namespace BMPBuilder
{
    partial class ExperimentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ExperimentForm));
            this.trialListView = new System.Windows.Forms.ListView();
            this.numbersTrialColumnHeader = new System.Windows.Forms.ColumnHeader();
            this.nameColumnHeader = new System.Windows.Forms.ColumnHeader();
            this.sizeColumnHeader = new System.Windows.Forms.ColumnHeader();
            this.patternSquaresColumnHeader = new System.Windows.Forms.ColumnHeader();
            this.durationColumnHeader = new System.Windows.Forms.ColumnHeader();
            this.colorsColumnHeader = new System.Windows.Forms.ColumnHeader();
            this.trialListMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.upToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.downToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.mainMenuStrip = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveAsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.infoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.totalNumberTrialsLabel = new System.Windows.Forms.Label();
            this.totalNumberTrialsDescriptionLabel = new System.Windows.Forms.Label();
            this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.deleteButton = new System.Windows.Forms.Button();
            this.generateButton = new System.Windows.Forms.Button();
            this.upButton = new System.Windows.Forms.Button();
            this.addButton = new System.Windows.Forms.Button();
            this.downButton = new System.Windows.Forms.Button();
            this.generateProgressBar = new System.Windows.Forms.ProgressBar();
            this.progressLabel = new System.Windows.Forms.Label();
            this.generateBackgroundWorker = new System.ComponentModel.BackgroundWorker();
            this.trialListMenuStrip.SuspendLayout();
            this.mainMenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // trialListView
            // 
            this.trialListView.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.trialListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.numbersTrialColumnHeader,
            this.nameColumnHeader,
            this.sizeColumnHeader,
            this.patternSquaresColumnHeader,
            this.durationColumnHeader,
            this.colorsColumnHeader});
            this.trialListView.ContextMenuStrip = this.trialListMenuStrip;
            this.trialListView.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trialListView.FullRowSelect = true;
            this.trialListView.Location = new System.Drawing.Point(15, 52);
            this.trialListView.MultiSelect = false;
            this.trialListView.Name = "trialListView";
            this.trialListView.Size = new System.Drawing.Size(532, 262);
            this.trialListView.TabIndex = 0;
            this.trialListView.UseCompatibleStateImageBehavior = false;
            this.trialListView.View = System.Windows.Forms.View.Details;
            this.trialListView.DoubleClick += new System.EventHandler(this.trialListView_DoubleClick);
            this.trialListView.SelectedIndexChanged += new System.EventHandler(this.trialListView_SelectedIndexChanged);
            // 
            // numbersTrialColumnHeader
            // 
            this.numbersTrialColumnHeader.Text = "#Trials";
            // 
            // nameColumnHeader
            // 
            this.nameColumnHeader.Text = "Name of Trials";
            this.nameColumnHeader.Width = 204;
            // 
            // sizeColumnHeader
            // 
            this.sizeColumnHeader.Text = "Size";
            this.sizeColumnHeader.Width = 58;
            // 
            // patternSquaresColumnHeader
            // 
            this.patternSquaresColumnHeader.Text = "Pattern";
            this.patternSquaresColumnHeader.Width = 61;
            // 
            // durationColumnHeader
            // 
            this.durationColumnHeader.Text = "Durat.";
            this.durationColumnHeader.Width = 56;
            // 
            // colorsColumnHeader
            // 
            this.colorsColumnHeader.Text = "Colors";
            this.colorsColumnHeader.Width = 67;
            // 
            // trialListMenuStrip
            // 
            this.trialListMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.deleteToolStripMenuItem,
            this.upToolStripMenuItem,
            this.downToolStripMenuItem});
            this.trialListMenuStrip.Name = "trialListMenuStrip";
            this.trialListMenuStrip.Size = new System.Drawing.Size(142, 70);
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.Image = global::BMPBuilder.Properties.Resources.remove_delete;
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new System.EventHandler(this.deleteToolStripMenuItem_Click);
            // 
            // upToolStripMenuItem
            // 
            this.upToolStripMenuItem.Image = global::BMPBuilder.Properties.Resources.arup16;
            this.upToolStripMenuItem.Name = "upToolStripMenuItem";
            this.upToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.upToolStripMenuItem.Text = "Move Up";
            this.upToolStripMenuItem.Click += new System.EventHandler(this.upToolStripMenuItem_Click);
            // 
            // downToolStripMenuItem
            // 
            this.downToolStripMenuItem.Image = global::BMPBuilder.Properties.Resources.ardo16;
            this.downToolStripMenuItem.Name = "downToolStripMenuItem";
            this.downToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.downToolStripMenuItem.Text = "Move Down";
            this.downToolStripMenuItem.Click += new System.EventHandler(this.downToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(245, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "List of all Trials for this Experiment";
            // 
            // mainMenuStrip
            // 
            this.mainMenuStrip.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.mainMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.mainMenuStrip.Location = new System.Drawing.Point(0, 0);
            this.mainMenuStrip.Name = "mainMenuStrip";
            this.mainMenuStrip.Size = new System.Drawing.Size(623, 24);
            this.mainMenuStrip.TabIndex = 3;
            this.mainMenuStrip.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.loadToolStripMenuItem,
            this.saveToolStripMenuItem,
            this.saveAsToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(40, 20);
            this.fileToolStripMenuItem.Text = "File";
            this.fileToolStripMenuItem.Click += new System.EventHandler(this.fileToolStripMenuItem_Click);
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Image = global::BMPBuilder.Properties.Resources.new16;
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.ShortcutKeyDisplayString = "";
            this.newToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.newToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.newToolStripMenuItem.Text = "New";
            this.newToolStripMenuItem.Click += new System.EventHandler(this.newToolStripMenuItem_Click);
            // 
            // loadToolStripMenuItem
            // 
            this.loadToolStripMenuItem.Image = global::BMPBuilder.Properties.Resources.open;
            this.loadToolStripMenuItem.Name = "loadToolStripMenuItem";
            this.loadToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.L)));
            this.loadToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.loadToolStripMenuItem.Text = "Load";
            this.loadToolStripMenuItem.Click += new System.EventHandler(this.loadToolStripMenuItem_Click);
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Image = global::BMPBuilder.Properties.Resources.save;
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.saveToolStripMenuItem.Text = "Save";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // saveAsToolStripMenuItem
            // 
            this.saveAsToolStripMenuItem.Image = global::BMPBuilder.Properties.Resources.save_as;
            this.saveAsToolStripMenuItem.Name = "saveAsToolStripMenuItem";
            this.saveAsToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift)
                        | System.Windows.Forms.Keys.S)));
            this.saveAsToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.saveAsToolStripMenuItem.Text = "Save As";
            this.saveAsToolStripMenuItem.Click += new System.EventHandler(this.saveAsToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Image = global::BMPBuilder.Properties.Resources.exit;
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.infoToolStripMenuItem});
            this.helpToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(26, 20);
            this.helpToolStripMenuItem.Text = "?";
            // 
            // infoToolStripMenuItem
            // 
            this.infoToolStripMenuItem.Image = global::BMPBuilder.Properties.Resources.help;
            this.infoToolStripMenuItem.Name = "infoToolStripMenuItem";
            this.infoToolStripMenuItem.Size = new System.Drawing.Size(111, 22);
            this.infoToolStripMenuItem.Text = "Info";
            this.infoToolStripMenuItem.Click += new System.EventHandler(this.infoToolStripMenuItem_Click);
            // 
            // openFileDialog
            // 
            this.openFileDialog.Filter = "Experiment Bin Files|*.bin|All files|*.*";
            // 
            // saveFileDialog
            // 
            this.saveFileDialog.Filter = "Experiment Bin Files|*.bin|All files|*.*";
            // 
            // totalNumberTrialsLabel
            // 
            this.totalNumberTrialsLabel.AutoSize = true;
            this.totalNumberTrialsLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.totalNumberTrialsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalNumberTrialsLabel.Location = new System.Drawing.Point(153, 324);
            this.totalNumberTrialsLabel.Name = "totalNumberTrialsLabel";
            this.totalNumberTrialsLabel.Size = new System.Drawing.Size(15, 16);
            this.totalNumberTrialsLabel.TabIndex = 9;
            this.totalNumberTrialsLabel.Text = "0";
            // 
            // totalNumberTrialsDescriptionLabel
            // 
            this.totalNumberTrialsDescriptionLabel.AutoSize = true;
            this.totalNumberTrialsDescriptionLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.totalNumberTrialsDescriptionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalNumberTrialsDescriptionLabel.Location = new System.Drawing.Point(12, 324);
            this.totalNumberTrialsDescriptionLabel.Name = "totalNumberTrialsDescriptionLabel";
            this.totalNumberTrialsDescriptionLabel.Size = new System.Drawing.Size(135, 16);
            this.totalNumberTrialsDescriptionLabel.TabIndex = 10;
            this.totalNumberTrialsDescriptionLabel.Text = "Total number of trials:";
            // 
            // deleteButton
            // 
            this.deleteButton.Enabled = false;
            this.deleteButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.deleteButton.Image = global::BMPBuilder.Properties.Resources.delete48;
            this.deleteButton.Location = new System.Drawing.Point(561, 197);
            this.deleteButton.Name = "deleteButton";
            this.deleteButton.Size = new System.Drawing.Size(48, 48);
            this.deleteButton.TabIndex = 6;
            this.deleteButton.UseVisualStyleBackColor = true;
            this.deleteButton.Click += new System.EventHandler(this.deleteButton_Click);
            // 
            // generateButton
            // 
            this.generateButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.generateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.generateButton.Image = global::BMPBuilder.Properties.Resources.copy48;
            this.generateButton.Location = new System.Drawing.Point(220, 320);
            this.generateButton.Name = "generateButton";
            this.generateButton.Size = new System.Drawing.Size(108, 72);
            this.generateButton.TabIndex = 4;
            this.generateButton.Text = "Generate Files";
            this.generateButton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.generateButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.generateButton.UseVisualStyleBackColor = true;
            this.generateButton.Click += new System.EventHandler(this.generateButton_Click);
            // 
            // upButton
            // 
            this.upButton.Enabled = false;
            this.upButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.upButton.Image = global::BMPBuilder.Properties.Resources.arup48;
            this.upButton.Location = new System.Drawing.Point(561, 76);
            this.upButton.Name = "upButton";
            this.upButton.Size = new System.Drawing.Size(48, 48);
            this.upButton.TabIndex = 7;
            this.upButton.UseVisualStyleBackColor = true;
            this.upButton.Click += new System.EventHandler(this.upButton_Click);
            // 
            // addButton
            // 
            this.addButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addButton.Image = global::BMPBuilder.Properties.Resources.add48;
            this.addButton.Location = new System.Drawing.Point(561, 251);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(48, 48);
            this.addButton.TabIndex = 1;
            this.addButton.UseVisualStyleBackColor = true;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // downButton
            // 
            this.downButton.Enabled = false;
            this.downButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.downButton.Image = global::BMPBuilder.Properties.Resources.ardown48;
            this.downButton.Location = new System.Drawing.Point(561, 130);
            this.downButton.Name = "downButton";
            this.downButton.Size = new System.Drawing.Size(48, 48);
            this.downButton.TabIndex = 5;
            this.downButton.UseVisualStyleBackColor = true;
            this.downButton.Click += new System.EventHandler(this.downButton_Click);
            // 
            // generateProgressBar
            // 
            this.generateProgressBar.Location = new System.Drawing.Point(337, 350);
            this.generateProgressBar.Name = "generateProgressBar";
            this.generateProgressBar.Size = new System.Drawing.Size(196, 23);
            this.generateProgressBar.TabIndex = 11;
            // 
            // progressLabel
            // 
            this.progressLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.progressLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.progressLabel.ForeColor = System.Drawing.Color.Blue;
            this.progressLabel.Location = new System.Drawing.Point(334, 327);
            this.progressLabel.Name = "progressLabel";
            this.progressLabel.Size = new System.Drawing.Size(198, 20);
            this.progressLabel.TabIndex = 12;
            this.progressLabel.Text = "Press \"Generate\" to create Experiment.";
            // 
            // generateBackgroundWorker
            // 
            this.generateBackgroundWorker.WorkerReportsProgress = true;
            this.generateBackgroundWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.generateBackgroundWorker_DoWork);
            this.generateBackgroundWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.generateBackgroundWorker_RunWorkerCompleted);
            this.generateBackgroundWorker.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.generateBackgroundWorker_ProgressChanged);
            // 
            // ExperimentForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(623, 404);
            this.Controls.Add(this.mainMenuStrip);
            this.Controls.Add(this.deleteButton);
            this.Controls.Add(this.generateProgressBar);
            this.Controls.Add(this.progressLabel);
            this.Controls.Add(this.upButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.totalNumberTrialsDescriptionLabel);
            this.Controls.Add(this.generateButton);
            this.Controls.Add(this.totalNumberTrialsLabel);
            this.Controls.Add(this.trialListView);
            this.Controls.Add(this.addButton);
            this.Controls.Add(this.downButton);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.mainMenuStrip;
            this.Name = "ExperimentForm";
            this.Text = "Experiment Builder";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ExperimentForm_FormClosing);
            this.trialListMenuStrip.ResumeLayout(false);
            this.mainMenuStrip.ResumeLayout(false);
            this.mainMenuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView trialListView;
        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MenuStrip mainMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.Button generateButton;
        private System.Windows.Forms.ColumnHeader numbersTrialColumnHeader;
        private System.Windows.Forms.ColumnHeader nameColumnHeader;
        private System.Windows.Forms.ColumnHeader durationColumnHeader;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
        private System.Windows.Forms.Button downButton;
        private System.Windows.Forms.Button deleteButton;
        private System.Windows.Forms.Button upButton;
        private System.Windows.Forms.ContextMenuStrip trialListMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem upToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem downToolStripMenuItem;
        private System.Windows.Forms.Label totalNumberTrialsLabel;
        private System.Windows.Forms.Label totalNumberTrialsDescriptionLabel;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog;
        private System.Windows.Forms.ColumnHeader sizeColumnHeader;
        private System.Windows.Forms.ColumnHeader patternSquaresColumnHeader;
        private System.Windows.Forms.ColumnHeader colorsColumnHeader;
        private System.Windows.Forms.ToolStripMenuItem saveAsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem infoToolStripMenuItem;
        private System.Windows.Forms.ProgressBar generateProgressBar;
        private System.Windows.Forms.Label progressLabel;
        private System.ComponentModel.BackgroundWorker generateBackgroundWorker;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
    }
}