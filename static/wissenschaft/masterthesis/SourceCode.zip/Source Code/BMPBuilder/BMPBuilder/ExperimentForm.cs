using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BMPBuilder
{
    /// <summary>
    /// The GUI for the Experiment Builder.
    /// </summary>
    public partial class ExperimentForm : Form
    {
        /// <summary>
        /// The actual filename of the experiment file - if empty, the "Save" and "New" functions are disabled. 
        /// </summary>
        private string filename = "";

        /// <summary>
        /// True, if changes are made and the experiment file needs to be saved again. (Otherwise data can be lost) 
        /// </summary>
        private bool changes = false;

        private ExperimentData experiment = new ExperimentData();

        /// <summary>
        /// Gets or sets the experiment data.
        /// </summary>
        /// <value>The experiment data.</value>
        public ExperimentData Experiment
        {
            get { return experiment; }
            set { experiment = value; }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ExperimentForm"/> class.
        /// </summary>
        public ExperimentForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Handles the Click event of the addButton control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void addButton_Click(object sender, EventArgs e)
        {
            TrialForm trialForm = new TrialForm(this);
            trialForm.ShowDialog();
            trialForm.Focus();
            changes = true;
        }

        /// <summary>
        /// Updates the trial list.
        /// </summary>
        public void UpdateTrialList()
        {
            trialListView.Items.Clear();
            int count = 0;
            for (int i = 0; i < Experiment.Trials.Count; i++)
            {
                ListViewItem trialItem = new ListViewItem(Experiment.Trials[i].TrialNumbers.ToString(), 0);
                count += Experiment.Trials[i].TrialNumbers;
                trialItem.SubItems.Add(Experiment.Trials[i].Name.ToString());
                trialItem.SubItems.Add(Experiment.Trials[i].Preview.SizeX.ToString() + "x" + Experiment.Trials[i].Preview.SizeY.ToString());
                trialItem.SubItems.Add(Experiment.Trials[i].Preview.PatternSquaresX.ToString() + "x" + Experiment.Trials[i].Preview.PatternSquaresY.ToString());
                trialItem.SubItems.Add(Experiment.Trials[i].Duration.ToString());
                int colors = 2;
                if (Experiment.Trials[i].Preview.Color3Checked) colors++;
                if (Experiment.Trials[i].Preview.Color4Checked) colors++;
                if (Experiment.Trials[i].Preview.Color5Checked) colors++;
                if (Experiment.Trials[i].Preview.Color6Checked) colors++;
                trialItem.SubItems.Add(colors.ToString());
                trialListView.Items.AddRange(new ListViewItem[] { trialItem });
            }
            totalNumberTrialsLabel.Text = count.ToString();
            verifyUpDownButtons();
        }

        /// <summary>
        /// Handles the DoubleClick event of the trialListView control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void trialListView_DoubleClick(object sender, EventArgs e)
        {
            //Open TrialForm
            try
            {
                int itemNumber = trialListView.Items.IndexOf(trialListView.SelectedItems[0]);
                TrialForm trialForm = new TrialForm(this, itemNumber);
                trialForm.ShowDialog();
                trialForm.Focus();
                changes = true;
            }
            catch (ArgumentOutOfRangeException ae) { ;}
        }

        /// <summary>
        /// Handles the Click event of the loadToolStripMenuItem control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void loadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                experiment = ExperimentData.LoadExperiment(openFileDialog.FileName);
                changes = false;
            }
            this.filename = openFileDialog.FileName;
            UpdateTrialList();
        }

        /// <summary>
        /// Handles the Click event of the saveToolStripMenuItem control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (filename.Equals(""))
            {
                this.saveAsToolStripMenuItem_Click(sender, e);
            }
            else
            {
                experiment.SaveExperiment(filename);
                changes = false;
            }
        }

        /// <summary>
        /// Handles the Click event of the upButton control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void upButton_Click(object sender, EventArgs e)
        {
            moveSelectedUp();
        }

        /// <summary>
        /// Moves the selected trial up.
        /// </summary>
        private void moveSelectedUp()
        {
            try
            {
                int itemNumber = trialListView.Items.IndexOf(trialListView.SelectedItems[0]);
                swapTrials(itemNumber - 1, itemNumber);
                UpdateTrialList();
                trialListView.Select();
                trialListView.Items[itemNumber - 1].Selected = true;

            }
            catch (ArgumentOutOfRangeException ae)
            {
                if (trialListView.Items.Count > 0)
                {
                    trialListView.Select();
                    trialListView.Items[0].Selected = true;
                }
            }
        }

        /// <summary>
        /// Moves the selected trial down.
        /// </summary>
        private void moveSelectedDown()
        {
            try
            {
                int itemNumber = trialListView.Items.IndexOf(trialListView.SelectedItems[0]);
                swapTrials(itemNumber + 1, itemNumber);
                UpdateTrialList();
                trialListView.Select();
                trialListView.Items[itemNumber + 1].Selected = true;

            }
            catch (ArgumentOutOfRangeException ae)
            {
                if (trialListView.Items.Count > 0)
                {
                    trialListView.Select();
                    trialListView.Items[trialListView.Items.Count - 1].Selected = true;
                }
            }
        }

        /// <summary>
        /// Swaps two trials.
        /// </summary>
        /// <param name="trialPosition1">First trial to be swapped with second trial.</param>
        /// <param name="trialPosition2">Second trial to be swapped with first trial.</param>
        private void swapTrials(int trialPosition1, int trialPosition2)
        {
            TrialData temp_trial = experiment.Trials[trialPosition1];
            experiment.Trials[trialPosition1] = experiment.Trials[trialPosition2];
            experiment.Trials[trialPosition2] = temp_trial;
            changes = true;
        }


        /// <summary>
        /// Deletes the selected item.
        /// </summary>
        private void deleteSelectedItem()
        {
            try
            {
                int itemNumber = trialListView.Items.IndexOf(trialListView.SelectedItems[0]);
                experiment.Trials.RemoveAt(itemNumber);
                UpdateTrialList();
                changes = true;
            }
            catch (ArgumentOutOfRangeException ae) { ;}
        }

        /// <summary>
        /// Handles the Click event of the downButton control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void downButton_Click(object sender, EventArgs e)
        {
            moveSelectedDown();
        }

        /// <summary>
        /// Handles the Click event of the deleteButton control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void deleteButton_Click(object sender, EventArgs e)
        {
            deleteSelectedItem();
        }

        /// <summary>
        /// Handles the Click event of the upToolStripMenuItem control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void upToolStripMenuItem_Click(object sender, EventArgs e)
        {
            moveSelectedUp();
        }

        /// <summary>
        /// Handles the Click event of the downToolStripMenuItem control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void downToolStripMenuItem_Click(object sender, EventArgs e)
        {
            moveSelectedDown();
        }

        /// <summary>
        /// Handles the Click event of the deleteToolStripMenuItem control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            deleteSelectedItem();
        }

        /// <summary>
        /// Handles the Click event of the generateButton control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void generateButton_Click(object sender, EventArgs e)
        {
            generateButton.Enabled = false;
            if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
            {
                Object[] args = new Object[2];
                args[0] = folderBrowserDialog.SelectedPath;
                args[1] = experiment;
                this.progressLabel.Text = "Generating files...";
                generateBackgroundWorker.RunWorkerAsync(args);
            }
            else
            {
                generateButton.Enabled = true;
            }
            
        }

        /// <summary>
        /// Handles the DoWork event of the generateBackgroundWorker control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.ComponentModel.DoWorkEventArgs"/> instance containing the event data.</param>
        private void generateBackgroundWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            // Get the BackgroundWorker that raised this event.
            BackgroundWorker worker = sender as BackgroundWorker;
            Object[] args = (Object[])(e.Argument);
            string path = (string)(args[0]);
            ExperimentData experiment = (ExperimentData)(args[1]);

            experiment.GenerateExperimentFile(path,worker);
        }

        /// <summary>
        /// Handles the ProgressChanged event of the generateBackgroundWorker control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.ComponentModel.ProgressChangedEventArgs"/> instance containing the event data.</param>
        private void generateBackgroundWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            this.generateProgressBar.Value = e.ProgressPercentage;
        }

        /// <summary>
        /// Handles the RunWorkerCompleted event of the generateBackgroundWorker control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.ComponentModel.RunWorkerCompletedEventArgs"/> instance containing the event data.</param>
        private void generateBackgroundWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            this.progressLabel.Text = "Done!";
            generateButton.Enabled = true;
            MessageBox.Show(this, "Files succesfully generated", "BMP Builder", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        /// <summary>
        /// Handles the Click event of the saveAsToolStripMenuItem control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                experiment.SaveExperiment(saveFileDialog.FileName);
                changes = false;
                filename=saveFileDialog.FileName;
            }
        }

        /// <summary>
        /// Handles the Click event of the exitToolStripMenuItem control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (changes)
                if (DialogResult.Cancel == MessageBox.Show("Quit without saving?", "Quit", MessageBoxButtons.OKCancel, MessageBoxIcon.Question))
                    return;
            this.Close();
        }

        /// <summary>
        /// Handles the SelectedIndexChanged event of the trialListView control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void trialListView_SelectedIndexChanged(object sender, EventArgs e)
        {
            verifyUpDownButtons();
        }

        /// <summary>
        /// Verifies if the up/down buttons have to be enabled or disabled.
        /// </summary>
        private void verifyUpDownButtons()
        {
            if (this.trialListView.SelectedItems.Count > 0)
            {
                if (!this.upButton.Enabled) this.upButton.Enabled = true;
                if (!this.downButton.Enabled) this.downButton.Enabled = true;
                if (!this.deleteButton.Enabled) this.deleteButton.Enabled = true;
            }
            else
            {
                if (this.upButton.Enabled) this.upButton.Enabled = false;
                if (this.downButton.Enabled) this.downButton.Enabled = false;
                if (this.deleteButton.Enabled) this.deleteButton.Enabled = false;
            }
        }

        /// <summary>
        /// Handles the Click event of the infoToolStripMenuItem control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void infoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Info info = new Info();
            info.ShowDialog();
            info.Focus();
        }

        /// <summary>
        /// Handles the Click event of the fileToolStripMenuItem control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {

            newToolStripMenuItem.Enabled = changes;

            if (changes && !filename.Equals(""))
            {
                saveToolStripMenuItem.Enabled = true;
                saveToolStripMenuItem.Text = "Save " + filename.Substring(filename.LastIndexOf(@"\")+1);
            }
            else
            {
                saveToolStripMenuItem.Enabled = false;
                saveToolStripMenuItem.Text = "Save";
            }
        }

        /// <summary>
        /// Handles the Click event of the newToolStripMenuItem control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (changes)
                if (DialogResult.Cancel == MessageBox.Show("Discard current experiment?", "Discard", MessageBoxButtons.OKCancel, MessageBoxIcon.Question))
                    return;
            filename = "";
            changes = false;
            experiment = new ExperimentData();
            UpdateTrialList();
            
        }

        /// <summary>
        /// Handles the FormClosing event of the ExperimentForm control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Windows.Forms.FormClosingEventArgs"/> instance containing the event data.</param>
        private void ExperimentForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (changes)
                if (DialogResult.Cancel == MessageBox.Show("Quit without saving?", "Quit", MessageBoxButtons.OKCancel, MessageBoxIcon.Question))
                    e.Cancel = true;
        }


    }
}