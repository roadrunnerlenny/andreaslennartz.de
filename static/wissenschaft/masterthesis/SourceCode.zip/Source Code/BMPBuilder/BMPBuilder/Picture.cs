using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace BMPBuilder
{
    /// <summary>
    /// The Picture class inherits from the Bitmap class, and represents a picture in which a target pattern can be found.
    /// </summary>
    [Serializable]
    public class Picture : BMPBuilder.Bitmap
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Picture"/> class.
        /// </summary>
        /// <param name="squaresX">The number of squares in horizontal direction.</param>
        /// <param name="squaresY">The number of squares in vertical direction.</param>
        /// <param name="colors">A list of colors which should be used for the image. (E.g, black and white)</param>
        public Picture(int squaresX, int squaresY, List<Color> colors) : base(squaresX, squaresY, colors)
        {
            ;
        }

        /// <summary>
        /// The pattern object which can be found in the picture.
        /// </summary>
        private Pattern patternInPicture = null;

        private int patternPositionX = 0;

        /// <summary>
        /// Gets or sets the pattern position X-coordinate (horizontal).
        /// </summary>
        /// <value>The pattern position X-coordinate (horizontal).</value>
        public int PatternPositionX
        {
            get { return patternPositionX; }
            set { patternPositionX = value; }
        }

        private int patternPositionY = 0;

        /// <summary>
        /// Gets or sets the pattern position Y-coordinate (vertical).
        /// </summary>
        /// <value>The pattern position Y-coordinate (vertical).</value>
        public int PatternPositionY
        {
            get { return patternPositionY; }
            set { patternPositionY = value; }
        }

        /// <summary>
        /// Removes and adds a pattern to the picture.
        /// </summary>
        /// <param name="pattern">The pattern to be added.</param>
        public void RemoveAndAddPattern(Pattern pattern) {
            patternInPicture = pattern;

            bool occur = true;
            int occurcounter = 1;
            Random colorRand = new Random();
            Random rand = new Random();
            /* Run the following steps until the pattern occurs exactly one time in the picture */
            do
            {
                /* Check if Pattern is in the picture - delete all occurances */
                while (occurcounter > 0)
                {
                    occurcounter = 0;
                    for (int x = 0; x <= this.squaresX - pattern.SquaresX; x++)
                    {
                        for (int y = 0; y <= this.squaresY - pattern.SquaresY; y++)
                        {
                            occur = true;
                            for (int ix = 0; ix < pattern.SquaresX; ix++)
                                for (int iy = 0; iy < pattern.SquaresY; iy++)
                                    if (structure[x + ix, y + iy] != pattern.Structure[ix, iy]) occur = false;
                            if (occur)
                            {
                                int randNumber = colorRand.Next(0, colors.Count);
                                while (colors[randNumber].ToArgb() == structure[x, y])
                                    randNumber = colorRand.Next(0, colors.Count);
                                structure[x, y] = colors[randNumber].ToArgb();
                                occurcounter++;
                            }
                        }
                    }
                }
                /* All occurances deleted */

                /* Now add the pattern exactly one time to the picture */
                patternPositionX = rand.Next(0, (this.squaresX - pattern.SquaresX));
                patternPositionY = rand.Next(0, (this.squaresY - pattern.SquaresY));
                for (int x = 0; x < pattern.SquaresX; x++)
                {
                    for (int y = 0; y < pattern.SquaresY; y++)
                    {
                        structure[patternPositionX + x, patternPositionY + y] = pattern.Structure[x, y];
                    }
                }

                /* Because of the changes in the picture before the pattern can occur twice - let's check it */
                /* Check if Pattern is in the picture - repeat until only one is in the picture*/
                occur = true;
                occurcounter = 0;
                for (int x = 0; x <= this.squaresX - pattern.SquaresX; x++)
                {
                    for (int y = 0; y <= this.squaresY - pattern.SquaresY; y++)
                    {
                        occur = true;
                        for (int ix = 0; ix < pattern.SquaresX; ix++)
                            for (int iy = 0; iy < pattern.SquaresY; iy++)
                                if (structure[x + ix, y + iy] != pattern.Structure[ix, iy]) occur = false;
                        if (occur) occurcounter++;
                    }
                }
            } while (occurcounter != 1);

        }

        /// <summary>
        /// Calculates the horizontal position in the structure of a given pixel location on the screen. Depends on the start location and 
        /// the size of the squares.
        /// </summary>
        /// <param name="averageX">The pixel location (X-Axis/horizontal) on the screen.</param>
        /// <param name="sizeX">The horizontal size of each square.</param>
        /// <returns>The horizontal position in the structure array.</returns>
        /// <example>
        /// <code>
        /// using System.Drawing;
        ///    List  c AS Color = {Color.Black, Color.White};
        ///    Picture p = new Picture(10, 10, c);
        ///    p.Create();
        ///    p.StartLocation = new Point(100, 100); //Picture has a distance of 100 pixel to the upper left corner of the screen
        ///
        ///    int averageX = 170; //Screen fixation was 170 pixel away from left border of screen.
        ///    int posX = p.CalculatePosX(averageX, 50); //Size of each square: 50 pixel;
        ///    Console.WriteLine("The X-Position should be 1: " + posX);
        /// </code>
        /// </example>
        public int CalculatePosX(int averageX, int sizeX)
        {
            int posX = -1;
            if ((averageX > startLocation.X) && (averageX < (startLocation.X + sizeX * squaresX))) //Fixation is inside
                posX = (averageX - startLocation.X) / sizeX;
            return posX;

        }

        /// <summary>
        /// Calculates the vertical position in the structure of a given pixel location on the screen. Depends on the start location and 
        /// the size of the squares.
        /// </summary>
        /// <param name="averageX">The pixel location (Y-Axis, vertical) on the screen.</param>
        /// <param name="sizeX">The vertical size of each square.</param>
        /// <returns>The vertical position in the structure array.</returns>
        /// <example>
        /// <code>
        /// using System.Drawing;
        ///    List c AS Color = {Color.Black, Color.White};
        ///    Picture p = new Picture(10, 10, c);
        ///    p.Create();
        ///    p.StartLocation = new Point(100, 100); //Picture has a distance of 100 pixel to the upper left corner of the screen
        ///
        ///    int averageY = 220; //Screen fixation was 220 pixel away from left border of screen.
        ///    int posY = p.CalculatePosY(averageX, 50); //Size of each square: 50 pixel;
        ///    Console.WriteLine("The X-Position should be 2: " + posY);
        /// </code>
        /// </example>
        /// 
        public int CalculatePosY(int averageY, int sizeY)
        {   
            int posY = -1;
            if ((averageY > startLocation.Y) && (averageY < (startLocation.Y + sizeY * squaresY))) //Fixation is inside
                posY = (averageY - startLocation.Y) / sizeY;
            return posY;
        }

        /// <summary>
        /// Determines whether the given position in the structure is a pattern fixation. Includes the surrounding squares - the radius
        /// specifies how many squares are included. 
        /// </summary>
        /// <param name="pos">The position in the structure.</param>
        /// <param name="radius">The radius, specifies how many surrounding squares are included. A radius of 0
        /// includes only the minimun squares, which depends on the pattern size. The bigger the radius, the more squares (also
        /// depending on the pattern size) are included.</param>
        /// <param name="includePatternFixation">If set to <c>true</c> the function always returns <c>false</c>.</param>
        /// <returns>
        /// 	<c>true</c> if it is a pattern fixation and the flag <c>includePatternFixation</c> is set; otherwise, <c>false</c>.
        /// </returns>
        public bool IsPatternFixation(Point pos, int radius, bool includePatternFixation)
        {
            if (!includePatternFixation)
            {
                return IsPatternFixation(pos, radius);
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Determines whether the given position in the structure is a pattern fixation. Includes the surrounding squares - the radius
        /// specifies how many squares are included. 
        /// </summary>
        /// <param name="pos">The position in the structure.</param>
        /// <param name="radius">The radius, specifies how many surrounding squares are included. A radius of 0
        /// includes only the minimun squares, which depends on the pattern size. The bigger the radius, the more squares (also
        /// depending on the pattern size) are included.</param>
        /// <returns>
        /// 	<c>true</c> if it is a pattern fixation; otherwise, <c>false</c>.
        /// </returns>
        public bool IsPatternFixation(Point pos, int radius) 
        {

            if (patternPositionX + 1 >= pos.X - (radius + 1) &&
                patternPositionX + 1 <= pos.X + (radius + 1) &&
                patternPositionY + 1 >= pos.Y - (radius + 1) &&
                patternPositionY + 1 <= pos.Y + (radius + 1))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
