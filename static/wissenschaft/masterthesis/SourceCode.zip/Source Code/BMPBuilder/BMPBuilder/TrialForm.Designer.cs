namespace BMPBuilder
{
    partial class TrialForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TrialForm));
            this.squaresXTextBox = new System.Windows.Forms.TextBox();
            this.squaresXLabel = new System.Windows.Forms.Label();
            this.squareYLabel = new System.Windows.Forms.Label();
            this.squaresYTextBox = new System.Windows.Forms.TextBox();
            this.sizeXYLabel = new System.Windows.Forms.Label();
            this.sizeXTextBox = new System.Windows.Forms.TextBox();
            this.sizeYTextBox = new System.Windows.Forms.TextBox();
            this.starLabel1 = new System.Windows.Forms.Label();
            this.previewButton = new System.Windows.Forms.Button();
            this.fullScreenCheckBox = new System.Windows.Forms.CheckBox();
            this.backgroundColorPictureBox = new System.Windows.Forms.PictureBox();
            this.backgroundColorLabel = new System.Windows.Forms.Label();
            this.backgroundColorDialog = new System.Windows.Forms.ColorDialog();
            this.color1Dialog = new System.Windows.Forms.ColorDialog();
            this.color2Dialog = new System.Windows.Forms.ColorDialog();
            this.color1Label = new System.Windows.Forms.Label();
            this.color2Label = new System.Windows.Forms.Label();
            this.color2PictureBox = new System.Windows.Forms.PictureBox();
            this.color1PictureBox = new System.Windows.Forms.PictureBox();
            this.patternSquaresXTextBox = new System.Windows.Forms.TextBox();
            this.starLabel2 = new System.Windows.Forms.Label();
            this.patternLabel = new System.Windows.Forms.Label();
            this.patternSquaresYTextBox = new System.Windows.Forms.TextBox();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.color6PictureBox = new System.Windows.Forms.PictureBox();
            this.color5PictureBox = new System.Windows.Forms.PictureBox();
            this.color4PictureBox = new System.Windows.Forms.PictureBox();
            this.color3PictureBox = new System.Windows.Forms.PictureBox();
            this.color3CheckBox = new System.Windows.Forms.CheckBox();
            this.color4CheckBox = new System.Windows.Forms.CheckBox();
            this.color5CheckBox = new System.Windows.Forms.CheckBox();
            this.color6CheckBox = new System.Windows.Forms.CheckBox();
            this.color3Dialog = new System.Windows.Forms.ColorDialog();
            this.color4Dialog = new System.Windows.Forms.ColorDialog();
            this.color5Dialog = new System.Windows.Forms.ColorDialog();
            this.color6Dialog = new System.Windows.Forms.ColorDialog();
            this.displayXDescriptionLabel = new System.Windows.Forms.Label();
            this.displayYDescriptionLabel = new System.Windows.Forms.Label();
            this.numberTrialsTextBox = new System.Windows.Forms.TextBox();
            this.numberTrialsLabel = new System.Windows.Forms.Label();
            this.nameTrialsLabel = new System.Windows.Forms.Label();
            this.nameTrialsTextBox = new System.Windows.Forms.TextBox();
            this.displayXTextBox = new System.Windows.Forms.TextBox();
            this.displayYTextBox = new System.Windows.Forms.TextBox();
            this.color3Label = new System.Windows.Forms.Label();
            this.color4Label = new System.Windows.Forms.Label();
            this.color5Label = new System.Windows.Forms.Label();
            this.color6Label = new System.Windows.Forms.Label();
            this.maxDurationTextBox = new System.Windows.Forms.TextBox();
            this.maxDurationLabel = new System.Windows.Forms.Label();
            this.sameScreenCheckBox = new System.Windows.Forms.CheckBox();
            this.OKButton = new System.Windows.Forms.Button();
            this.cancelButton = new System.Windows.Forms.Button();
            this.quadraticCheckBox = new System.Windows.Forms.CheckBox();
            this.displayTimeTextBox = new System.Windows.Forms.TextBox();
            this.displayTimeLabel = new System.Windows.Forms.Label();
            this.secLabel = new System.Windows.Forms.Label();
            this.displayTime2TextBox = new System.Windows.Forms.TextBox();
            this.displayTime2Label = new System.Windows.Forms.Label();
            this.borderColorLabel = new System.Windows.Forms.Label();
            this.borderColorPictureBox = new System.Windows.Forms.PictureBox();
            this.borderColorDialog = new System.Windows.Forms.ColorDialog();
            this.conclusionColorDialog = new System.Windows.Forms.ColorDialog();
            this.conclusionColorLabel = new System.Windows.Forms.Label();
            this.conclusionColorPictureBox = new System.Windows.Forms.PictureBox();
            this.displayTime3Label = new System.Windows.Forms.Label();
            this.displayTimeTrialNumberLabel = new System.Windows.Forms.Label();
            this.secLabel2 = new System.Windows.Forms.Label();
            this.borderSizeDescriptionLabel = new System.Windows.Forms.Label();
            this.borderSizeLabel = new System.Windows.Forms.Label();
            this.colorGroupBox = new System.Windows.Forms.GroupBox();
            this.trialGroupBox = new System.Windows.Forms.GroupBox();
            this.squareGroupBox = new System.Windows.Forms.GroupBox();
            this.patternGroupBox = new System.Windows.Forms.GroupBox();
            this.secLabel3 = new System.Windows.Forms.Label();
            this.displayTimeTrialNumber2Label = new System.Windows.Forms.Label();
            this.displayTime4Label = new System.Windows.Forms.Label();
            this.displayTime5Label = new System.Windows.Forms.Label();
            this.displayTime3TextBox = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.backgroundColorPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.color2PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.color1PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.color6PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.color5PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.color4PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.color3PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.borderColorPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.conclusionColorPictureBox)).BeginInit();
            this.colorGroupBox.SuspendLayout();
            this.trialGroupBox.SuspendLayout();
            this.squareGroupBox.SuspendLayout();
            this.patternGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // squaresXTextBox
            // 
            this.squaresXTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.squaresXTextBox.Enabled = false;
            this.squaresXTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.squaresXTextBox.Location = new System.Drawing.Point(306, 39);
            this.squaresXTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.squaresXTextBox.Name = "squaresXTextBox";
            this.squaresXTextBox.Size = new System.Drawing.Size(39, 22);
            this.squaresXTextBox.TabIndex = 12;
            // 
            // squaresXLabel
            // 
            this.squaresXLabel.AutoSize = true;
            this.squaresXLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.squaresXLabel.Location = new System.Drawing.Point(219, 43);
            this.squaresXLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.squaresXLabel.Name = "squaresXLabel";
            this.squaresXLabel.Size = new System.Drawing.Size(80, 16);
            this.squaresXLabel.TabIndex = 5;
            this.squaresXLabel.Text = "# Squares X";
            // 
            // squareYLabel
            // 
            this.squareYLabel.AutoSize = true;
            this.squareYLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.squareYLabel.Location = new System.Drawing.Point(360, 42);
            this.squareYLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.squareYLabel.Name = "squareYLabel";
            this.squareYLabel.Size = new System.Drawing.Size(81, 16);
            this.squareYLabel.TabIndex = 6;
            this.squareYLabel.Text = "# Squares Y";
            // 
            // squaresYTextBox
            // 
            this.squaresYTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.squaresYTextBox.Enabled = false;
            this.squaresYTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.squaresYTextBox.Location = new System.Drawing.Point(446, 39);
            this.squaresYTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.squaresYTextBox.Name = "squaresYTextBox";
            this.squaresYTextBox.Size = new System.Drawing.Size(39, 22);
            this.squaresYTextBox.TabIndex = 13;
            // 
            // sizeXYLabel
            // 
            this.sizeXYLabel.AutoSize = true;
            this.sizeXYLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sizeXYLabel.Location = new System.Drawing.Point(9, 76);
            this.sizeXYLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.sizeXYLabel.Name = "sizeXYLabel";
            this.sizeXYLabel.Size = new System.Drawing.Size(127, 16);
            this.sizeXYLabel.TabIndex = 8;
            this.sizeXYLabel.Text = "Size X*Y of Squares";
            // 
            // sizeXTextBox
            // 
            this.sizeXTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sizeXTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sizeXTextBox.Location = new System.Drawing.Point(138, 72);
            this.sizeXTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.sizeXTextBox.Name = "sizeXTextBox";
            this.sizeXTextBox.Size = new System.Drawing.Size(39, 22);
            this.sizeXTextBox.TabIndex = 14;
            this.sizeXTextBox.Click += new System.EventHandler(this.sizeXTextBox_Click);
            this.sizeXTextBox.TextChanged += new System.EventHandler(this.sizeXTextBox_TextChanged);
            // 
            // sizeYTextBox
            // 
            this.sizeYTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sizeYTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sizeYTextBox.Location = new System.Drawing.Point(194, 72);
            this.sizeYTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.sizeYTextBox.Name = "sizeYTextBox";
            this.sizeYTextBox.Size = new System.Drawing.Size(39, 22);
            this.sizeYTextBox.TabIndex = 15;
            this.sizeYTextBox.Click += new System.EventHandler(this.sizeYTextBox_Click);
            this.sizeYTextBox.TextChanged += new System.EventHandler(this.sizeYTextBox_TextChanged);
            // 
            // starLabel1
            // 
            this.starLabel1.AutoSize = true;
            this.starLabel1.Location = new System.Drawing.Point(180, 76);
            this.starLabel1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.starLabel1.Name = "starLabel1";
            this.starLabel1.Size = new System.Drawing.Size(11, 13);
            this.starLabel1.TabIndex = 11;
            this.starLabel1.Text = "*";
            // 
            // previewButton
            // 
            this.previewButton.Enabled = false;
            this.previewButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.previewButton.Image = global::BMPBuilder.Properties.Resources.squares;
            this.previewButton.Location = new System.Drawing.Point(383, 366);
            this.previewButton.Margin = new System.Windows.Forms.Padding(4);
            this.previewButton.Name = "previewButton";
            this.previewButton.Size = new System.Drawing.Size(83, 78);
            this.previewButton.TabIndex = 12;
            this.previewButton.Text = "Preview";
            this.previewButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.previewButton.UseVisualStyleBackColor = true;
            this.previewButton.Click += new System.EventHandler(this.PreviewButton_Click);
            // 
            // fullScreenCheckBox
            // 
            this.fullScreenCheckBox.AutoSize = true;
            this.fullScreenCheckBox.Checked = true;
            this.fullScreenCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.fullScreenCheckBox.Enabled = false;
            this.fullScreenCheckBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.fullScreenCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fullScreenCheckBox.Location = new System.Drawing.Point(12, 21);
            this.fullScreenCheckBox.Margin = new System.Windows.Forms.Padding(4);
            this.fullScreenCheckBox.Name = "fullScreenCheckBox";
            this.fullScreenCheckBox.Size = new System.Drawing.Size(166, 20);
            this.fullScreenCheckBox.TabIndex = 10;
            this.fullScreenCheckBox.Text = "Fill Screen with Squares";
            this.fullScreenCheckBox.UseVisualStyleBackColor = true;
            // 
            // backgroundColorPictureBox
            // 
            this.backgroundColorPictureBox.BackColor = System.Drawing.Color.White;
            this.backgroundColorPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.backgroundColorPictureBox.Location = new System.Drawing.Point(134, 18);
            this.backgroundColorPictureBox.Margin = new System.Windows.Forms.Padding(4);
            this.backgroundColorPictureBox.Name = "backgroundColorPictureBox";
            this.backgroundColorPictureBox.Size = new System.Drawing.Size(27, 24);
            this.backgroundColorPictureBox.TabIndex = 14;
            this.backgroundColorPictureBox.TabStop = false;
            this.backgroundColorPictureBox.Click += new System.EventHandler(this.backgroundColorPictureBox_Click);
            // 
            // backgroundColorLabel
            // 
            this.backgroundColorLabel.AutoSize = true;
            this.backgroundColorLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backgroundColorLabel.Location = new System.Drawing.Point(10, 22);
            this.backgroundColorLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.backgroundColorLabel.Name = "backgroundColorLabel";
            this.backgroundColorLabel.Size = new System.Drawing.Size(116, 16);
            this.backgroundColorLabel.TabIndex = 45;
            this.backgroundColorLabel.Text = "Background Color";
            // 
            // color1Label
            // 
            this.color1Label.AutoSize = true;
            this.color1Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.color1Label.Location = new System.Drawing.Point(11, 75);
            this.color1Label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.color1Label.Name = "color1Label";
            this.color1Label.Size = new System.Drawing.Size(50, 16);
            this.color1Label.TabIndex = 16;
            this.color1Label.Text = "Color 1";
            // 
            // color2Label
            // 
            this.color2Label.AutoSize = true;
            this.color2Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.color2Label.Location = new System.Drawing.Point(11, 106);
            this.color2Label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.color2Label.Name = "color2Label";
            this.color2Label.Size = new System.Drawing.Size(50, 16);
            this.color2Label.TabIndex = 17;
            this.color2Label.Text = "Color 2";
            // 
            // color2PictureBox
            // 
            this.color2PictureBox.BackColor = System.Drawing.Color.Black;
            this.color2PictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.color2PictureBox.Location = new System.Drawing.Point(71, 101);
            this.color2PictureBox.Margin = new System.Windows.Forms.Padding(4);
            this.color2PictureBox.Name = "color2PictureBox";
            this.color2PictureBox.Size = new System.Drawing.Size(27, 24);
            this.color2PictureBox.TabIndex = 18;
            this.color2PictureBox.TabStop = false;
            this.color2PictureBox.Click += new System.EventHandler(this.color2PictureBox_Click);
            // 
            // color1PictureBox
            // 
            this.color1PictureBox.BackColor = System.Drawing.Color.White;
            this.color1PictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.color1PictureBox.Location = new System.Drawing.Point(71, 71);
            this.color1PictureBox.Margin = new System.Windows.Forms.Padding(4);
            this.color1PictureBox.Name = "color1PictureBox";
            this.color1PictureBox.Size = new System.Drawing.Size(27, 24);
            this.color1PictureBox.TabIndex = 19;
            this.color1PictureBox.TabStop = false;
            this.color1PictureBox.Click += new System.EventHandler(this.color1PictureBox_Click);
            // 
            // patternSquaresXTextBox
            // 
            this.patternSquaresXTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.patternSquaresXTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.patternSquaresXTextBox.Location = new System.Drawing.Point(391, 72);
            this.patternSquaresXTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.patternSquaresXTextBox.Name = "patternSquaresXTextBox";
            this.patternSquaresXTextBox.Size = new System.Drawing.Size(35, 22);
            this.patternSquaresXTextBox.TabIndex = 16;
            this.patternSquaresXTextBox.Click += new System.EventHandler(this.patternSquaresXTextBox_Click);
            this.patternSquaresXTextBox.TextChanged += new System.EventHandler(this.patternSquaresXTextBox_TextChanged);
            // 
            // starLabel2
            // 
            this.starLabel2.AutoSize = true;
            this.starLabel2.Location = new System.Drawing.Point(430, 76);
            this.starLabel2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.starLabel2.Name = "starLabel2";
            this.starLabel2.Size = new System.Drawing.Size(11, 13);
            this.starLabel2.TabIndex = 28;
            this.starLabel2.Text = "*";
            // 
            // patternLabel
            // 
            this.patternLabel.AutoSize = true;
            this.patternLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.patternLabel.Location = new System.Drawing.Point(284, 76);
            this.patternLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.patternLabel.Name = "patternLabel";
            this.patternLabel.Size = new System.Drawing.Size(102, 16);
            this.patternLabel.TabIndex = 29;
            this.patternLabel.Text = "Pattern squares";
            // 
            // patternSquaresYTextBox
            // 
            this.patternSquaresYTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.patternSquaresYTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.patternSquaresYTextBox.Location = new System.Drawing.Point(448, 72);
            this.patternSquaresYTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.patternSquaresYTextBox.Name = "patternSquaresYTextBox";
            this.patternSquaresYTextBox.Size = new System.Drawing.Size(37, 22);
            this.patternSquaresYTextBox.TabIndex = 17;
            this.patternSquaresYTextBox.Click += new System.EventHandler(this.patternSquaresYTextBox_Click);
            this.patternSquaresYTextBox.TextChanged += new System.EventHandler(this.patternSquaresYTextBox_TextChanged);
            // 
            // timer
            // 
            this.timer.Enabled = true;
            this.timer.Interval = 300;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // color6PictureBox
            // 
            this.color6PictureBox.BackColor = System.Drawing.Color.Yellow;
            this.color6PictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.color6PictureBox.Enabled = false;
            this.color6PictureBox.Location = new System.Drawing.Point(328, 103);
            this.color6PictureBox.Margin = new System.Windows.Forms.Padding(4);
            this.color6PictureBox.Name = "color6PictureBox";
            this.color6PictureBox.Size = new System.Drawing.Size(27, 24);
            this.color6PictureBox.TabIndex = 32;
            this.color6PictureBox.TabStop = false;
            this.color6PictureBox.Click += new System.EventHandler(this.color6PictureBox_Click);
            // 
            // color5PictureBox
            // 
            this.color5PictureBox.BackColor = System.Drawing.Color.Blue;
            this.color5PictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.color5PictureBox.Enabled = false;
            this.color5PictureBox.Location = new System.Drawing.Point(328, 71);
            this.color5PictureBox.Margin = new System.Windows.Forms.Padding(4);
            this.color5PictureBox.Name = "color5PictureBox";
            this.color5PictureBox.Size = new System.Drawing.Size(27, 24);
            this.color5PictureBox.TabIndex = 33;
            this.color5PictureBox.TabStop = false;
            this.color5PictureBox.Click += new System.EventHandler(this.color5PictureBox_Click);
            // 
            // color4PictureBox
            // 
            this.color4PictureBox.BackColor = System.Drawing.Color.Green;
            this.color4PictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.color4PictureBox.Enabled = false;
            this.color4PictureBox.Location = new System.Drawing.Point(199, 102);
            this.color4PictureBox.Margin = new System.Windows.Forms.Padding(4);
            this.color4PictureBox.Name = "color4PictureBox";
            this.color4PictureBox.Size = new System.Drawing.Size(27, 24);
            this.color4PictureBox.TabIndex = 34;
            this.color4PictureBox.TabStop = false;
            this.color4PictureBox.Click += new System.EventHandler(this.color4PictureBox_Click);
            // 
            // color3PictureBox
            // 
            this.color3PictureBox.BackColor = System.Drawing.Color.Red;
            this.color3PictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.color3PictureBox.Enabled = false;
            this.color3PictureBox.Location = new System.Drawing.Point(199, 72);
            this.color3PictureBox.Margin = new System.Windows.Forms.Padding(4);
            this.color3PictureBox.Name = "color3PictureBox";
            this.color3PictureBox.Size = new System.Drawing.Size(27, 24);
            this.color3PictureBox.TabIndex = 35;
            this.color3PictureBox.TabStop = false;
            this.color3PictureBox.Click += new System.EventHandler(this.color3PictureBox_Click);
            // 
            // color3CheckBox
            // 
            this.color3CheckBox.AutoSize = true;
            this.color3CheckBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.color3CheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.color3CheckBox.Location = new System.Drawing.Point(171, 78);
            this.color3CheckBox.Margin = new System.Windows.Forms.Padding(4);
            this.color3CheckBox.Name = "color3CheckBox";
            this.color3CheckBox.Size = new System.Drawing.Size(12, 11);
            this.color3CheckBox.TabIndex = 6;
            this.color3CheckBox.UseVisualStyleBackColor = true;
            this.color3CheckBox.CheckedChanged += new System.EventHandler(this.color3CheckBox_CheckedChanged);
            // 
            // color4CheckBox
            // 
            this.color4CheckBox.AutoSize = true;
            this.color4CheckBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.color4CheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.color4CheckBox.Location = new System.Drawing.Point(171, 108);
            this.color4CheckBox.Margin = new System.Windows.Forms.Padding(4);
            this.color4CheckBox.Name = "color4CheckBox";
            this.color4CheckBox.Size = new System.Drawing.Size(12, 11);
            this.color4CheckBox.TabIndex = 7;
            this.color4CheckBox.UseVisualStyleBackColor = true;
            this.color4CheckBox.CheckedChanged += new System.EventHandler(this.color4CheckBox_CheckedChanged);
            // 
            // color5CheckBox
            // 
            this.color5CheckBox.AutoSize = true;
            this.color5CheckBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.color5CheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.color5CheckBox.Location = new System.Drawing.Point(302, 77);
            this.color5CheckBox.Margin = new System.Windows.Forms.Padding(4);
            this.color5CheckBox.Name = "color5CheckBox";
            this.color5CheckBox.Size = new System.Drawing.Size(12, 11);
            this.color5CheckBox.TabIndex = 8;
            this.color5CheckBox.UseVisualStyleBackColor = true;
            this.color5CheckBox.CheckedChanged += new System.EventHandler(this.color5CheckBox_CheckedChanged);
            // 
            // color6CheckBox
            // 
            this.color6CheckBox.AutoSize = true;
            this.color6CheckBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.color6CheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.color6CheckBox.Location = new System.Drawing.Point(302, 109);
            this.color6CheckBox.Margin = new System.Windows.Forms.Padding(4);
            this.color6CheckBox.Name = "color6CheckBox";
            this.color6CheckBox.Size = new System.Drawing.Size(12, 11);
            this.color6CheckBox.TabIndex = 9;
            this.color6CheckBox.UseVisualStyleBackColor = true;
            this.color6CheckBox.CheckedChanged += new System.EventHandler(this.color6CheckBox_CheckedChanged);
            // 
            // displayXDescriptionLabel
            // 
            this.displayXDescriptionLabel.AutoSize = true;
            this.displayXDescriptionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayXDescriptionLabel.Location = new System.Drawing.Point(214, 52);
            this.displayXDescriptionLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.displayXDescriptionLabel.Name = "displayXDescriptionLabel";
            this.displayXDescriptionLabel.Size = new System.Drawing.Size(68, 16);
            this.displayXDescriptionLabel.TabIndex = 40;
            this.displayXDescriptionLabel.Text = "Display X:";
            // 
            // displayYDescriptionLabel
            // 
            this.displayYDescriptionLabel.AutoSize = true;
            this.displayYDescriptionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayYDescriptionLabel.Location = new System.Drawing.Point(359, 52);
            this.displayYDescriptionLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.displayYDescriptionLabel.Name = "displayYDescriptionLabel";
            this.displayYDescriptionLabel.Size = new System.Drawing.Size(69, 16);
            this.displayYDescriptionLabel.TabIndex = 41;
            this.displayYDescriptionLabel.Text = "Display Y:";
            // 
            // numberTrialsTextBox
            // 
            this.numberTrialsTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numberTrialsTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numberTrialsTextBox.Location = new System.Drawing.Point(127, 19);
            this.numberTrialsTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.numberTrialsTextBox.Name = "numberTrialsTextBox";
            this.numberTrialsTextBox.Size = new System.Drawing.Size(59, 22);
            this.numberTrialsTextBox.TabIndex = 1;
            // 
            // numberTrialsLabel
            // 
            this.numberTrialsLabel.AutoSize = true;
            this.numberTrialsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numberTrialsLabel.Location = new System.Drawing.Point(9, 21);
            this.numberTrialsLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.numberTrialsLabel.Name = "numberTrialsLabel";
            this.numberTrialsLabel.Size = new System.Drawing.Size(110, 16);
            this.numberTrialsLabel.TabIndex = 45;
            this.numberTrialsLabel.Text = "Number of Trials:";
            // 
            // nameTrialsLabel
            // 
            this.nameTrialsLabel.AutoSize = true;
            this.nameTrialsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameTrialsLabel.Location = new System.Drawing.Point(197, 21);
            this.nameTrialsLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.nameTrialsLabel.Name = "nameTrialsLabel";
            this.nameTrialsLabel.Size = new System.Drawing.Size(128, 16);
            this.nameTrialsLabel.TabIndex = 46;
            this.nameTrialsLabel.Text = "Name of Trial block:";
            // 
            // nameTrialsTextBox
            // 
            this.nameTrialsTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nameTrialsTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameTrialsTextBox.Location = new System.Drawing.Point(329, 19);
            this.nameTrialsTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.nameTrialsTextBox.Name = "nameTrialsTextBox";
            this.nameTrialsTextBox.Size = new System.Drawing.Size(161, 22);
            this.nameTrialsTextBox.TabIndex = 2;
            // 
            // displayXTextBox
            // 
            this.displayXTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.displayXTextBox.Enabled = false;
            this.displayXTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayXTextBox.Location = new System.Drawing.Point(290, 50);
            this.displayXTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.displayXTextBox.Name = "displayXTextBox";
            this.displayXTextBox.Size = new System.Drawing.Size(61, 22);
            this.displayXTextBox.TabIndex = 4;
            // 
            // displayYTextBox
            // 
            this.displayYTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.displayYTextBox.Enabled = false;
            this.displayYTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayYTextBox.Location = new System.Drawing.Point(434, 50);
            this.displayYTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.displayYTextBox.Name = "displayYTextBox";
            this.displayYTextBox.Size = new System.Drawing.Size(56, 22);
            this.displayYTextBox.TabIndex = 5;
            // 
            // color3Label
            // 
            this.color3Label.AutoSize = true;
            this.color3Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.color3Label.Location = new System.Drawing.Point(111, 75);
            this.color3Label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.color3Label.Name = "color3Label";
            this.color3Label.Size = new System.Drawing.Size(50, 16);
            this.color3Label.TabIndex = 50;
            this.color3Label.Text = "Color 3";
            // 
            // color4Label
            // 
            this.color4Label.AutoSize = true;
            this.color4Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.color4Label.Location = new System.Drawing.Point(112, 106);
            this.color4Label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.color4Label.Name = "color4Label";
            this.color4Label.Size = new System.Drawing.Size(50, 16);
            this.color4Label.TabIndex = 51;
            this.color4Label.Text = "Color 4";
            // 
            // color5Label
            // 
            this.color5Label.AutoSize = true;
            this.color5Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.color5Label.Location = new System.Drawing.Point(241, 74);
            this.color5Label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.color5Label.Name = "color5Label";
            this.color5Label.Size = new System.Drawing.Size(50, 16);
            this.color5Label.TabIndex = 52;
            this.color5Label.Text = "Color 5";
            // 
            // color6Label
            // 
            this.color6Label.AutoSize = true;
            this.color6Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.color6Label.Location = new System.Drawing.Point(241, 106);
            this.color6Label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.color6Label.Name = "color6Label";
            this.color6Label.Size = new System.Drawing.Size(50, 16);
            this.color6Label.TabIndex = 53;
            this.color6Label.Text = "Color 6";
            // 
            // maxDurationTextBox
            // 
            this.maxDurationTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.maxDurationTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maxDurationTextBox.Location = new System.Drawing.Point(127, 50);
            this.maxDurationTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.maxDurationTextBox.Name = "maxDurationTextBox";
            this.maxDurationTextBox.Size = new System.Drawing.Size(59, 22);
            this.maxDurationTextBox.TabIndex = 3;
            // 
            // maxDurationLabel
            // 
            this.maxDurationLabel.AutoSize = true;
            this.maxDurationLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maxDurationLabel.Location = new System.Drawing.Point(9, 52);
            this.maxDurationLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.maxDurationLabel.Name = "maxDurationLabel";
            this.maxDurationLabel.Size = new System.Drawing.Size(110, 16);
            this.maxDurationLabel.TabIndex = 55;
            this.maxDurationLabel.Text = "Max duration in s:";
            // 
            // sameScreenCheckBox
            // 
            this.sameScreenCheckBox.AutoSize = true;
            this.sameScreenCheckBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sameScreenCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sameScreenCheckBox.Location = new System.Drawing.Point(15, 25);
            this.sameScreenCheckBox.Margin = new System.Windows.Forms.Padding(4);
            this.sameScreenCheckBox.Name = "sameScreenCheckBox";
            this.sameScreenCheckBox.Size = new System.Drawing.Size(235, 20);
            this.sameScreenCheckBox.TabIndex = 18;
            this.sameScreenCheckBox.Text = "Pattern and Picture on same screen";
            this.sameScreenCheckBox.UseVisualStyleBackColor = true;
            this.sameScreenCheckBox.CheckedChanged += new System.EventHandler(this.sameScreenCheckBox_CheckedChanged);
            // 
            // OKButton
            // 
            this.OKButton.Enabled = false;
            this.OKButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.OKButton.Image = global::BMPBuilder.Properties.Resources.yes;
            this.OKButton.Location = new System.Drawing.Point(430, 458);
            this.OKButton.Margin = new System.Windows.Forms.Padding(4);
            this.OKButton.Name = "OKButton";
            this.OKButton.Size = new System.Drawing.Size(48, 48);
            this.OKButton.TabIndex = 57;
            this.OKButton.UseVisualStyleBackColor = true;
            this.OKButton.Click += new System.EventHandler(this.OKButton_Click);
            // 
            // cancelButton
            // 
            this.cancelButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cancelButton.Image = global::BMPBuilder.Properties.Resources.no;
            this.cancelButton.Location = new System.Drawing.Point(374, 458);
            this.cancelButton.Margin = new System.Windows.Forms.Padding(4);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(48, 48);
            this.cancelButton.TabIndex = 58;
            this.cancelButton.UseVisualStyleBackColor = true;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // quadraticCheckBox
            // 
            this.quadraticCheckBox.AutoSize = true;
            this.quadraticCheckBox.Checked = true;
            this.quadraticCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.quadraticCheckBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.quadraticCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quadraticCheckBox.Location = new System.Drawing.Point(12, 43);
            this.quadraticCheckBox.Margin = new System.Windows.Forms.Padding(4);
            this.quadraticCheckBox.Name = "quadraticCheckBox";
            this.quadraticCheckBox.Size = new System.Drawing.Size(82, 20);
            this.quadraticCheckBox.TabIndex = 11;
            this.quadraticCheckBox.Text = "Quadratic";
            this.quadraticCheckBox.UseVisualStyleBackColor = true;
            this.quadraticCheckBox.CheckedChanged += new System.EventHandler(this.quadraticCheckBox_CheckedChanged);
            // 
            // displayTimeTextBox
            // 
            this.displayTimeTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.displayTimeTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayTimeTextBox.Location = new System.Drawing.Point(176, 58);
            this.displayTimeTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.displayTimeTextBox.Name = "displayTimeTextBox";
            this.displayTimeTextBox.Size = new System.Drawing.Size(54, 22);
            this.displayTimeTextBox.TabIndex = 19;
            // 
            // displayTimeLabel
            // 
            this.displayTimeLabel.AutoSize = true;
            this.displayTimeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayTimeLabel.Location = new System.Drawing.Point(47, 61);
            this.displayTimeLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.displayTimeLabel.Name = "displayTimeLabel";
            this.displayTimeLabel.Size = new System.Drawing.Size(116, 16);
            this.displayTimeLabel.TabIndex = 61;
            this.displayTimeLabel.Text = "Display pattern for";
            // 
            // secLabel
            // 
            this.secLabel.AutoSize = true;
            this.secLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.secLabel.Location = new System.Drawing.Point(238, 62);
            this.secLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.secLabel.Name = "secLabel";
            this.secLabel.Size = new System.Drawing.Size(33, 16);
            this.secLabel.TabIndex = 62;
            this.secLabel.Text = "sec.";
            // 
            // displayTime2TextBox
            // 
            this.displayTime2TextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.displayTime2TextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayTime2TextBox.Location = new System.Drawing.Point(176, 84);
            this.displayTime2TextBox.Margin = new System.Windows.Forms.Padding(4);
            this.displayTime2TextBox.Name = "displayTime2TextBox";
            this.displayTime2TextBox.Size = new System.Drawing.Size(55, 22);
            this.displayTime2TextBox.TabIndex = 20;
            // 
            // displayTime2Label
            // 
            this.displayTime2Label.AutoSize = true;
            this.displayTime2Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayTime2Label.Location = new System.Drawing.Point(110, 88);
            this.displayTime2Label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.displayTime2Label.Name = "displayTime2Label";
            this.displayTime2Label.Size = new System.Drawing.Size(54, 16);
            this.displayTime2Label.TabIndex = 64;
            this.displayTime2Label.Text = "trials for";
            // 
            // borderColorLabel
            // 
            this.borderColorLabel.AutoSize = true;
            this.borderColorLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.borderColorLabel.Location = new System.Drawing.Point(371, 22);
            this.borderColorLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.borderColorLabel.Name = "borderColorLabel";
            this.borderColorLabel.Size = new System.Drawing.Size(84, 16);
            this.borderColorLabel.TabIndex = 65;
            this.borderColorLabel.Text = "Border Color";
            // 
            // borderColorPictureBox
            // 
            this.borderColorPictureBox.BackColor = System.Drawing.Color.Black;
            this.borderColorPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.borderColorPictureBox.Location = new System.Drawing.Point(463, 19);
            this.borderColorPictureBox.Margin = new System.Windows.Forms.Padding(4);
            this.borderColorPictureBox.Name = "borderColorPictureBox";
            this.borderColorPictureBox.Size = new System.Drawing.Size(27, 24);
            this.borderColorPictureBox.TabIndex = 66;
            this.borderColorPictureBox.TabStop = false;
            this.borderColorPictureBox.Click += new System.EventHandler(this.borderColorPictureBox_Click);
            // 
            // conclusionColorLabel
            // 
            this.conclusionColorLabel.AutoSize = true;
            this.conclusionColorLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.conclusionColorLabel.Location = new System.Drawing.Point(189, 22);
            this.conclusionColorLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.conclusionColorLabel.Name = "conclusionColorLabel";
            this.conclusionColorLabel.Size = new System.Drawing.Size(109, 16);
            this.conclusionColorLabel.TabIndex = 67;
            this.conclusionColorLabel.Text = "Conclusion Color";
            // 
            // conclusionColorPictureBox
            // 
            this.conclusionColorPictureBox.BackColor = System.Drawing.Color.Red;
            this.conclusionColorPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.conclusionColorPictureBox.Location = new System.Drawing.Point(306, 18);
            this.conclusionColorPictureBox.Margin = new System.Windows.Forms.Padding(4);
            this.conclusionColorPictureBox.Name = "conclusionColorPictureBox";
            this.conclusionColorPictureBox.Size = new System.Drawing.Size(27, 24);
            this.conclusionColorPictureBox.TabIndex = 68;
            this.conclusionColorPictureBox.TabStop = false;
            this.conclusionColorPictureBox.Click += new System.EventHandler(this.conclusionColorPictureBox_Click);
            // 
            // displayTime3Label
            // 
            this.displayTime3Label.AutoSize = true;
            this.displayTime3Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayTime3Label.Location = new System.Drawing.Point(14, 88);
            this.displayTime3Label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.displayTime3Label.Name = "displayTime3Label";
            this.displayTime3Label.Size = new System.Drawing.Size(60, 16);
            this.displayTime3Label.TabIndex = 69;
            this.displayTime3Label.Text = "and after";
            // 
            // displayTimeTrialNumberLabel
            // 
            this.displayTimeTrialNumberLabel.AutoSize = true;
            this.displayTimeTrialNumberLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayTimeTrialNumberLabel.Location = new System.Drawing.Point(88, 88);
            this.displayTimeTrialNumberLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.displayTimeTrialNumberLabel.Name = "displayTimeTrialNumberLabel";
            this.displayTimeTrialNumberLabel.Size = new System.Drawing.Size(15, 16);
            this.displayTimeTrialNumberLabel.TabIndex = 70;
            this.displayTimeTrialNumberLabel.Text = "0";
            // 
            // secLabel2
            // 
            this.secLabel2.AutoSize = true;
            this.secLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.secLabel2.Location = new System.Drawing.Point(239, 87);
            this.secLabel2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.secLabel2.Name = "secLabel2";
            this.secLabel2.Size = new System.Drawing.Size(33, 16);
            this.secLabel2.TabIndex = 71;
            this.secLabel2.Text = "sec.";
            // 
            // borderSizeDescriptionLabel
            // 
            this.borderSizeDescriptionLabel.AutoSize = true;
            this.borderSizeDescriptionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.borderSizeDescriptionLabel.Location = new System.Drawing.Point(376, 54);
            this.borderSizeDescriptionLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.borderSizeDescriptionLabel.Name = "borderSizeDescriptionLabel";
            this.borderSizeDescriptionLabel.Size = new System.Drawing.Size(81, 16);
            this.borderSizeDescriptionLabel.TabIndex = 72;
            this.borderSizeDescriptionLabel.Text = "Border Size:";
            // 
            // borderSizeLabel
            // 
            this.borderSizeLabel.AutoSize = true;
            this.borderSizeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.borderSizeLabel.Location = new System.Drawing.Point(470, 54);
            this.borderSizeLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.borderSizeLabel.Name = "borderSizeLabel";
            this.borderSizeLabel.Size = new System.Drawing.Size(15, 16);
            this.borderSizeLabel.TabIndex = 73;
            this.borderSizeLabel.Text = "0";
            // 
            // colorGroupBox
            // 
            this.colorGroupBox.Controls.Add(this.borderSizeLabel);
            this.colorGroupBox.Controls.Add(this.borderSizeDescriptionLabel);
            this.colorGroupBox.Controls.Add(this.conclusionColorPictureBox);
            this.colorGroupBox.Controls.Add(this.conclusionColorLabel);
            this.colorGroupBox.Controls.Add(this.borderColorPictureBox);
            this.colorGroupBox.Controls.Add(this.borderColorLabel);
            this.colorGroupBox.Controls.Add(this.color6Label);
            this.colorGroupBox.Controls.Add(this.color5Label);
            this.colorGroupBox.Controls.Add(this.color4Label);
            this.colorGroupBox.Controls.Add(this.color3Label);
            this.colorGroupBox.Controls.Add(this.color6CheckBox);
            this.colorGroupBox.Controls.Add(this.color5CheckBox);
            this.colorGroupBox.Controls.Add(this.color4CheckBox);
            this.colorGroupBox.Controls.Add(this.color3CheckBox);
            this.colorGroupBox.Controls.Add(this.color3PictureBox);
            this.colorGroupBox.Controls.Add(this.color4PictureBox);
            this.colorGroupBox.Controls.Add(this.color5PictureBox);
            this.colorGroupBox.Controls.Add(this.color6PictureBox);
            this.colorGroupBox.Controls.Add(this.color1PictureBox);
            this.colorGroupBox.Controls.Add(this.color2PictureBox);
            this.colorGroupBox.Controls.Add(this.color2Label);
            this.colorGroupBox.Controls.Add(this.color1Label);
            this.colorGroupBox.Controls.Add(this.backgroundColorLabel);
            this.colorGroupBox.Controls.Add(this.backgroundColorPictureBox);
            this.colorGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colorGroupBox.Location = new System.Drawing.Point(12, 96);
            this.colorGroupBox.Name = "colorGroupBox";
            this.colorGroupBox.Size = new System.Drawing.Size(516, 141);
            this.colorGroupBox.TabIndex = 74;
            this.colorGroupBox.TabStop = false;
            this.colorGroupBox.Text = "Color Definitions";
            // 
            // trialGroupBox
            // 
            this.trialGroupBox.Controls.Add(this.maxDurationLabel);
            this.trialGroupBox.Controls.Add(this.maxDurationTextBox);
            this.trialGroupBox.Controls.Add(this.displayYTextBox);
            this.trialGroupBox.Controls.Add(this.displayXTextBox);
            this.trialGroupBox.Controls.Add(this.nameTrialsTextBox);
            this.trialGroupBox.Controls.Add(this.nameTrialsLabel);
            this.trialGroupBox.Controls.Add(this.numberTrialsLabel);
            this.trialGroupBox.Controls.Add(this.numberTrialsTextBox);
            this.trialGroupBox.Controls.Add(this.displayYDescriptionLabel);
            this.trialGroupBox.Controls.Add(this.displayXDescriptionLabel);
            this.trialGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trialGroupBox.Location = new System.Drawing.Point(12, 7);
            this.trialGroupBox.Name = "trialGroupBox";
            this.trialGroupBox.Size = new System.Drawing.Size(516, 83);
            this.trialGroupBox.TabIndex = 75;
            this.trialGroupBox.TabStop = false;
            this.trialGroupBox.Text = "Trial definitions";
            // 
            // squareGroupBox
            // 
            this.squareGroupBox.Controls.Add(this.quadraticCheckBox);
            this.squareGroupBox.Controls.Add(this.patternSquaresYTextBox);
            this.squareGroupBox.Controls.Add(this.patternLabel);
            this.squareGroupBox.Controls.Add(this.starLabel2);
            this.squareGroupBox.Controls.Add(this.patternSquaresXTextBox);
            this.squareGroupBox.Controls.Add(this.fullScreenCheckBox);
            this.squareGroupBox.Controls.Add(this.starLabel1);
            this.squareGroupBox.Controls.Add(this.sizeYTextBox);
            this.squareGroupBox.Controls.Add(this.sizeXTextBox);
            this.squareGroupBox.Controls.Add(this.sizeXYLabel);
            this.squareGroupBox.Controls.Add(this.squaresYTextBox);
            this.squareGroupBox.Controls.Add(this.squareYLabel);
            this.squareGroupBox.Controls.Add(this.squaresXLabel);
            this.squareGroupBox.Controls.Add(this.squaresXTextBox);
            this.squareGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.squareGroupBox.Location = new System.Drawing.Point(12, 243);
            this.squareGroupBox.Name = "squareGroupBox";
            this.squareGroupBox.Size = new System.Drawing.Size(516, 112);
            this.squareGroupBox.TabIndex = 76;
            this.squareGroupBox.TabStop = false;
            this.squareGroupBox.Text = "Square defintions";
            // 
            // patternGroupBox
            // 
            this.patternGroupBox.Controls.Add(this.secLabel3);
            this.patternGroupBox.Controls.Add(this.displayTimeTrialNumber2Label);
            this.patternGroupBox.Controls.Add(this.displayTime4Label);
            this.patternGroupBox.Controls.Add(this.displayTime5Label);
            this.patternGroupBox.Controls.Add(this.displayTime3TextBox);
            this.patternGroupBox.Controls.Add(this.secLabel2);
            this.patternGroupBox.Controls.Add(this.displayTimeTrialNumberLabel);
            this.patternGroupBox.Controls.Add(this.displayTime3Label);
            this.patternGroupBox.Controls.Add(this.displayTime2Label);
            this.patternGroupBox.Controls.Add(this.displayTime2TextBox);
            this.patternGroupBox.Controls.Add(this.secLabel);
            this.patternGroupBox.Controls.Add(this.displayTimeLabel);
            this.patternGroupBox.Controls.Add(this.displayTimeTextBox);
            this.patternGroupBox.Controls.Add(this.sameScreenCheckBox);
            this.patternGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.patternGroupBox.Location = new System.Drawing.Point(12, 362);
            this.patternGroupBox.Name = "patternGroupBox";
            this.patternGroupBox.Size = new System.Drawing.Size(302, 139);
            this.patternGroupBox.TabIndex = 77;
            this.patternGroupBox.TabStop = false;
            this.patternGroupBox.Text = "Pattern definitions";
            // 
            // secLabel3
            // 
            this.secLabel3.AutoSize = true;
            this.secLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.secLabel3.Location = new System.Drawing.Point(239, 113);
            this.secLabel3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.secLabel3.Name = "secLabel3";
            this.secLabel3.Size = new System.Drawing.Size(33, 16);
            this.secLabel3.TabIndex = 76;
            this.secLabel3.Text = "sec.";
            // 
            // displayTimeTrialNumber2Label
            // 
            this.displayTimeTrialNumber2Label.AutoSize = true;
            this.displayTimeTrialNumber2Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayTimeTrialNumber2Label.Location = new System.Drawing.Point(88, 114);
            this.displayTimeTrialNumber2Label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.displayTimeTrialNumber2Label.Name = "displayTimeTrialNumber2Label";
            this.displayTimeTrialNumber2Label.Size = new System.Drawing.Size(15, 16);
            this.displayTimeTrialNumber2Label.TabIndex = 75;
            this.displayTimeTrialNumber2Label.Text = "0";
            // 
            // displayTime4Label
            // 
            this.displayTime4Label.AutoSize = true;
            this.displayTime4Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayTime4Label.Location = new System.Drawing.Point(14, 114);
            this.displayTime4Label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.displayTime4Label.Name = "displayTime4Label";
            this.displayTime4Label.Size = new System.Drawing.Size(60, 16);
            this.displayTime4Label.TabIndex = 74;
            this.displayTime4Label.Text = "and after";
            // 
            // displayTime5Label
            // 
            this.displayTime5Label.AutoSize = true;
            this.displayTime5Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayTime5Label.Location = new System.Drawing.Point(110, 114);
            this.displayTime5Label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.displayTime5Label.Name = "displayTime5Label";
            this.displayTime5Label.Size = new System.Drawing.Size(54, 16);
            this.displayTime5Label.TabIndex = 73;
            this.displayTime5Label.Text = "trials for";
            // 
            // displayTime3TextBox
            // 
            this.displayTime3TextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.displayTime3TextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayTime3TextBox.Location = new System.Drawing.Point(176, 110);
            this.displayTime3TextBox.Margin = new System.Windows.Forms.Padding(4);
            this.displayTime3TextBox.Name = "displayTime3TextBox";
            this.displayTime3TextBox.Size = new System.Drawing.Size(55, 22);
            this.displayTime3TextBox.TabIndex = 72;
            // 
            // TrialForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(538, 513);
            this.Controls.Add(this.patternGroupBox);
            this.Controls.Add(this.squareGroupBox);
            this.Controls.Add(this.trialGroupBox);
            this.Controls.Add(this.colorGroupBox);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.OKButton);
            this.Controls.Add(this.previewButton);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "TrialForm";
            this.Text = "Trial Data";
            this.Load += new System.EventHandler(this.TrialForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.backgroundColorPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.color2PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.color1PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.color6PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.color5PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.color4PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.color3PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.borderColorPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.conclusionColorPictureBox)).EndInit();
            this.colorGroupBox.ResumeLayout(false);
            this.colorGroupBox.PerformLayout();
            this.trialGroupBox.ResumeLayout(false);
            this.trialGroupBox.PerformLayout();
            this.squareGroupBox.ResumeLayout(false);
            this.squareGroupBox.PerformLayout();
            this.patternGroupBox.ResumeLayout(false);
            this.patternGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox squaresXTextBox;
        private System.Windows.Forms.Label squaresXLabel;
        private System.Windows.Forms.Label squareYLabel;
        private System.Windows.Forms.TextBox squaresYTextBox;
        private System.Windows.Forms.Label sizeXYLabel;
        private System.Windows.Forms.TextBox sizeXTextBox;
        private System.Windows.Forms.TextBox sizeYTextBox;
        private System.Windows.Forms.Label starLabel1;
        private System.Windows.Forms.Button previewButton;
        private System.Windows.Forms.CheckBox fullScreenCheckBox;
        private System.Windows.Forms.PictureBox backgroundColorPictureBox;
        private System.Windows.Forms.Label backgroundColorLabel;
        private System.Windows.Forms.ColorDialog backgroundColorDialog;
        private System.Windows.Forms.ColorDialog color1Dialog;
        private System.Windows.Forms.ColorDialog color2Dialog;
        private System.Windows.Forms.Label color1Label;
        private System.Windows.Forms.Label color2Label;
        private System.Windows.Forms.PictureBox color2PictureBox;
        private System.Windows.Forms.PictureBox color1PictureBox;
        private System.Windows.Forms.TextBox patternSquaresXTextBox;
        private System.Windows.Forms.Label starLabel2;
        private System.Windows.Forms.Label patternLabel;
        private System.Windows.Forms.TextBox patternSquaresYTextBox;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.PictureBox color6PictureBox;
        private System.Windows.Forms.PictureBox color5PictureBox;
        private System.Windows.Forms.PictureBox color4PictureBox;
        private System.Windows.Forms.PictureBox color3PictureBox;
        private System.Windows.Forms.CheckBox color3CheckBox;
        private System.Windows.Forms.CheckBox color4CheckBox;
        private System.Windows.Forms.CheckBox color5CheckBox;
        private System.Windows.Forms.CheckBox color6CheckBox;
        private System.Windows.Forms.ColorDialog color3Dialog;
        private System.Windows.Forms.ColorDialog color4Dialog;
        private System.Windows.Forms.ColorDialog color5Dialog;
        private System.Windows.Forms.ColorDialog color6Dialog;
        private System.Windows.Forms.Label displayXDescriptionLabel;
        private System.Windows.Forms.Label displayYDescriptionLabel;
        private System.Windows.Forms.TextBox numberTrialsTextBox;
        private System.Windows.Forms.Label numberTrialsLabel;
        private System.Windows.Forms.Label nameTrialsLabel;
        private System.Windows.Forms.TextBox nameTrialsTextBox;
        private System.Windows.Forms.TextBox displayXTextBox;
        private System.Windows.Forms.TextBox displayYTextBox;
        private System.Windows.Forms.Label color3Label;
        private System.Windows.Forms.Label color4Label;
        private System.Windows.Forms.Label color5Label;
        private System.Windows.Forms.Label color6Label;
        private System.Windows.Forms.TextBox maxDurationTextBox;
        private System.Windows.Forms.Label maxDurationLabel;
        private System.Windows.Forms.CheckBox sameScreenCheckBox;
        private System.Windows.Forms.Button OKButton;
        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.CheckBox quadraticCheckBox;
        private System.Windows.Forms.TextBox displayTimeTextBox;
        private System.Windows.Forms.Label displayTimeLabel;
        private System.Windows.Forms.Label secLabel;
        private System.Windows.Forms.TextBox displayTime2TextBox;
        private System.Windows.Forms.Label displayTime2Label;
        private System.Windows.Forms.Label borderColorLabel;
        private System.Windows.Forms.PictureBox borderColorPictureBox;
        private System.Windows.Forms.ColorDialog borderColorDialog;
        private System.Windows.Forms.ColorDialog conclusionColorDialog;
        private System.Windows.Forms.Label conclusionColorLabel;
        private System.Windows.Forms.PictureBox conclusionColorPictureBox;
        private System.Windows.Forms.Label displayTime3Label;
        private System.Windows.Forms.Label displayTimeTrialNumberLabel;
        private System.Windows.Forms.Label secLabel2;
        private System.Windows.Forms.Label borderSizeDescriptionLabel;
        private System.Windows.Forms.Label borderSizeLabel;
        private System.Windows.Forms.GroupBox colorGroupBox;
        private System.Windows.Forms.GroupBox trialGroupBox;
        private System.Windows.Forms.GroupBox squareGroupBox;
        private System.Windows.Forms.GroupBox patternGroupBox;
        private System.Windows.Forms.Label secLabel3;
        private System.Windows.Forms.Label displayTimeTrialNumber2Label;
        private System.Windows.Forms.Label displayTime4Label;
        private System.Windows.Forms.Label displayTime5Label;
        private System.Windows.Forms.TextBox displayTime3TextBox;
    }
}

