using System;
using System.Collections.Generic;
using System.Text;

namespace BMPBuilder
{
    /// <summary>
    /// Class to store and handle all necessary information of a trial. All trial data which is need to generate a preview is stored 
    /// the linked PreviewData object. 
    /// </summary>
    /// <seealso cref="TrialData"/>, <seealso cref="ExperimentData"/>
    [Serializable]
    public class TrialData
    {
        private PreviewData preview = null;

        /// <summary>
        /// Gets or sets all trial information needed to generate a preview.
        /// </summary>
        /// <value>Preview Data</value>
        public PreviewData Preview
        {
            get { return preview; }
            set { preview = value; }
        }

        private int trialNumbers = 0;

        /// <summary>
        /// Gets or sets the number of trials.
        /// </summary>
        /// <value>The number of trials.</value>
        public int TrialNumbers
        {
            get { return trialNumbers; }
            set { trialNumbers = value; }
        }

        private string name = "";

        /// <summary>
        /// Gets or sets the name of the trial.
        /// </summary>
        /// <value>The name of the trial.</value>
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        private int duration = 0;

        /// <summary>
        /// Gets or sets the duration of the trial.
        /// </summary>
        /// <value>The duration of the trial.</value>
        public int Duration
        {
            get { return duration; }
            set { duration = value; }
        }




    

    }
}
