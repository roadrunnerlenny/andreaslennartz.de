using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace BMPBuilder
{
    /// <summary>
    /// Class to store and handle all necessary information of a trial which is needed to generate a preview of a trial.
    /// </summary>
    /// <seealso cref="TrialData"/>, <seealso cref="ExperimentData"/>
    [Serializable]
    public class PreviewData
    {
        private int squaresX = 0;

        /// <summary>
        /// Gets or sets the number of squares in horizontal direction in a trial.
        /// </summary>
        /// <value>The number of squares in horizontal direction in a trial.</value>
        public int SquaresX
        {
            get { return squaresX; }
            set { squaresX = value; }
        }
        private int squaresY = 0;

        /// <summary>
        /// Gets or sets the number of squares in vertical direction in a trial.
        /// </summary>
        /// <value>The number of squares in vertical direction in a trial.</value>
        public int SquaresY
        {
            get { return squaresY; }
            set { squaresY = value; }
        }
        private int sizeX = 0;

        /// <summary>
        /// Gets or sets the width of each square (in pixel).
        /// </summary>
        /// <value>The width of each square (in pixel).</value>
        public int SizeX
        {
            get { return sizeX; }
            set { sizeX = value; }
        }
        private int sizeY = 0;

        /// <summary>
        /// Gets or sets the height of each square (in pixel).
        /// </summary>
        /// <value>The height of each square (in pixel).</value>
        public int SizeY
        {
            get { return sizeY; }
            set { sizeY = value; }
        }
        private int patternSquaresX = 0;

        /// <summary>
        /// Gets or sets the number of squares in horizontal direction for the pattern.
        /// </summary>
        /// <value>The number of squares in horizontal direction for the pattern.</value>
        public int PatternSquaresX
        {
            get { return patternSquaresX; }
            set { patternSquaresX = value; }
        }
        private int patternSquaresY = 0;

        /// <summary>
        /// Gets or sets the number of squares in vertical direction for the pattern.
        /// </summary>
        /// <value>The number of squares in vertical direction for the pattern.</value>
        public int PatternSquaresY
        {
            get { return patternSquaresY; }
            set { patternSquaresY = value; }
        }

        private int displayX = Constants.DisplayX;

        /// <summary>
        /// Gets or sets the width of the display - should be the screen width (in pixel) of the experiment pc.
        /// </summary>
        /// <value>The width of the display - should be the screen width (in pixel) of the experiment pc.</value>
        public int DisplayX
        {
            get { return displayX; }
            set { displayX = value; }
        }

        private int displayY = Constants.DisplayY;

        /// <summary>
        /// Gets or sets the height of the display - should be the screen width (in pixel) of the experiment pc.
        /// </summary>
        /// <value>The height of the display - should be the screen width (in pixel) of the experiment pc.</value>
        public int DisplayY
        {
            get { return displayY; }
            set { displayY = value; }
        }

        private bool sameScreen = false;

        /// <summary>
        /// Gets or sets a value indicating whether the pattern and the picture are displayed on the same screen.
        /// </summary>
        /// <value><c>true</c> if pattern and picture are displayed on the same screen; otherwise, <c>false</c>.</value>
        public bool SameScreen
        {
            get { return sameScreen; }
            set { sameScreen = value; }
        }

        private int backgroundColor = (Color.White).ToArgb();

        /// <summary>
        /// Gets or sets the color of the background.
        /// </summary>
        /// <value>The color of the background.</value>
        public Color BackgroundColor
        {
            get { 
                return Color.FromArgb(backgroundColor); 
            }
            set { 
                Color givenColor = value; 
                backgroundColor = givenColor.ToArgb();
            }
        }

        private int borderColor = (Color.White).ToArgb();

        /// <summary>
        /// Gets or sets the color of the border.
        /// </summary>
        /// <value>The color of the border.</value>
        public Color BorderColor
        {
            get
            {
                return Color.FromArgb(borderColor);
            }
            set
            {
                Color givenColor = value;
                borderColor = givenColor.ToArgb();
            }
        }

        private int color1 = (Color.Black).ToArgb();

        /// <summary>
        /// Gets or sets the color 1.
        /// </summary>
        /// <value>The color 1.</value>
        public Color Color1
        {
            get
            {
                return Color.FromArgb(color1);
            }
            set
            {
                Color givenColor = value;
                color1 = givenColor.ToArgb();
            }
        }

        private int color2 = (Color.Black).ToArgb();

        /// <summary>
        /// Gets or sets the color 2.
        /// </summary>
        /// <value>The color 2.</value>
        public Color Color2
        {
            get
            {
                return Color.FromArgb(color2);
            }
            set
            {
                Color givenColor = value;
                color2 = givenColor.ToArgb();
            }
        }

        private int color3 = (Color.Red).ToArgb();

        /// <summary>
        /// Gets or sets the color 3.
        /// </summary>
        /// <value>The color 3.</value>
        public Color Color3
        {
            get
            {
                return Color.FromArgb(color3);
            }
            set
            {
                Color givenColor = value;
                color3 = givenColor.ToArgb();
            }
        }

        private bool color3Checked = false;

        /// <summary>
        /// Gets or sets a value indicating whether color 3 is activated.
        /// </summary>
        /// <value><c>true</c> if color 3 is activated.; otherwise, <c>false</c>.</value>
        public bool Color3Checked
        {
            get { return color3Checked; }
            set { color3Checked = value; }
        }

        private int color4 = (Color.Green).ToArgb();

        /// <summary>
        /// Gets or sets the color 4.
        /// </summary>
        /// <value>The color 4.</value>
        public Color Color4
        {
            get
            {
                return Color.FromArgb(color4);
            }
            set
            {
                Color givenColor = value;
                color4 = givenColor.ToArgb();
            }
        }

        private bool color4Checked = false;

        /// <summary>
        /// Gets or sets a value indicating whether color 4 is activated.
        /// </summary>
        /// <value><c>true</c> if color 4 is activated.; otherwise, <c>false</c>.</value>
        public bool Color4Checked
        {
            get { return color4Checked; }
            set { color4Checked = value; }
        }

        private int color5 = (Color.Blue).ToArgb();

        /// <summary>
        /// Gets or sets the color 5.
        /// </summary>
        /// <value>The color 5.</value>
        public Color Color5
        {
            get
            {
                return Color.FromArgb(color5);
            }
            set
            {
                Color givenColor = value;
                color5 = givenColor.ToArgb();
            }
        }

        private bool color5Checked = false;

        /// <summary>
        /// Gets or sets a value indicating whether color 5 is activated.
        /// </summary>
        /// <value><c>true</c> if color 5 is activated; otherwise, <c>false</c>.</value>
        public bool Color5Checked
        {
            get { return color5Checked; }
            set { color5Checked = value; }
        }

        private int color6 = (Color.Yellow).ToArgb();

        /// <summary>
        /// Gets or sets the color 6.
        /// </summary>
        /// <value>The color 6.</value>
        public Color Color6
        {
            get
            {
                return Color.FromArgb(color6);
            }
            set
            {
                Color givenColor = value;
                color6 = givenColor.ToArgb();
            }
        }

        private bool color6Checked = false;

        /// <summary>
        /// Gets or sets a value indicating whether color 6 is activated.
        /// </summary>
        /// <value><c>true</c> if color 6 is activated; otherwise, <c>false</c>.</value>
        public bool Color6Checked
        {
            get { return color6Checked; }
            set { color6Checked = value; }
        }

        private int conclusionColor = (Color.White).ToArgb();

        /// <summary>
        /// Gets or sets the color of the rectangular frame the marks the target pattern in the picture at the end of a trial.
        /// </summary>
        /// <value>The color of the rectange frame the marks the target pattern in the picture at the end of a trial.</value>
        public Color ConclusionColor
        {
            get
            {
                return Color.FromArgb(conclusionColor);
            }
            set
            {
                Color givenColor = value;
                conclusionColor = givenColor.ToArgb();
            }
        }

        private int patternDisplayTime = 0;

        /// <summary>
        /// Gets or sets the pattern display time for the first trials.
        /// </summary>
        /// <value>The pattern display time for the first trials.</value>
        public int PatternDisplayTime
        {
            get { return patternDisplayTime; }
            set { patternDisplayTime = value; }
        }

        private int patternDisplayTime2 = 0;

        /// <summary>
        /// Gets or sets the pattern display time after a specified number of trials.
        /// </summary>
        /// <value>The pattern display time after a specified number of trials.</value>
        public int PatternDisplayTime2
        {
            get { return patternDisplayTime2; }
            set { patternDisplayTime2 = value; }
        }

        private int patternDisplayTime3 = 0;

        /// <summary>
        /// Gets or sets the pattern display time after a specified number of trials.
        /// </summary>
        /// <value>The pattern display time after a specified number of trials.</value>
        public int PatternDisplayTime3
        {
            get { return patternDisplayTime3; }
            set { patternDisplayTime3 = value; }
        }




    }
}
