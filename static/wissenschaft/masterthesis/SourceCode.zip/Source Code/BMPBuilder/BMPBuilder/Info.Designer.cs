namespace BMPBuilder
{
    partial class Info
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Info));
            this.builderLabel = new System.Windows.Forms.Label();
            this.experimentLabel = new System.Windows.Forms.Label();
            this.analysisLabel = new System.Windows.Forms.Label();
            this.nameLabel = new System.Windows.Forms.Label();
            this.pictureBox = new System.Windows.Forms.PictureBox();
            this.thesisLabel = new System.Windows.Forms.Label();
            this.profLabel = new System.Windows.Forms.Label();
            this.name2Label = new System.Windows.Forms.Label();
            this.name3Label = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // builderLabel
            // 
            this.builderLabel.AutoSize = true;
            this.builderLabel.Location = new System.Drawing.Point(12, 20);
            this.builderLabel.Name = "builderLabel";
            this.builderLabel.Size = new System.Drawing.Size(82, 16);
            this.builderLabel.TabIndex = 0;
            this.builderLabel.Text = "BMP Builder";
            // 
            // experimentLabel
            // 
            this.experimentLabel.AutoSize = true;
            this.experimentLabel.Location = new System.Drawing.Point(109, 20);
            this.experimentLabel.Name = "experimentLabel";
            this.experimentLabel.Size = new System.Drawing.Size(107, 16);
            this.experimentLabel.TabIndex = 1;
            this.experimentLabel.Text = "BMP Experiment";
            // 
            // analysisLabel
            // 
            this.analysisLabel.AutoSize = true;
            this.analysisLabel.Location = new System.Drawing.Point(234, 20);
            this.analysisLabel.Name = "analysisLabel";
            this.analysisLabel.Size = new System.Drawing.Size(91, 16);
            this.analysisLabel.TabIndex = 2;
            this.analysisLabel.Text = "BMP Analysis";
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(105, 123);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(130, 16);
            this.nameLabel.TabIndex = 3;
            this.nameLabel.Text = "by Andreas Lennartz";
            // 
            // pictureBox
            // 
            this.pictureBox.Image = global::BMPBuilder.Properties.Resources.squares;
            this.pictureBox.InitialImage = global::BMPBuilder.Properties.Resources.squares;
            this.pictureBox.Location = new System.Drawing.Point(143, 54);
            this.pictureBox.Name = "pictureBox";
            this.pictureBox.Size = new System.Drawing.Size(48, 48);
            this.pictureBox.TabIndex = 4;
            this.pictureBox.TabStop = false;
            // 
            // thesisLabel
            // 
            this.thesisLabel.AutoSize = true;
            this.thesisLabel.Location = new System.Drawing.Point(35, 147);
            this.thesisLabel.Name = "thesisLabel";
            this.thesisLabel.Size = new System.Drawing.Size(275, 16);
            this.thesisLabel.TabIndex = 5;
            this.thesisLabel.Text = "Master Thesis HS Fulda && UMass Boston \'07";
            // 
            // profLabel
            // 
            this.profLabel.AutoSize = true;
            this.profLabel.Location = new System.Drawing.Point(100, 180);
            this.profLabel.Name = "profLabel";
            this.profLabel.Size = new System.Drawing.Size(131, 16);
            this.profLabel.TabIndex = 6;
            this.profLabel.Text = "Advising Professors:";
            // 
            // name2Label
            // 
            this.name2Label.AutoSize = true;
            this.name2Label.Location = new System.Drawing.Point(81, 206);
            this.name2Label.Name = "name2Label";
            this.name2Label.Size = new System.Drawing.Size(166, 16);
            this.name2Label.TabIndex = 7;
            this.name2Label.Text = "Prof. Dr. Jan-Torsten Milde";
            // 
            // name3Label
            // 
            this.name3Label.AutoSize = true;
            this.name3Label.Location = new System.Drawing.Point(102, 232);
            this.name3Label.Name = "name3Label";
            this.name3Label.Size = new System.Drawing.Size(129, 16);
            this.name3Label.TabIndex = 8;
            this.name3Label.Text = "Ph.D. Marc Pomplun";
            // 
            // Info
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(329, 266);
            this.Controls.Add(this.name3Label);
            this.Controls.Add(this.name2Label);
            this.Controls.Add(this.profLabel);
            this.Controls.Add(this.thesisLabel);
            this.Controls.Add(this.pictureBox);
            this.Controls.Add(this.nameLabel);
            this.Controls.Add(this.analysisLabel);
            this.Controls.Add(this.experimentLabel);
            this.Controls.Add(this.builderLabel);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Info";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Info";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label builderLabel;
        private System.Windows.Forms.Label experimentLabel;
        private System.Windows.Forms.Label analysisLabel;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.PictureBox pictureBox;
        private System.Windows.Forms.Label thesisLabel;
        private System.Windows.Forms.Label profLabel;
        private System.Windows.Forms.Label name2Label;
        private System.Windows.Forms.Label name3Label;
    }
}