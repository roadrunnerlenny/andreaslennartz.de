using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace BMPBuilder
{
    /// <summary>
    /// This class is the GUI for entering trial information.
    /// </summary>
    public partial class TrialForm : Form
    {
        /// <summary>
        /// The exeriment which generated this form.
        /// </summary>
        ExperimentForm experimentForm = null;

        /// <summary>
        /// Stores the trial information. Will be added to the Experiment Data.
        /// </summary>
        TrialData trial = new TrialData();

        /// <summary>
        /// Stores the preview information. Will be linked to the Trial Data.
        /// </summary>
        PreviewData preview = new PreviewData();

        /// <summary>
        /// If an existing TrialData objects needs to be changed or a new one has to be created.
        /// </summary>
        bool addData = true;

        /// <summary>
        /// If an existing TrialData object needs to be changed, this is the number in the TrialList. 
        /// </summary>
        int editNumber = 0;

        /// <summary>
        /// Initializes a new instance of the <see cref="TrialForm"/> class.
        /// </summary>
        public TrialForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="TrialForm"/> class.
        /// </summary>
        /// <param name="experimentForm">The experiment form.</param>
        public TrialForm(ExperimentForm experimentForm)
        {
            InitializeComponent();
            this.experimentForm = experimentForm;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="TrialForm"/> class.
        /// </summary>
        /// <param name="experimentForm">The experiment form.</param>
        /// <param name="editNumber">The edit number of the trial to be changed.</param>
        public TrialForm(ExperimentForm experimentForm, int editNumber)
        {
            InitializeComponent();
            this.experimentForm = experimentForm;
            addData = false;
            this.editNumber = editNumber;
            preview = experimentForm.Experiment.Trials[editNumber].Preview;
            trial = experimentForm.Experiment.Trials[editNumber];
            numberTrialsTextBox.Text = trial.TrialNumbers.ToString();
            maxDurationTextBox.Text = trial.Duration.ToString();
            nameTrialsTextBox.Text = trial.Name;

            displayXTextBox.Text = preview.DisplayX.ToString();
            displayYTextBox.Text = preview.DisplayY.ToString();

            backgroundColorPictureBox.BackColor = preview.BackgroundColor;
            borderColorPictureBox.BackColor = preview.BorderColor;
            conclusionColorPictureBox.BackColor = preview.ConclusionColor;

            color3CheckBox.Checked = preview.Color3Checked;
            color4CheckBox.Checked = preview.Color4Checked;
            color5CheckBox.Checked = preview.Color5Checked;
            color6CheckBox.Checked = preview.Color6Checked;
            color1PictureBox.BackColor = preview.Color1;
            color2PictureBox.BackColor = preview.Color2;
            color3PictureBox.BackColor = preview.Color3;
            color4PictureBox.BackColor = preview.Color4;
            color5PictureBox.BackColor = preview.Color5;
            color6PictureBox.BackColor = preview.Color6;

            if (preview.SquaresX == preview.SquaresY) quadraticCheckBox.Checked = true;
            else quadraticCheckBox.Checked = false;

            sameScreenCheckBox.Checked = preview.SameScreen;

            squaresXTextBox.Text = preview.SquaresX.ToString();
            squaresYTextBox.Text = preview.SquaresY.ToString();

            sizeXTextBox.Text = preview.SizeX.ToString();
            sizeYTextBox.Text = preview.SizeY.ToString();

            patternSquaresXTextBox.Text = preview.PatternSquaresX.ToString();
            patternSquaresYTextBox.Text = preview.PatternSquaresY.ToString();

            if (preview.PatternDisplayTime > 0) displayTimeTextBox.Text = preview.PatternDisplayTime.ToString();
            if (preview.PatternDisplayTime2 > 0) displayTime2TextBox.Text = preview.PatternDisplayTime2.ToString();
            if (preview.PatternDisplayTime3 > 0) displayTime3TextBox.Text = preview.PatternDisplayTime3.ToString();
        }

        /// <summary>
        /// Handles the Load event of the TrialForm control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void TrialForm_Load(object sender, EventArgs e)
        {
            displayXTextBox.Text = Constants.DisplayX.ToString();
            displayYTextBox.Text = Constants.DisplayY.ToString();
            displayTimeTrialNumberLabel.Text = Constants.PatternNumberBeforeTimeChange.ToString();
            displayTimeTrialNumber2Label.Text = Constants.PatternNumberBeforeTimeChange2.ToString();
            borderSizeLabel.Text = Constants.BorderSize.ToString();

        }


        /// <summary>
        /// Handles the Click event of the PreviewButton control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void PreviewButton_Click(object sender, EventArgs e)
        {
            readPreviewFormValues();
            showPreviewForm(preview);
        }

        /// <summary>
        /// Handles the Click event of the backgroundColorPictureBox control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void backgroundColorPictureBox_Click(object sender, EventArgs e)
        {
            backgroundColorDialog.Color = backgroundColorPictureBox.BackColor;

            if (backgroundColorDialog.ShowDialog() == DialogResult.OK)
            {
                backgroundColorPictureBox.BackColor = backgroundColorDialog.Color;
            }
        }

        /// <summary>
        /// Handles the Click event of the color1PictureBox control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void color1PictureBox_Click(object sender, EventArgs e)
        {
            color1Dialog.Color = color1PictureBox.BackColor;

            if (color1Dialog.ShowDialog() == DialogResult.OK)
            {
                color1PictureBox.BackColor = color1Dialog.Color;
            }
        }

        /// <summary>
        /// Handles the Click event of the color2PictureBox control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void color2PictureBox_Click(object sender, EventArgs e)
        {
            color2Dialog.Color = color2PictureBox.BackColor;

            if (color2Dialog.ShowDialog() == DialogResult.OK)
            {
                color2PictureBox.BackColor = color2Dialog.Color;
            }
        }

        /// <summary>
        /// Handles the Click event of the color3PictureBox control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void color3PictureBox_Click(object sender, EventArgs e)
        {
            color3Dialog.Color = color3PictureBox.BackColor;

            if (color3Dialog.ShowDialog() == DialogResult.OK)
            {
                color3PictureBox.BackColor = color3Dialog.Color;
            }
        }

        /// <summary>
        /// Handles the Click event of the color4PictureBox control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void color4PictureBox_Click(object sender, EventArgs e)
        {
            color4Dialog.Color = color4PictureBox.BackColor;

            if (color4Dialog.ShowDialog() == DialogResult.OK)
            {
                color4PictureBox.BackColor = color4Dialog.Color;
            }
        }

        /// <summary>
        /// Handles the Click event of the color5PictureBox control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void color5PictureBox_Click(object sender, EventArgs e)
        {
            color5Dialog.Color = color5PictureBox.BackColor;

            if (color5Dialog.ShowDialog() == DialogResult.OK)
            {
                color5PictureBox.BackColor = color5Dialog.Color;
            }
        }

        /// <summary>
        /// Handles the Click event of the color6PictureBox control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void color6PictureBox_Click(object sender, EventArgs e)
        {
            color6Dialog.Color = color6PictureBox.BackColor;

            if (color6Dialog.ShowDialog() == DialogResult.OK)
            {
                color6PictureBox.BackColor = color6Dialog.Color;
            }
        }

        /// <summary>
        /// Handles the CheckedChanged event of the color3CheckBox control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void color3CheckBox_CheckedChanged(object sender, EventArgs e)
        {
            color3PictureBox.Enabled = color3CheckBox.Checked;
        }

        /// <summary>
        /// Handles the CheckedChanged event of the color4CheckBox control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void color4CheckBox_CheckedChanged(object sender, EventArgs e)
        {
            color4PictureBox.Enabled = color4CheckBox.Checked;
        }

        /// <summary>
        /// Handles the CheckedChanged event of the color5CheckBox control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void color5CheckBox_CheckedChanged(object sender, EventArgs e)
        {
            color5PictureBox.Enabled = color5CheckBox.Checked;
        }

        /// <summary>
        /// Handles the CheckedChanged event of the color6CheckBox control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void color6CheckBox_CheckedChanged(object sender, EventArgs e)
        {
            color6PictureBox.Enabled = color6CheckBox.Checked;
        }


        /// <summary>
        /// Handles the Tick event of the timer control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void timer_Tick(object sender, EventArgs e)
        {
            bool preview = false;
            bool build = false;
            try {
                if (
                    Int32.Parse(displayXTextBox.Text) > 0 &&
                    Int32.Parse(displayYTextBox.Text) > 0 &&
                    Int32.Parse(sizeXTextBox.Text) > 0 && 
                    Int32.Parse(sizeYTextBox.Text) > 0 &&
                    Int32.Parse(squaresXTextBox.Text)>0 &&
                    Int32.Parse(squaresYTextBox.Text)>0 &&
                    Int32.Parse(patternSquaresXTextBox.Text)>0 &&
                    Int32.Parse(patternSquaresYTextBox.Text)>0 &&
                    (sameScreenCheckBox.Checked==true || Int32.Parse(displayTimeTextBox.Text) > 0) &&
                    (sameScreenCheckBox.Checked == true || Int32.Parse(displayTime2TextBox.Text) > 0) &&
                    (sameScreenCheckBox.Checked == true || Int32.Parse(displayTime3TextBox.Text) > 0) 
                   ) 
                        preview = true;
                if (preview==true && 
                    Int32.Parse(numberTrialsTextBox.Text) > 0 &&
                    Int32.Parse(maxDurationTextBox.Text) > 0 &&
                    (!(nameTrialsTextBox.Text.Trim()).Equals(""))
                   )
                    build = true;
                
            } catch (FormatException fe) {
                ;
            }
            if (previewButton.Enabled != preview) previewButton.Enabled = preview;
            if (OKButton.Enabled != build) OKButton.Enabled = build;
        }

        /// <summary>
        /// Handles the Click event of the sizeXTextBox control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void sizeXTextBox_Click(object sender, EventArgs e)
        {
            sizeXTextBox.SelectAll();
        }

        /// <summary>
        /// Handles the TextChanged event of the sizeXTextBox control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void sizeXTextBox_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (Int32.Parse(sizeXTextBox.Text) <= 0 || Int32.Parse(sizeXTextBox.Text) > Constants.MaxSizeX)
                {
                    sizeXTextBox.Text = "";
                }
            }
            catch (FormatException fe)
            {
                sizeXTextBox.Text = "";
            }
            updateSquaresX();
        }

        /// <summary>
        /// Handles the Click event of the sizeYTextBox control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void sizeYTextBox_Click(object sender, EventArgs e)
        {
            sizeYTextBox.SelectAll();
        }

        /// <summary>
        /// Handles the TextChanged event of the sizeYTextBox control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void sizeYTextBox_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (Int32.Parse(sizeYTextBox.Text) <= 0 || Int32.Parse(sizeYTextBox.Text) > Constants.MaxSizeY)
                {
                    sizeYTextBox.Text = "";
                }
            }
            catch (FormatException fe)
            {
                sizeYTextBox.Text = "";
            }
            updateSquaresY();
        }


        /// <summary>
        /// Handles the TextChanged event of the patternSquaresXTextBox control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void patternSquaresXTextBox_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (!(Int32.Parse(patternSquaresXTextBox.Text) > 0 && Int32.Parse(patternSquaresXTextBox.Text) < Constants.MaxPatternsX))
                    throw new FormatException();
            }
            catch (FormatException fe)
            {
                patternSquaresXTextBox.Text = "";
                patternSquaresXTextBox.SelectAll();
            }
        }

        /// <summary>
        /// Handles the Click event of the patternSquaresXTextBox control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void patternSquaresXTextBox_Click(object sender, EventArgs e)
        {
            patternSquaresXTextBox.SelectAll();
        }

        /// <summary>
        /// Handles the TextChanged event of the patternSquaresYTextBox control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void patternSquaresYTextBox_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (!(Int32.Parse(patternSquaresYTextBox.Text) > 0 && Int32.Parse(patternSquaresYTextBox.Text) < Constants.MaxPatternsY))
                    throw new FormatException();
            }
            catch (FormatException fe)
            {
                patternSquaresYTextBox.Text = "";
                patternSquaresYTextBox.SelectAll();
            }
        }

        /// <summary>
        /// Handles the Click event of the patternSquaresYTextBox control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void patternSquaresYTextBox_Click(object sender, EventArgs e)
        {
            patternSquaresYTextBox.SelectAll();
        }


        /// <summary>
        /// Handles the CheckedChanged event of the quadraticCheckBox control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void quadraticCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            updateSquaresX();
            updateSquaresY();
        }

        /// <summary>
        /// Handles the CheckedChanged event of the sameScreenCheckBox control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void sameScreenCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            updateSquaresX();
            updateSquaresY();
            if (sameScreenCheckBox.Checked != !displayTimeTextBox.Enabled)
            {
                displayTimeTextBox.Enabled = !sameScreenCheckBox.Checked;
                displayTime2TextBox.Enabled = !sameScreenCheckBox.Checked;
                displayTime3TextBox.Enabled = !sameScreenCheckBox.Checked;
            }
        }

        /// <summary>
        /// Handles the Click event of the cancelButton control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Handles the Click event of the OKButton control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void OKButton_Click(object sender, EventArgs e)
        {
            bool noError = true;
            try
            {
                this.readPreviewFormValues();
                this.readBuildFormValues();
            }
            catch (FormatException fe)
            {
                noError = false;
            }
            if (noError)
            {
                if (addData)
                {
                    experimentForm.Experiment.Trials.Add(trial);
                }
                else
                {
                    experimentForm.Experiment.Trials[editNumber] = trial;
                }
                experimentForm.UpdateTrialList();
                this.Close();
            }
        }


        /// <summary>
        /// Shows the preview form.
        /// </summary>
        /// <param name="preview">The preview to be shown.</param>
        private void showPreviewForm(PreviewData preview)
        {
            PreviewForm previewForm = new PreviewForm();
            previewForm.CreatePreviewForm(preview);
            previewForm.Show();
            previewForm.Focus();

        }

        /// <summary>
        /// Reads the preview form values.
        /// </summary>
        private void readPreviewFormValues()
        {
            preview.SquaresX = Int32.Parse(squaresXTextBox.Text);
            preview.SquaresY = Int32.Parse(squaresYTextBox.Text);
            preview.SizeX = Int32.Parse(sizeXTextBox.Text);
            preview.SizeY = Int32.Parse(sizeYTextBox.Text);
            preview.PatternSquaresX = Int32.Parse(patternSquaresXTextBox.Text);
            preview.PatternSquaresY = Int32.Parse(patternSquaresYTextBox.Text);
            preview.DisplayX = Int32.Parse(displayXTextBox.Text);
            preview.DisplayY = Int32.Parse(displayYTextBox.Text);
            preview.BackgroundColor = backgroundColorPictureBox.BackColor;
            preview.BorderColor = borderColorPictureBox.BackColor;
            preview.ConclusionColor = conclusionColorPictureBox.BackColor;
            preview.Color1 = color1PictureBox.BackColor;
            preview.Color2 = color2PictureBox.BackColor;
            preview.Color3Checked = color3CheckBox.Checked; preview.Color3 = color3PictureBox.BackColor;
            preview.Color4Checked = color4CheckBox.Checked; preview.Color4 = color4PictureBox.BackColor;
            preview.Color5Checked = color5CheckBox.Checked; preview.Color5 = color5PictureBox.BackColor;
            preview.Color6Checked = color6CheckBox.Checked; preview.Color6 = color6PictureBox.BackColor;
            preview.SameScreen = sameScreenCheckBox.Checked;
            if (!sameScreenCheckBox.Checked)
            {
                preview.PatternDisplayTime = Int32.Parse(displayTimeTextBox.Text);
                preview.PatternDisplayTime2 = Int32.Parse(displayTime2TextBox.Text);
                preview.PatternDisplayTime3 = Int32.Parse(displayTime3TextBox.Text);
            }
        }

        /// <summary>
        /// Reads the build form values.
        /// </summary>
        private void readBuildFormValues()
        {
            trial.TrialNumbers = Int32.Parse(numberTrialsTextBox.Text);
            trial.Duration = Int32.Parse(maxDurationTextBox.Text);
            trial.Name = nameTrialsTextBox.Text;
            trial.Preview = preview;
        }

        /// <summary>
        /// Updates the squares X display..
        /// </summary>
        private void updateSquaresX()
        {
            try
            {
                if (fullScreenCheckBox.Checked)
                {
                    decimal X = 0;
                    if (sameScreenCheckBox.Checked)
                    {

                        if (!quadraticCheckBox.Checked)
                            X = Math.Ceiling((decimal)( (Constants.PictureWidth-Constants.BorderSize) / Int32.Parse(sizeXTextBox.Text)));
                        else
                            X = Constants.PictureWidth < Constants.PictureHeight ?
                                Math.Ceiling((decimal)( (Constants.PictureWidth-Constants.BorderSize) / Int32.Parse(sizeXTextBox.Text))) :
                                Math.Ceiling((decimal)( (Constants.PictureHeight-Constants.BorderSize) / Int32.Parse(sizeXTextBox.Text)));
                    }
                    else
                    {
                        if (!quadraticCheckBox.Checked)
                            X = Math.Ceiling((decimal)( (Constants.DisplayX-Constants.BorderSize) / Int32.Parse(sizeXTextBox.Text)));
                        else
                            X = Constants.DisplayX < Constants.DisplayY ?
                                Math.Ceiling((decimal)( (Constants.DisplayX-Constants.BorderSize) / Int32.Parse(sizeXTextBox.Text))) :
                                Math.Ceiling((decimal)( (Constants.DisplayY-Constants.BorderSize) / Int32.Parse(sizeXTextBox.Text)));
                    }
                    squaresXTextBox.Text = X.ToString();
                }
            }
            catch (FormatException fe)
            {
                squaresXTextBox.Text = "";
            }
        }

        /// <summary>
        /// Updates the squares Y display.
        /// </summary>
        private void updateSquaresY()
        {
            try
            {
                if (fullScreenCheckBox.Checked)
                {
                    decimal Y = 0;
                    if (!quadraticCheckBox.Checked)
                        Y = Math.Ceiling((decimal)( (Constants.PictureHeight-Constants.BorderSize) / Int32.Parse(sizeYTextBox.Text)));
                    else
                        if (sameScreenCheckBox.Checked)
                            Y = Constants.PictureHeight < Constants.PictureWidth ?
                                Math.Ceiling((decimal)( (Constants.PictureHeight-Constants.BorderSize) / Int32.Parse(sizeYTextBox.Text))) :
                                Math.Ceiling((decimal)( (Constants.PictureWidth-Constants.BorderSize) / Int32.Parse(sizeYTextBox.Text)));
                        else
                            Y = Constants.DisplayX < Constants.DisplayY ?
                                Math.Ceiling((decimal)( (Constants.DisplayX-Constants.BorderSize) / Int32.Parse(sizeXTextBox.Text))) :
                                Math.Ceiling((decimal)( (Constants.DisplayY-Constants.BorderSize) / Int32.Parse(sizeXTextBox.Text)));
                    squaresYTextBox.Text = Y.ToString();
                }
            }
            catch (FormatException fe)
            {
                squaresYTextBox.Text = "";
            }
        }

        /// <summary>
        /// Handles the Click event of the borderColorPictureBox control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void borderColorPictureBox_Click(object sender, EventArgs e)
        {
            borderColorDialog.Color = borderColorPictureBox.BackColor;

            if (borderColorDialog.ShowDialog() == DialogResult.OK)
            {
                borderColorPictureBox.BackColor = borderColorDialog.Color;
            }
        }

        /// <summary>
        /// Handles the Click event of the conclusionColorPictureBox control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void conclusionColorPictureBox_Click(object sender, EventArgs e)
        {
            conclusionColorDialog.Color = conclusionColorPictureBox.BackColor;

            if (conclusionColorDialog.ShowDialog() == DialogResult.OK)
            {
                conclusionColorPictureBox.BackColor = conclusionColorDialog.Color;
            }
        }



    }
}



