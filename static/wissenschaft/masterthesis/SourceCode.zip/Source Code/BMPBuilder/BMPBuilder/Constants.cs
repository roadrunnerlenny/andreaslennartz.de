using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace BMPBuilder
{
    /// <summary>
    /// The Constants class defines fixed values for the experiments, such as the screen size or the maximum number of squares for a pattern.
    /// </summary>
    public class Constants
    {
        private static int displayX = 1280;

        /// <summary>
        /// Gets the horizontal resolution of the experiment screen. 
        /// </summary>
        /// <value>Horizontal resolution of experiment screen.</value>
        public static int DisplayX

        {
            get { return Constants.displayX; }
        }

        private static int displayY = 1024;

        /// <summary>
        /// Gets the vertical resolution of the experiment screen.
        /// </summary>
        /// <value>Vertical resolution of experiment screen.</value>
        public static int DisplayY
        {
            get { return Constants.displayY; }
           
        }

        private static int pictureWidth = 1000;

        /// <summary>
        /// Gets the maximum width for a picture object.
        /// </summary>
        /// <value>The maximum width for a picture object.</value>
        public static int PictureWidth
        {
            get { return Constants.pictureWidth; }
        }

        private static int pictureHeight = displayY;

        /// <summary>
        /// Gets the maximum height for a picture object.
        /// </summary>
        /// <value>The maximum height for a picture object.</value>
        public static int PictureHeight
        {
            get { return Constants.pictureHeight; }
        }

        private static int patternWidth = displayX - pictureWidth;

        /// <summary>
        /// Gets the maximum width for a pattern object.
        /// </summary>
        /// <value>The maximum width for a pattern object.</value>
        public static int PatternWidth
        {
            get { return Constants.patternWidth; }
        }

        /// <summary>
        /// Gets the maximum height for a pattern object.
        /// </summary>
        /// <value>The maximum height for a pattern object.</value>
        private static int patternHeight = pictureHeight;

        public static int PatternHeight
        {
            get { return Constants.patternHeight; }
        }

        private static int patternOffset = pictureWidth;

        /// <summary>
        /// Gets the vertical (X-Axis) start position of the pattern display.
        /// </summary>
        /// <value>The vertical (X-Axis) start position of the pattern display.</value>
        public static int PatternOffset
        {
            get { return Constants.patternOffset; }
        }

        private static int maxSizeX = 200;

        /// <summary>
        /// Gets the maximum width for a square.
        /// </summary>
        /// <value>The maximum width for a square.</value>
        public static int MaxSizeX
        {
            get { return Constants.maxSizeX; }
        }

        private static int maxSizeY = 200;

        /// <summary>
        /// Gets the maximum height for a square.
        /// </summary>
        /// <value>The maximum height for a square.</value>
        public static int MaxSizeY
        {
            get { return Constants.maxSizeY; }
        }

        private static int maxPatternsX = 10;

        /// <summary>
        /// Gets the maximum number of pattern squares in horizontal direction.
        /// </summary>
        /// <value>The maximum number of pattern squares in horizontal direction.</value>
        public static int MaxPatternsX
        {
            get { return Constants.maxPatternsX; }
        }

        private static int maxPatternsY = 10;

        /// <summary>
        /// Gets the maximum number of pattern squares in vertical direction.
        /// </summary>
        /// <value>The maximum number of pattern squares in vertical direction.</value>
        public static int MaxPatternsY
        {
            get { return Constants.maxPatternsY; }
        }

        private static string configFileName = @"config.txt";

        /// <summary>
        /// Gets the name of the config file.
        /// </summary>
        /// <value>The name of the config file.</value>
        public static string ConfigFileName
        {
            get { return Constants.configFileName; }
        }

        private static string experimentFileName = "experiment.bin";

        /// <summary>
        /// Gets the name of the experiment file.
        /// </summary>
        /// <value>The name of the experiment file.</value>
        public static string ExperimentFileName
        {
            get { return Constants.experimentFileName; }
        }

        private static string imageFolderName = @"images";

        /// <summary>
        /// Gets the name of the image folder.
        /// </summary>
        /// <value>The name of the image folder.</value>
        public static string ImageFolderName
        {
            get { return Constants.imageFolderName; }
        }

        private static string dataFolderName = @"data";

        /// <summary>
        /// Gets the name of the data folder.
        /// </summary>
        /// <value>The name of the data folder.</value>
        public static string DataFolderName
        {
            get { return Constants.dataFolderName; }
        }

        private static string patternDataPrefix = "PatternData_";

        /// <summary>
        /// Gets the pattern data prefix.
        /// </summary>
        /// <value>The pattern data prefix.</value>
        public static string PatternDataPrefix
        {
            get { return Constants.patternDataPrefix; }
        }

        private static string pictureDataPrefix = "PictureData_";

        /// <summary>
        /// Gets the picture data prefix.
        /// </summary>
        /// <value>The picture data prefix.</value>
        public static string PictureDataPrefix
        {
            get { return Constants.pictureDataPrefix; }
        }

        private static string dataPostfix = ".bin";

        /// <summary>
        /// Gets the data file ending )e.g.,set to .bin)
        /// </summary>
        /// <value>The data file ending.</value>
        public static string DataPostfix
        {
            get { return Constants.dataPostfix; }
        }

        private static int patternNumberBeforeTimeChange = 3;

        /// <summary>
        /// Gets the number of trials done before display time changes for first time.
        /// </summary>
        /// <value>The number of trials done before display time changes for first time.</value>
        public static int PatternNumberBeforeTimeChange
        {
            get { return Constants.patternNumberBeforeTimeChange; }
        }

        private static int patternNumberBeforeTimeChange2 = 15;

        /// <summary>
        /// Gets the number of trials done before display time changes for second time.
        /// </summary>
        /// <value>The number of trials done before display time changes for second time.</value>
        public static int PatternNumberBeforeTimeChange2
        {
            get { return Constants.patternNumberBeforeTimeChange2; }
        }

        private static int borderSize = 2;

        /// <summary>
        /// Gets or sets the size of the rectangle frame that marks the target squares at the end of each trial.
        /// </summary>
        /// <value>The size of the rectangle frame that marks the target squares at the end of each trial.</value>
        public static int BorderSize
        {
            get { return Constants.borderSize; }
            set { Constants.borderSize = value; }
        }

        /// <summary>
        /// Calculates the picture location on the screen.
        /// </summary>
        /// <param name="sameScreen">If set to <c>true</c>, pattern and picture are displayed on the same screen.</param>
        /// <param name="squaresX">The number of squares in horizontal direction.</param>
        /// <param name="sizeX">The size of each square (in pixel) in horizontal direction.</param>
        /// <param name="squaresY">The number of squares in vertical direction.</param>
        /// <param name="sizeY">The size of each square (in pixel) in vertical direction.</param>
        /// <returns></returns>
        public static Point CalcPictureLocation(bool sameScreen, int squaresX, int sizeX, int squaresY, int sizeY)
        {
            if (sameScreen)
            {
                return new Point(
                    (Constants.DisplayX - Constants.PatternWidth - squaresX * sizeX) / 2,
                    (Constants.DisplayY - squaresY * sizeY) / 2
                );
            }
            else
            {
                return new Point(
                    (Constants.DisplayX - squaresX * sizeX) / 2,
                    (Constants.DisplayY - squaresY * sizeY) / 2
                );
            }
        }

        /// <summary>
        /// Calculates the pattern location on the screen.
        /// </summary>
        /// <param name="sameScreen">If set to <c>true</c>, pattern and picture are displayed on the same screen.</param>
        /// <param name="squaresX">The number of squares of the pattern in horizontal direction.</param>
        /// <param name="sizeX">The size of each square (in pixel) in horizontal direction.</param>
        /// <param name="squaresY">The number of squares of the pattern in vertical direction.</param>
        /// <param name="sizeY">The size of each square (in pixel) in vertical direction.</param>
        /// <returns></returns>
        public static Point CalcPatternLocation(bool sameScreen, int patternSquaresX, int sizeX, int patternSquaresY, int sizeY)
        {
            if (sameScreen)
            {
                return new Point(
                    Constants.PatternOffset + (Constants.PatternWidth / 2) - (patternSquaresX * sizeX / 2),
                    (Constants.PatternHeight / 2) - (patternSquaresY * sizeY / 2)
                 );
            }
            else
            {
                return new Point(
                    (Constants.DisplayX - patternSquaresX * sizeX) / 2,
                    (Constants.DisplayY - patternSquaresY * sizeY) / 2
                );
            }
        }

        /// <summary>
        /// Makes a string out of a color object.
        /// </summary>
        /// <param name="colValue">The color value as an object.</param>
        /// <param name="abbr">If set to <c>true</c>, an abbreviated form will be used.</param>
        /// <returns>The color as a string, e.g. -1 will return "Black" or if abbreviation is set "B".</returns>
        public static string ColorIntToString(Color colValue, bool abbr)
        {
            return Constants.ColorIntToString(colValue.ToArgb(), abbr);
        }

        /// <summary>
        /// Makes a string out of an integer color value.
        /// </summary>
        /// <param name="colValue">The color value as an integer.</param>
        /// <param name="abbr">If set to <c>true</c>, an abbreviated form will be used.</param>
        /// <returns>The color as a string, e.g. -1 will return "Black" or if abbreviation is set "B".</returns>
        public static string ColorIntToString(int colValue, bool abbr)
        {
            if (colValue == Color.White.ToArgb())
            {
                if (abbr) return "W";
                else return "White";
            }
            else if (colValue == Color.Black.ToArgb())
            {
                if (abbr) return "B";
                else return "Black";
            }
            else if (colValue == Color.Red.ToArgb())
            {
                if (abbr) return "R";
                else return "Red";
            }
            else if (colValue == Color.Green.ToArgb())
            {
                if (abbr) return "G";
                else return "Green";
            }
            else if (colValue == Color.Blue.ToArgb())
            {
                if (abbr) return "Bl";
                else return "Blue";
            }
            else if (colValue == Color.Yellow.ToArgb())
            {
                if (abbr) return "Y";
                else return "Yellow";
            }
            else if (colValue == Color.Orange.ToArgb())
            {
                if (abbr) return "O";
                else return "Orange";
            }
            else if (colValue == Color.Gray.ToArgb())
            {
                if (abbr) return "G";
                else return "Gray";
            }
            else if (colValue == Color.DarkGray.ToArgb())
            {
                if (abbr) return "dG";
                else return "Dark Gray";
            }
            else if (colValue == Color.LightGray.ToArgb())
            {
                if (abbr) return "lG";
                else return "light Gray";
            }
            else if (colValue == Color.DarkSlateGray.ToArgb())
            {
                if (abbr) return "dsG";
                else return "Dark Slate Gray";
            }
            else if (colValue == Color.LightSlateGray.ToArgb())
            {
                if (abbr) return "lsG";
                else return "Light Slate Gray";
            }
            else return colValue.ToString();
        }


    }
}
