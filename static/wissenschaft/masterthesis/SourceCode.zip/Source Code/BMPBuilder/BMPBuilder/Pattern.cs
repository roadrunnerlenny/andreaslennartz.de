using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace BMPBuilder
{
    /// <summary>
    /// The Pattern class inherits from the Bitmap class, and represents a pattern image.
    /// </summary>
    [Serializable]
    public class Pattern : BMPBuilder.Bitmap
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Pattern"/> class.
        /// </summary>
        /// <param name="squaresX">The number of squares in horizontal direction.</param>
        /// <param name="squaresY">The number of squares in vertical direction.</param>
        /// <param name="colors">A list of colors which should be used for the image. (E.g, black and white)</param>
        public Pattern(int squaresX, int squaresY, List<Color> colors)
            : base(squaresX, squaresY, colors) { 
            ; 
        }
    }
}
