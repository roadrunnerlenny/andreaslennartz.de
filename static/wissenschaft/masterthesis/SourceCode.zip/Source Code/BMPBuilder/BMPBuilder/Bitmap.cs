using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;


namespace BMPBuilder
{
    /// <summary>
    /// The Bitmap class defines basic properties and functions for a square-shaped checkboard-like image. Creating, 
    /// Painting, Loading and Saving of images is possible. This class should not be instantiated directly - its inherited classes 
    /// Picture and Pattern should be used instead. 
    /// </summary>
    [Serializable]
    public class Bitmap
    {
        protected int squaresX = 0;

        /// <summary>
        /// Numbers of squares in horizontal directions
        /// </summary>
        public int SquaresX
        {
            get { return squaresX; }
            set { squaresX = value; }
        }

        protected int squaresY = 0;

        /// <summary>
        /// Numbers of sqares in vertical direction
        /// </summary>
        public int SquaresY
        {
            get { return squaresY; }
            set { squaresY = value; }
        }

        protected List<Color> colors = new List<Color>();

        /// <summary>
        /// A list of all colors the Image contains. (E.g., if the Image contains squares in black and white, this
        /// List will contain two color objects with the values black and white.)
        /// </summary>
        public List<Color> Colors
        {
            get { return colors; }
            set { colors = value; }
        }

        protected int[,] structure = null;

        /// <summary>
        /// The structure of the image, defined in a two-dimensional array of integer values. 
        /// </summary>
        /// <example>
        /// If an image contains 20x20 squares, the upper bounds for the array are 20,20. Each field of the 
        /// array contains an integer value equivalent to a defined color of the corresponding square. 
        /// <code>
        ///     using System.Drawing;
        ///     List c as Color = {Color.Black, Color.White};
        ///     BMPBuilder.Bitmap b = new BMPBuilder.Bitmap(10, 10, c);
        ///     b.Create();
        ///     for (int i=0;i SMALLERAS b.SquaresXi;i++)
        ///         for (int j=0;j SMALLERAS b.SquaresY;j++) 
        ///             if (b.Structure[i, j] == Color.Black.ToArgb())
        ///                  Console.WriteLine(i + "," + j + " is a black square.");
        /// </code>
        /// </example>
        public int[,] Structure
        {
            get { return structure; }
            set { structure = value; }
        }

        protected Point startLocation = new Point(0, 0);

        /// <summary>
        /// The X and Y coordinate the image is displayed on the screen. Important to calcuate a square Position from a given
        /// point on the screen. 
        /// </summary>
        public Point StartLocation
        {
            get { return startLocation; }
            set { startLocation = value; }
        }

        /// <summary>
        /// Fills the image at random with the colors defined in the Color Property
        /// </summary>
        /// <example>
        /// <code>
        ///     using System.Drawing;
        ///     List c as Color = {Color.Black, Color.White};
        ///     BMPBuilder.Bitmap b = new BMPBuilder.Bitmap(10, 10, c);
        ///     b.Create();
        ///     for (int i=0;i SMALLER AS b.SquaresX;i++)
        ///         for (int j=0;j SMALLER AS b.SquaresY;j++) 
        ///             if (b.Structure[i, j] == Color.Black.ToArgb())
        ///                  Console.WriteLine(i + "," + j + " is a black square.");
        /// </code>
        /// </example>
        public void Create()
        {
            Random rand = new Random();
            for (int x = 0; x < this.squaresX; x++)
            {
                for (int y = 0; y < this.squaresY; y++)
                {
                    int colorNumber = rand.Next(0, colors.Count);
                    structure[x, y] = colors[colorNumber].ToArgb();
                }
            }
        }

        /// <summary>
        /// Returns a "real" bitmap of the type System.Drawing.Bitmap of the created image.
        /// </summary>
        /// <param name="squareSize">The Width and Height of each Square in Pixel</param>
        /// <param name="borderColor">The color of the surrounding border</param>
        /// <returns>A System.Drawing.Bitmap with the painted image.</returns>
        public System.Drawing.Bitmap Paint(Size squareSize, Color borderColor)
        {
            System.Drawing.Bitmap bmp = new System.Drawing.Bitmap(squareSize.Width * squaresX + Constants.BorderSize * 2, squareSize.Height * squaresY + Constants.BorderSize * 2);
            Graphics g = Graphics.FromImage(bmp);

            g.DrawRectangle(new Pen(borderColor, Constants.BorderSize), Constants.BorderSize / 2, Constants.BorderSize / 2, (squareSize.Width * squaresX) + Constants.BorderSize, (squareSize.Height * squaresY) + Constants.BorderSize);

            for (int x = 0; x < squaresX; x++)
            {
                for (int y = 0; y < squaresY; y++)
                {
                    Point location = new Point(x * squareSize.Width + Constants.BorderSize, y * squareSize.Height + Constants.BorderSize);
                    Rectangle actRect = new Rectangle(location, squareSize);
                    SolidBrush brush = new SolidBrush(Color.FromArgb(structure[x, y]));
                    g.FillRectangle(brush, actRect);
                }
            }
            g.Flush();
            g.Dispose();
            return bmp;
        }

        /// <summary>
        /// Saves the image data to a file on the hardisk. 
        /// </summary>
        /// <param name="filename">The path and filename where to store the object.</param>
        public void Save(string filename)
        {
            IFormatter formatter = new BinaryFormatter();
            using (Stream stream = new FileStream(filename, FileMode.Create, FileAccess.Write, FileShare.None))
            {
                formatter.Serialize(stream, this);
            }
        }


        /// <summary>
        /// Loads previously saved image data. 
        /// </summary>
        /// <param name="filename">The path and filename of a previously saved object.</param>
        /// <returns>The loaded image data.</returns>
        public static BMPBuilder.Bitmap Load(string filename)
        {
            IFormatter formatter = new BinaryFormatter();
            using (Stream stream = new FileStream(filename, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                return (BMPBuilder.Bitmap)formatter.Deserialize(stream);
            }
        }

        /// <summary>
        /// Creates a new image object. 
        /// </summary>
        /// <param name="squaresX">The number of squares in horizontal direction.</param>
        /// <param name="squaresY">The number of squares in vertical direction. </param>
        /// <param name="colors">A list of colors which should be used for the image. (E.g, black and white)</param>
        public Bitmap(int squaresX, int squaresY, List<Color> colors)
        {
            this.squaresX = squaresX;
            this.squaresY = squaresY;
            this.colors = colors;
            structure = new int[squaresX,squaresY];
        }

        /// <summary>
        /// Returns the percentage distribution of colors of an (already created) image. E.g, if a 2x2 image consists of 1 black square
        /// and 3 white squares, the distribution would be 0.25 and 0.75.
        /// </summary>
        /// <param name="decimals">Truncates the result to the specified decimal places</param>
        /// <returns> A field (size is determined by the number of colors) that contains the percentage distribution
        /// value for each color. </returns>
        public double[] ColorDistribution(int decimals)
        {
            return ColorDistribution(decimals,new Rectangle(0,0,squaresX,squaresY));
        }

        /// <summary>
        /// Returns the percentage distribution of colors of the defined clipping area of an image. E.g, if the defined clipping area
        /// spans over a 2x2 pattern and consists of 1 black square and 3 white squares, the distribution would be 0.25 and 0.75.
        /// </summary>
        /// <param name="decimals">Truncates the result to the specified decimal places</param>
        /// <param name="distRect">A clipped area defined as a rectangle. Should not exceed the size of the image.</param>
        /// <returns> A field (size is determined by the number of colors) that contains the percentage distribution
        ///  value for each color. </returns>
        public double[] ColorDistribution(int decimals,Rectangle distRect)
        {
            double sqPctg = 1.0 / (double)((distRect.Width * distRect.Height));
            double[] pctgs = new double[colors.Count];
            for (int p = 0; p < colors.Count; p++)
                pctgs[p] = 0;
            for (int m = distRect.X; m < distRect.X+distRect.Width; m++)
                for (int n = distRect.Y; n < distRect.Y+distRect.Height; n++)
                    for (int p = 0; p < colors.Count; p++)
                        try
                        {
                            if (structure[m, n] == colors[p].ToArgb())
                                pctgs[p] += sqPctg;
                        }
                        catch (IndexOutOfRangeException ie)
                        {
                            pctgs[p] = 0;
                        }
            for (int p = 0; p < colors.Count; p++)
                pctgs[p] = Math.Round(pctgs[p], decimals);
            return pctgs;
        }

    }
}
