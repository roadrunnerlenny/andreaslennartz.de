using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Drawing;

namespace BMPBuilder
{
    /// <summary>
    /// Class to store and handle all necessary information for an experiment. It contains a list of all Trials as well as 
    /// functions to load and save the experiment and generate data files for the experiment engine. 
    /// </summary>
    /// <seealso cref="TrialData"/>, <seealso cref="PreviewData"/>
    [Serializable]
    public class ExperimentData
    {
        List<TrialData> trials = new List<TrialData>();

        /// <summary>
        /// Gets or sets the list of trials.
        /// </summary>
        /// <value>The list of trials.</value>
        public List<TrialData> Trials
        {
          get { return trials; }
          set { trials = value; }
        }

        /// <summary>
        /// Loads the experiment.
        /// </summary>
        /// <param name="filename">The filename (including path) of the experiment to be loaded.</param>
        /// <returns>A new Object with the loaded experiment data.</returns>
        public static ExperimentData LoadExperiment(string filename)
        {
            IFormatter formatter = new BinaryFormatter();
            using (Stream stream = new FileStream(filename, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                return (ExperimentData)formatter.Deserialize(stream);
            }
        }

        /// <summary>
        /// Saves the experiment.
        /// </summary>
        /// <param name="filename">The filename (including path) of the experiment.</param>
        public void SaveExperiment(string filename)
        {
            IFormatter formatter = new BinaryFormatter();
            using (Stream stream = new FileStream(filename, FileMode.Create, FileAccess.Write, FileShare.None))
            {
                formatter.Serialize(stream, this);
            }
        }

        /// <summary>
        /// Generates the experiment file for the experiment engine..
        /// </summary>
        /// <param name="folder">The folder where the files are to be created.</param>
        /// <param name="worker">A background worker object that runs this function in a background thread and 
        /// can retrieve progress information.</param>
        /// <returns><c>true</c> if the file generation was successful.</returns>
        public bool GenerateExperimentFile(string folder, System.ComponentModel.BackgroundWorker worker)
        {
            try
            {
                if (Directory.Exists(folder + @"\" + Constants.ImageFolderName)) Directory.Delete(folder + @"\" + Constants.ImageFolderName, true);
                Directory.CreateDirectory(folder + @"\" + Constants.ImageFolderName);
                if (Directory.Exists(folder + @"\" + Constants.DataFolderName)) Directory.Delete(folder + @"\" + Constants.DataFolderName, true);
                Directory.CreateDirectory(folder + @"\" + Constants.DataFolderName);
            }
            catch (IOException ie)
            {
                System.Windows.Forms.MessageBox.Show("Cannot create/delete Folders! Please check if any files are in use!");
                return false;
            }

            int counter = 0;
            int totalTrials = 0;
            foreach (TrialData trial in this.Trials)
                totalTrials += trial.TrialNumbers;

            /* Open the config file */
            using (TextWriter tw = new StreamWriter(folder + @"\" + Constants.ConfigFileName))
            {
                tw.WriteLine(Constants.DisplayX.ToString());
                tw.WriteLine(Constants.DisplayY.ToString());
                tw.WriteLine(totalTrials.ToString());
            }

            int actTrialBlockNumber = 0;
            /* For each trial: Create pattern and picture files */
            foreach (TrialData trial in this.Trials)
            {
                int i = 1;
                List<Color> colors = new List<Color>();
                colors.Add(trial.Preview.Color1);
                colors.Add(trial.Preview.Color2);
                if (trial.Preview.Color3Checked) colors.Add(trial.Preview.Color3);
                if (trial.Preview.Color4Checked) colors.Add(trial.Preview.Color4);
                if (trial.Preview.Color5Checked) colors.Add(trial.Preview.Color5);
                if (trial.Preview.Color6Checked) colors.Add(trial.Preview.Color6);
                Pattern pattern = new Pattern(trial.Preview.PatternSquaresX, trial.Preview.PatternSquaresY, colors);

                pattern.Create();

                for (; i <= trial.TrialNumbers; i++)
                {
                    System.Drawing.Bitmap trialBMP = new System.Drawing.Bitmap(Constants.DisplayX, Constants.DisplayY);
                    Graphics g = Graphics.FromImage(trialBMP);
                    g.FillRectangle(new SolidBrush(trial.Preview.BackgroundColor), 0, 0, trialBMP.Width, trialBMP.Height);

                    System.Drawing.Bitmap trialBMPPattern = null;
                    Graphics gP = null;
                    if (!trial.Preview.SameScreen)
                    {
                        trialBMPPattern = new System.Drawing.Bitmap(Constants.DisplayX, Constants.DisplayY);
                        gP = Graphics.FromImage(trialBMPPattern);
                        gP.FillRectangle(new SolidBrush(trial.Preview.BackgroundColor), 0, 0, trialBMPPattern.Width, trialBMPPattern.Height);
                    }

                    System.Drawing.Bitmap patternBMP = pattern.Paint(new Size(trial.Preview.SizeX, trial.Preview.SizeY), trial.Preview.BorderColor);

                    Picture picture = new Picture(trial.Preview.SquaresX, trial.Preview.SquaresY, colors);
                    picture.Create();
                    picture.RemoveAndAddPattern(pattern);
                    System.Drawing.Bitmap pictureBMP = picture.Paint(new Size(trial.Preview.SizeX, trial.Preview.SizeY), trial.Preview.BorderColor);

                    picture.StartLocation = Constants.CalcPictureLocation(
                        trial.Preview.SameScreen,
                        trial.Preview.SquaresX, trial.Preview.SizeX,
                        trial.Preview.SquaresY, trial.Preview.SizeY
                    );
                    pattern.StartLocation = Constants.CalcPatternLocation(
                        trial.Preview.SameScreen,
                        trial.Preview.PatternSquaresX, trial.Preview.SizeX,
                        trial.Preview.PatternSquaresY, trial.Preview.SizeY
                    );

                    g.DrawImage(pictureBMP, picture.StartLocation);

                    if (trial.Preview.SameScreen)
                    {
                        g.DrawImage(patternBMP, pattern.StartLocation);
                    }
                    else
                    {
                        gP.DrawImage(patternBMP, pattern.StartLocation);
                        gP.Flush();
                        gP.Dispose();
                    }
                    g.Flush();
                    g.Dispose();

                    trialBMP.Save(folder + @"\" + Constants.ImageFolderName + @"\" + "trial_" + (actTrialBlockNumber + i) + ".bmp");
                    if (!trial.Preview.SameScreen)
                        trialBMPPattern.Save(folder + @"\" + Constants.ImageFolderName + @"\" + "trialPattern_" + (actTrialBlockNumber + i) + ".bmp");

                    /* Write the conclusion of the trial into different files for each trial */
                    using (TextWriter tw = new StreamWriter(folder + @"\" + Constants.DataFolderName + @"\" + "trialData_" + (actTrialBlockNumber + i) + ".txt"))
                    {
                        tw.WriteLine(trial.Name);
                        if (trial.Preview.SameScreen)
                            tw.WriteLine("1");
                        else
                            tw.WriteLine("0");

                        if (!trial.Preview.SameScreen)
                        {
                            if (i < Constants.PatternNumberBeforeTimeChange)
                                tw.WriteLine(trial.Preview.PatternDisplayTime.ToString());
                            else if (i < Constants.PatternNumberBeforeTimeChange2)
                                tw.WriteLine(trial.Preview.PatternDisplayTime2.ToString());
                            else
                                tw.WriteLine(trial.Preview.PatternDisplayTime3.ToString());
                        }
                        else
                        {
                            tw.WriteLine("0");
                        }

                        tw.WriteLine(trial.Duration.ToString());
                        tw.WriteLine(picture.StartLocation.X + (trial.Preview.SizeX * picture.PatternPositionX));
                        tw.WriteLine(picture.StartLocation.Y + (trial.Preview.SizeY * picture.PatternPositionY));
                        tw.WriteLine(trial.Preview.SizeX * trial.Preview.PatternSquaresX);
                        tw.WriteLine(trial.Preview.SizeY * trial.Preview.PatternSquaresY);
                        tw.WriteLine(trial.Preview.ConclusionColor.R.ToString());
                        tw.WriteLine(trial.Preview.ConclusionColor.G.ToString());
                        tw.WriteLine(trial.Preview.ConclusionColor.B.ToString());

                        // Following data is only written to the file to make a manual check if file creating was successful 
                        tw.WriteLine("-------------------------------------------");
                        tw.WriteLine("Data not read by experiment after this line");
                        tw.WriteLine("-------------------------------------------");
                        tw.WriteLine("Pattern position X: "+picture.PatternPositionX.ToString());
                        tw.WriteLine("Pattern position Y: "+picture.PatternPositionY.ToString());
                        tw.WriteLine("Picture start location X: " + picture.StartLocation.X.ToString());
                        tw.WriteLine("Picture start location Y: " + picture.StartLocation.Y.ToString());
                        tw.WriteLine("Pattern start location X " + pattern.StartLocation.X.ToString());
                        tw.WriteLine("Pattern start location X " + pattern.StartLocation.Y.ToString());
 
                        /* 
                         * For data verifaction purposes the raw Array data can be written to the file 
                         * 
                        foreach (int k in pattern.Structure)
                            tw.Write(k + ",");
                        tw.WriteLine();
                        foreach (int k in picture.Structure)
                            tw.Write(k + ",");
                        tw.WriteLine();
                        */
                    }

                    IFormatter formatter = new BinaryFormatter();
                    picture.Save(folder + @"\" + Constants.DataFolderName + @"\" + "PictureData_" + (actTrialBlockNumber + i) + ".bin");
                    pattern.Save(folder + @"\" + Constants.DataFolderName + @"\" + "PatternData_" + (actTrialBlockNumber + i) + ".bin");

                    int progress = (int)(((double)counter++) / ((double)totalTrials) * ((double)100.0));
                    worker.ReportProgress(progress);
                }
                actTrialBlockNumber += (i - 1);

            }

            this.SaveExperiment(folder + @"\" + Constants.ExperimentFileName);

            return true;



        }
    }
}
