using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace BMPBuilder
{
    /// <summary>
    /// This class displays a rough preview of a pattern and picture on the screen. 
    /// </summary>
    public class PreviewForm : System.Windows.Forms.Form
    {
        /// <summary>
        /// Creates the preview form.
        /// </summary>
        /// <param name="preview">The preview data.</param>
        public void CreatePreviewForm(PreviewData preview)
        {
            this.FormBorderStyle = FormBorderStyle.None;
            this.Size = new Size(preview.DisplayX, preview.DisplayY);
            this.BackColor = preview.BackgroundColor;
            this.StartPosition = FormStartPosition.Manual;
            this.Location = new Point(0, 0);

            PictureBox previewPicture = new PictureBox();
            previewPicture.Size = new Size(preview.SquaresX * preview.SizeX + Constants.BorderSize *2, preview.SquaresY * preview.SizeY + Constants.BorderSize *2);
            
            previewPicture.Location = Constants.CalcPictureLocation(preview.SameScreen, preview.SquaresX, preview.SizeX, preview.SquaresY, preview.SizeY);

            previewPicture.BorderStyle = BorderStyle.None;
            previewPicture.BackColor = preview.BackgroundColor;

            PictureBox previewPattern = new PictureBox();
            previewPattern.Size = new Size(preview.PatternSquaresX * preview.SizeX+Constants.BorderSize*2, preview.PatternSquaresY * preview.SizeY+Constants.BorderSize*2);
            previewPattern.Location = Constants.CalcPatternLocation(preview.SameScreen, preview.PatternSquaresX, preview.SizeX,
                preview.PatternSquaresY, preview.SizeY);

            previewPattern.BorderStyle = BorderStyle.None;
            previewPattern.BackColor = preview.BackgroundColor;

            //Adding Color for Picture and Pattern
            List<Color> colors = new List<Color>();
            colors.Add(preview.Color1);
            colors.Add(preview.Color2);
            if (preview.Color3Checked) colors.Add(preview.Color3);
            if (preview.Color4Checked) colors.Add(preview.Color4);
            if (preview.Color5Checked) colors.Add(preview.Color5);
            if (preview.Color6Checked) colors.Add(preview.Color6);

            Pattern pattern = new Pattern(preview.PatternSquaresX, preview.PatternSquaresY, colors);
            pattern.Create();
            System.Drawing.Bitmap patternBMP = pattern.Paint(new Size(preview.SizeX, preview.SizeY),preview.BorderColor);

            Picture picture = new Picture(preview.SquaresX, preview.SquaresY, colors);
            picture.Create();
            picture.RemoveAndAddPattern(pattern);
            System.Drawing.Bitmap pictureBMP = picture.Paint(new Size(preview.SizeX, preview.SizeY),preview.BorderColor);

            previewPicture.Image = pictureBMP;
            previewPattern.Image = patternBMP;

            this.Controls.Add(previewPattern);
            this.Controls.Add(previewPicture);


            if (preview.SameScreen)
            {
                this.Click += new EventHandler(previewForm_Click_SameScreen);
                previewPicture.Click += new EventHandler(previewForm_Click_SameScreen);
                previewPattern.Click += new EventHandler(previewForm_Click_SameScreen);
            }
            else
            {
                this.Click += new EventHandler(previewForm_Click_DiffScreen);
                previewPattern.Click += new EventHandler(previewForm_Click_DiffScreen);
                this.Controls[0].Visible = true;
                this.Controls[1].Visible = false;
                previewPicture.Click += new EventHandler(previewForm_Click_SameScreen);
            }

        }



        /// <summary>
        /// Handles the DiffScreen event of the previewForm_Click control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void previewForm_Click_DiffScreen(object sender, EventArgs e)
        {
            this.Controls[0].Visible = false;
            this.Controls[1].Visible = true;
            this.Click -= new EventHandler(previewForm_Click_DiffScreen);
            this.Click += new EventHandler(previewForm_Click_SameScreen);
        }

        /// <summary>
        /// Handles the SameScreen event of the previewForm_Click control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void previewForm_Click_SameScreen(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
