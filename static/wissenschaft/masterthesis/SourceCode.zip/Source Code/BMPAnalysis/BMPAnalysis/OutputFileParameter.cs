using System;
using System.Collections.Generic;
using System.Text;

namespace BMPAnalysis
{
    /// <summary>
    /// Represents the parameter for the calculation of the Analysis and creating the output files.
    /// </summary>
    public class OutputFileParameter
    {
        private bool excel = false;

        /// <summary>
        /// Gets or sets a value indicating whether the output should be an Excel sheet.
        /// </summary>
        /// <value><c>true</c> if output should be an Excel sheet; otherwise, <c>false</c>.</value>
        /// <remarks>Defines a XOR-Relationship between the excel and the rawData Flag.</remarks>
        public bool Excel
        {
            get { return excel; }
            set { 
                excel = value;
                /* Defines a XOR-Relationship between the excel and the rawData Flag */
                if (value) rawData = !value;
                else rawData = value;

            }
        }

        private bool rawData = true;

        /// <summary>
        /// Gets or sets a value indicating whether the output should be raw data (txt) files.
        /// </summary>
        /// <value><c>true</c> if output should be raw data (txt) files; otherwise, <c>false</c>.</value>
        /// <remarks>Defines a XOR-Relationship between the excel and the rawData Flag.</remarks>
        public bool RawData
        {
            get { return rawData; }
            set { 
                rawData = value;
                /* Defines a XOR-Relationship between the excel and the rawData Flag */
                if (value) excel = !value; 
                else excel = value;
            }
        }


        private int radius = 1;

        /// <summary>
        /// Gets or sets the radius. Indicates how many surrounding squares of a fixation (additional to the pattern size) should
        /// be included to the fixation calculation.
        /// </summary>
        /// <value>The radius.</value>
        public int Radius
        {
            get { return radius; }
            set { radius = value; }
        }

        private bool includePatternFixation = false;

        /// <summary>
        /// Gets or sets a value indicating whether the pattern fixation should be included or not.
        /// </summary>
        /// <value>
        /// 	<c>true</c> if pattern fixation should be included; otherwise, <c>false</c>.
        /// </value>
        public bool IncludePatternFixation
        {
            get { return includePatternFixation; }
            set { includePatternFixation = value; }
        }

        private bool includeFirstFixation = false;


        /// <summary>
        /// Gets or sets a value indicating whether the first fixation of a trial should be included.
        /// </summary>
        /// <value>
        /// 	<c>true</c> if the first fixation of a trial should be included; otherwise, <c>false</c>.
        /// </value>
        public bool IncludeFirstFixation
        {
            get { return includeFirstFixation; }
            set { includeFirstFixation = value; }
        }

        private bool shortExcelReport = false;

        /// <summary>
        /// Gets or sets a value indicating whether a short excel report should be generated.
        /// </summary>
        /// <value><c>true</c> if a short excel report should be generated; otherwise, <c>false</c>.</value>
        public bool ShortExcelReport
        {
            get { return shortExcelReport; }
            set { shortExcelReport = value; }
        }

        private double similarityMeasure = 1;

        /// <summary>
        /// Gets or sets the similarity measure, which is a percentage value that describes how similar two vectors are to each other.
        /// </summary>
        /// <value>The similarity measure.</value>
        public double SimilarityMeasure
        {
            get { return similarityMeasure; }
            set { similarityMeasure = value; }
        }

        private int from = 1;

        /// <summary>
        /// Gets or sets at which trial to start the output.
        /// </summary>
        /// <value>At which trial to start the output.</value>
        public int From
        {
            get { return from; }
            set { from = value; }
        }

        private int to = 1;

        /// <summary>
        /// Gets or sets at which trial to end the output.
        /// </summary>
        /// <value>At which trial to end the output.</value>
        public int To
        {
            get { return to; }
            set { to = value; }
        }

        private int top10 = 15;

        /// <summary>
        /// Gets or sets how many vectors should be included in the final ranking list.
        /// </summary>
        /// <value>How many vectors should be included in the final ranking list.</value>
        public int Top10
        {
            get { return top10; }
            set { top10 = value; }
        }

        private string outputFolder = @"";

        /// <summary>
        /// Gets or sets the output folder. Only signification if raw data (txt) files are desired.
        /// </summary>
        /// <value>The output folder.</value>
        public string OutputFolder
        {
            get { return outputFolder; }
            set { outputFolder = value; }
        }

        private int moveX = 0;

        /// <summary>
        /// Gets or sets if and where the fixation position should be moved in vertical direction. For instance, a value of -1 would move the fixation 1 square
        /// to the left.
        /// </summary>
        /// <value>If and where the fixation position should be moved in vertical direction.</value>
        public int MoveX
        {
            get { return moveX; }
            set { moveX = value; }
        }

        private int moveY = 0;

        /// <summary>
        /// Gets or sets if and where the fixation position should be moved in horizontal direction. For instance, a value of -1 would move the fixation 1 square
        /// up.
        /// </summary>
        /// <value>if and where the fixation position should be moved in horizontal direction.</value>
        public int MoveY
        {
            get { return moveY; }
            set { moveY = value; }
        }

        /// <summary>
        /// Returns a String that represents the current OutputFileParameter.
        /// </summary>
        /// <returns>
        /// A String that represents the current OutputFileParameter.
        /// </returns>
        public override string ToString()
        {
            return "Radius:" + (Radius + 1) + " | " +
                "Including Pattern Fixations:" + IncludePatternFixation.ToString() + " | " +
                "Including First Fixation:" + IncludeFirstFixation.ToString() + " | " +
                "Similarity Measure:" + SimilarityMeasure.ToString() + " | " +
                "Display Top " + Top10.ToString() + " | " +
                "Move Center X by:" + MoveX.ToString() + " | " +
                "Move Fixation Center Y by:" + MoveY.ToString() + " | " +
                "From:" + (From + 1) + " | " +
                "To:" + (To + 1) + " | ";
        }

                   
    }
}
