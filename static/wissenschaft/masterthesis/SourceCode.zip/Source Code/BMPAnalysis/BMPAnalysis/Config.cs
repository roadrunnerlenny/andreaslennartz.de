using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace BMPAnalysis
{
    /// <summary>
    /// Represents a configuration file which contains the resolution of the display screen and the overall 
    /// number of trials of an experiment
    /// </summary>
    public class Config
    {
        private int displayX = 0;

        /// <summary>
        /// Gets or sets the width of the display.
        /// </summary>
        /// <value>The width of the display.</value>
        public int DisplayX
        {
            get { return displayX; }
            set { displayX = value; }
        }

        private int displayY = 0;

        /// <summary>
        /// Gets or sets the height of the display.
        /// </summary>
        /// <value>The height of the display.</value>
        public int DisplayY
        {
            get { return displayY; }
            set { displayY = value; }
        }

        private int numTrials = 0;

        /// <summary>
        /// Gets or sets the overall number of trials.
        /// </summary>
        /// <value>The overall number of trials.</value>
        public int NumTrials
        {
            get { return numTrials; }
            set { numTrials = value; }
        }

        /// <summary>
        /// Loads the specified config filef.
        /// </summary>
        /// <param name="filename">The filename of the config file.</param>
        /// <returns></returns>
        public void Load(string filename)
        {
            using (TextReader tr = new StreamReader(filename))
            {
                this.DisplayX = Int32.Parse(tr.ReadLine());
                this.DisplayY = Int32.Parse(tr.ReadLine());
                this.NumTrials = Int32.Parse(tr.ReadLine());
            }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Config"/> class.
        /// </summary>
        public Config() { ;}

        /// <summary>
        /// Initializes a new instance of the <see cref="Config"/> class.
        /// </summary>
        /// <param name="filename">The filename of the config file to be load.</param>
        public Config(string filename)
        {
            Load(filename);
        }
    }
}
