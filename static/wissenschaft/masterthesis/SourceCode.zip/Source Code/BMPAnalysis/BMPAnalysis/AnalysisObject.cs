using System;
using System.Collections.Generic;
using System.Text;
using BMPBuilder;
using ASCLibrary;

namespace BMPAnalysis
{
    /// <summary>
    /// This object contains all data needed to generate an Analysis. 
    /// </summary>
    public class AnalysisObject
    {
        private string name = "";

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        private string experimentFolder = @"";

        /// <summary>
        /// Gets or sets the experiment folder.
        /// </summary>
        /// <value>The experiment folder.</value>
        public string ExperimentFolder
        {
            get { return experimentFolder; }
            set { experimentFolder = value; }
        }

        private string dataFile = @"";

        /// <summary>
        /// Gets or sets the data file.
        /// </summary>
        /// <value>The data file.</value>
        public string DataFile
        {
            get { return dataFile; }
            set { dataFile = value; }
        }

        private ASCData ascData = null;

        /// <summary>
        /// Gets or sets the asc data.
        /// </summary>
        /// <value>The asc data.</value>
        public ASCData AscData
        {
            get { return ascData; }
            set { ascData = value; }
        }

        private ExperimentData experiment = null;

        /// <summary>
        /// Gets or sets the experiment data.
        /// </summary>
        /// <value>The experiment data.</value>
        public ExperimentData Experiment
        {
            get { return experiment; }
            set { experiment = value; }
        }

        private Config config = null;

        /// <summary>
        /// Gets or sets the config data.
        /// </summary>
        /// <value>The config data.</value>
        public Config Config
        {
            get { return config; }
            set { config = value; }
        }

        private List<Pattern> patternList = null;

        /// <summary>
        /// Gets or sets the pattern list.
        /// </summary>
        /// <value>The pattern list.</value>
        public List<Pattern> PatternList
        {
            get { return patternList; }
            set { patternList = value; }
        }

        private List<Picture> pictureList = null;

        /// <summary>
        /// Gets or sets the picture list.
        /// </summary>
        /// <value>The picture list.</value>
        public List<Picture> PictureList
        {
            get { return pictureList; }
            set { pictureList = value; }
        }

        private OutputFileParameter parameterList = new OutputFileParameter();

        /// <summary>
        /// Gets or sets the parameter list.
        /// </summary>
        /// <value>The parameter list.</value>
        public OutputFileParameter ParameterList
        {
            get { return parameterList; }
            set { parameterList = value; }
        }


   

    }
}
