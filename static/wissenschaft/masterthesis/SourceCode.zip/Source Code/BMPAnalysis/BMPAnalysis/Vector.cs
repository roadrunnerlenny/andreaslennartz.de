using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using BMPBuilder;
using ASCLibrary;

namespace BMPAnalysis 
{
    /// <summary>
    /// A vector is a one-dimensional representation of a two dimensional pattern. 
    /// If the pattern is e.g. a 3x3 array of different color values, a vector of this pattern
    /// would be an one-dimensional array with the length 9. The first three color values
    /// of the vector array would be identical with the top three color values of the
    /// pattern array.(The top left, top center and top right colors). The second group of
    /// three would correspond to the colors in the middle row, and the the last three
    /// values would be the ones in the bottom row. Therefore, the conversion is row
    /// wise from top to bottom. A vector can be written as a string by writing the
    /// abbreviated color letters in a single row (E.g.: "WWWB" is a vector string for
    /// describing a vector with the color sequence white,white,white and black.)
    /// </summary>
    public class Vector : IComparable
    {
        private int[] colors;

        /// <summary>
        /// Gets the color values as integers of the vector array.
        /// </summary>
        /// <value>Te color values as integers of the vector array.</value>
        public int[] Colors
        {
            get { return colors; }
        }

        /// <summary>
        /// A list of all colors the vector can (but may not) contain, stored as integer values.
        /// </summary>
        private int[] colorList;

        /// <summary>
        /// Gets or sets a list of all colors the vector can (but may not) contain.
        /// </summary>
        /// <value>A list of all colors the vector can (but may not) contain.</value>
        public List<Color> ColorList
        {
            set
            {
                colorList = new int[value.Count];
                for (int i = 0; i < value.Count; i++)
                    colorList[i] = value[i].ToArgb();
            }
            get
            {
                List<Color> colList = new List<Color>();
                for (int i = 0; i < colorList.Length; i++)
                    colList.Add(Color.FromArgb(colorList[i]));
                return colList;
            }
        }

            private int count = 0;

        private long weight = -1;

        /// <summary>
        /// Gets or sets the weight of the vector. This can be the duration of a fixation.  
        /// </summary>
        /// <value>The weight.</value>
        public long Weight
        {
            get { return weight; }
            set { weight = value; }
        }

        /// <summary>
        /// Gets or sets the size of the vector. This is basically the length of the vector array.
        /// </summary>
        /// <value>The size of the vector.</value>
        public int Size
        {
            get 
            { 
                return colors.Length; 
            }
            set 
            { 
                colors = new int[value];
                for (int i = 0; i < colors.Length; i++ )
                    colors[count] = 0;
                count = 0;
            }
        }

        private long frequency = 1;

        /// <summary>
        /// Gets or sets the frequency. If a 
        /// number of vectors are combined in a list, the frequency describes the occurrences
        /// in this list.
        /// </summary>
        /// <value>The frequency.</value>
        public long Frequency
        {
            get { return frequency; }
            set { frequency = value; }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Vector"/> class.
        /// </summary>
        /// <param name="size">The size of the vector. This is basically the length of the vector array.</param>
        /// <param name="colorList">A list of all colors the vector can (but may not) contain. </param>
        public Vector(int size, List<Color> colorList)
        {
            this.Size = size;
            this.ColorList = colorList;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Vector"/> class.
        /// </summary>
        /// <param name="colorArray">The color array of a two dimensional pattern array.</param>
        /// <param name="colorList">A list of all colors the vector can (but may not) contain. </param>
        public Vector(int[,] colorArray, List<Color> colorList)
        {
            this.Size = (colorArray.GetUpperBound(0)+1) * (colorArray.GetUpperBound(1)+1);
            for (int x = colorArray.GetLowerBound(0); x <= colorArray.GetUpperBound(0); x++)
                for (int y = colorArray.GetLowerBound(1); y <= colorArray.GetUpperBound(1); y++)
                    this.Add(colorArray[y, x]); //Attention: x und y are swapped!
            this.ColorList = colorList;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Vector"/> class.
        /// </summary>
        /// <param name="size">The size of the vector. This is basically the length of the vector array.</param>
        /// <param name="weight">The weight of the vector, e.g. the duration of a fixation.</param>
        /// <param name="colorList">A list of all colors the vector can (but may not) contain.</param>
        public Vector(int size, long weight, List<Color> colorList)
        {
            this.Weight = weight;
            this.Size = size;
            this.ColorList = colorList;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Vector"/> class.
        /// </summary>
        /// <param name="vector">An existing vector that values will be copied into the new vector object, except
        /// its frequency and its weight.</param>
        /// <param name="weight">The new weight of the new vector.</param>
        /// <param name="frequency">The new frequency of the new vector.</param>
        public Vector(Vector vector, long weight, long frequency)
        {
            this.Size = vector.Colors.Length;
            for (int i = 0; i < vector.Colors.Length; i++)
            {
                colors[i] = vector.Colors[i];
            }
            this.Frequency = frequency;
            this.Weight = weight;
            this.ColorList = vector.ColorList;
        }

        /// <summary>
        /// Adds the specified color to the vector. If the vector is newly instantiated, this will start at the first
        /// element of the vector, and continues with the next element, until the vector is filled. 
        /// </summary>
        /// <param name="color">The color value as integer that should be added at the next unset vector position.</param>
        public void Add(int color)
        {
            colors[count] = color;
            if (count < (colors.Length-1)) count++;
            else count = 0;
        }

        /// <summary>
        /// Adds the specified color to the vector. If the vector is newly instantiated, this will start at the first
        /// element of the vector, and continues with the next element, until the vector is filled. 
        /// </summary>
        /// <param name="color">The color value as color object that should be added at the next unset vector position.</param>
        public void Add(Color color)
        {
            this.Add(color.ToArgb());
        }

        /// <summary>
        /// Returns a <see cref="T:System.String"></see> (a vector string) that represents the current <see cref="T:System.Object"></see>.
        /// </summary>
        /// <returns>
        /// A <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
        /// </returns>
        public override string ToString()
        {
            string vectorstring = "";
            foreach (int color in colors)
            {
                vectorstring += Constants.ColorIntToString(color, true);
            }
            return vectorstring;
        }

        /// <summary>
        /// Compares the current instance with another vector object. Uses the frequency to compare these vectors.
        /// </summary>
        /// <param name="obj">An object to compare with this instance.</param>
        /// <returns>
        /// A 32-bit signed integer that indicates the relative order of the objects being compared. The return value has these meanings: Value Meaning Less than zero This instance is less than obj. Zero This instance is equal to obj. Greater than zero This instance is greater than obj.
        /// </returns>
        /// <exception cref="T:System.ArgumentException">Argument not of type Vector</exception>
        public int CompareTo(object obj) {
            if (obj is Vector)
            {
                Vector v = (Vector)obj;
                if (frequency > v.frequency)
                {
                    return -1;
                }
                else if (frequency < v.frequency)
                {
                    return 1;
                }
                else if (frequency == v.frequency)
                {
                    if (weight > v.weight) return -1;
                    if (weight < v.weight) return 1;
                    if (weight == v.weight) return 0;
                }
                return 0;
            }
            else throw new ArgumentException("Argument not of type Vector!");
        }

        /// <summary>
        /// Compares two vectors with each other. Uses the weight to compare these vectors.
        /// </summary>
        /// <param name="obj1">The first vector</param>
        /// <param name="obj2">The second vector.</param>
        /// <returns>
        /// A 32-bit signed integer that indicates the relative order of the objects being compared. The return value has these meanings: Value Meaning Less than zero This instance is less than obj. Zero This instance is equal to obj. Greater than zero This instance is greater than obj.
        /// </returns>
        /// <exception cref="T:System.ArgumentException">Argument not of type Vector</exception>
        public static int CompareToUsingWeight(object obj1,object obj2)
        {
            if (obj1 is Vector && obj2 is Vector)
            {
                Vector v1 = (Vector)obj1;
                Vector v2 = (Vector)obj2;
                if (v1.weight > v2.weight) return -1;
                else if (v1.weight < v2.weight) return 1;
                else return 0;
            }
            else throw new ArgumentException("Argument not of type Vector!");
        }

        /// <summary>
        /// Calculates the similarity of the current instance with another vector. The similarity is a percentage which 
        /// indicates how many positions have the same value in both vectors.
        /// </summary>
        /// <param name="v1">The vector to compare the current instance with.</param>
        /// <returns>The percentage which indicates how many positions have the same value in both vectors.</returns>
        public double Compare(Vector v1)
        {
            return Vector.Compare(v1, this);
        }

        /// <summary>
        /// Calculates the similarity of two vectors  with each other. The similarity is a percentage which 
        /// indicates how many positions have the same value in both vectors.
        /// </summary>
        /// <param name="v1">The first vector to compare with the second vector.</param>
        /// <param name="v1">The second vector to compare with the first vector.</param>
        /// <returns>The percentage which indicates how many positions have the same value in both vectors.</returns>
        public static double Compare(Vector v1, Vector v2) 
        {
            if (v1.Size != v2.Size) throw new ArithmeticException();
            int matches = 0;
            for (int i = 0; i < v1.Size; i++)
            {
                if (v1.Colors[i] == v2.Colors[i]) matches++;
            }
            double pctg = Math.Round((double)(1.0/(double)(v1.Size)),2);
            return pctg * (double)(matches);
        }


        /// <summary>
        /// Swaps the colors of two positions in the vector array.
        /// </summary>
        /// <param name="pos1">The first position in the vector array to be swapped with the second position.</param>
        /// <param name="pos1">The second position in the vector array to be swapped with the first position.</param>
        /// <returns><c>True</c> if both position where inside the vector array range.</returns>
        public bool Swap(int pos1, int pos2)
        {
            try
            {
                int swap = colors[pos1];
                colors[pos1] = colors[pos2];
                colors[pos2] = swap;
                return true;
            }
            catch (ArgumentOutOfRangeException ae)
            {
                return false;
            }
        }

        /// <summary>
        /// Determines whether the specified Vector is equal to the current Vector.
        /// </summary>
        /// <param name="obj">The Vector to compare with the current Vector.</param>
        /// <returns>
        /// true if the specified Vector is equal to the current Vector; otherwise, false.
        /// </returns>
        public override bool Equals(object obj)
        {
            try
            {
                Vector compareVector = (Vector)obj;
                bool equal = true;
                for (int i = 0; i < colors.Length; i++)
                {
                    if (colors[i] != compareVector.Colors[i])
                    {
                        equal = false;
                        break;
                    }
                }
                return equal;
            }
            catch (ArgumentOutOfRangeException)
            {
                return false;
            }

        }

        /// <summary>
        /// Calculates a new average vector of a list of vectors. Counts the frequency (or the total weight) of each color for each position in all vectors,
        /// and writes the color with the highest frequency (or highest weight) in the new average vector. If the frequency for a position is the same for all colors,
        /// the color which has color the highest value in the color distribution is taken. 
        /// </summary>
        /// <param name="vectorList">The vector list to build the new average vector of.</param>
        /// <param name="range">The range, how many of the vectors in the vector list should be considered. If the value is smaller
        /// than the size of the vector list, the first vectors up to the given range of the list will be taken</param>
        /// <param name="colorList">The list of all possible colors as an integer array that can, but may not occur in the vectors. </param>
        /// <param name="colorDistribution">The color distribution of all possible colors that can, but may not occur in the vectors. </param>
        /// <param name="useWeight">if set to <c>true</c>, the weight instead the frequency is used to build the average vector.</param>
        /// <returns>The new average vector</returns>
        public static Vector AverageVector(List<Vector> vectorList, int range, int[] colorList, double[] colorDistribution, bool useWeight)
        {
            try
            {
                long[,] colorCount = new long[vectorList[0].Size,colorList.Length];
                Vector averageVector = new Vector(vectorList[0].Size,-1,vectorList[0].ColorList);
                for (int pos = 0; pos < vectorList[0].Size; pos++)
                {
                    for (int nr = 0; nr < range; nr++)
                    {
                        Vector v = vectorList[nr];
                        for (int i = 0; i < colorList.Length; i++)
                        {
                            if (v.Colors[pos] == colorList[i])
                                if (!useWeight)
                                    colorCount[pos, i]++;
                                else
                                    colorCount[pos, i] += v.Weight;
                        }
                    }
                   
                }
                for (int pos = 0; pos < vectorList[0].Size; pos++)
                {
                    long highestColor = colorCount[pos,0];
                    int highestColorPos = 0;
                    bool even = false;
                    List<int> evenColorsPos = new List<int>();
                    for (int i = 0; i < colorList.Length - 1; i++)
                    {
                        if (highestColor < colorCount[pos, i + 1])
                        {
                            highestColor = colorCount[pos,i+1]; 
                            highestColorPos = i+1;
                            even = false;
                            evenColorsPos = new List<int>();
                        }
                        else if (highestColor==colorCount[pos,i+1]) 
                        {
                            if (!evenColorsPos.Contains(i)) evenColorsPos.Add(i);
                            evenColorsPos.Add(i+1);
                            even = true;
                        }
                    }
                    if (even)
                    {
                        double highestColorDistribution = colorDistribution[evenColorsPos[0]];
                        int disPos = 0;
                        for(int j=1;j<evenColorsPos.Count;j++) {
                            if (highestColorDistribution < colorDistribution[evenColorsPos[j]]) {
                                highestColorDistribution = colorDistribution[evenColorsPos[j]];
                                disPos = j;
                            }
                        }
                       
                        averageVector.Add(colorList[disPos]);
                    }
                    else
                    {
                        averageVector.Add(colorList[highestColorPos]);
                    }
                }
                return averageVector;

            }
            catch (ArgumentOutOfRangeException ae)
            {
                return null;
            }
        }

        /// <summary>
        /// Calculates a new average vector of a list of vectors. Counts the frequency (or the total weight) of each color for each position in all vectors,
        /// and writes the color with the highest frequency (or highest weight) in the new average vector. If the frequency for a position is the same for all colors,
        /// the color which has color the highest value in the color distribution is taken. 
        /// </summary>
        /// <param name="vectorList">The vector list to build the new average vector of.</param>
        /// <param name="colorList">The list of all possible colors as a list of color objects that can, but may not occur in the vectors. </param>
        /// <param name="colorDistribution">The color distribution of all possible colors that can, but may not occur in the vectors. </param>
        /// <param name="useWeight">if set to <c>true</c>, the weight instead the frequency is used to build the average vector.</param>
        /// <returns>The new average vector.</returns>
        public static Vector AverageVector(List<Vector> vectorList, List<Color> colorList, double[] colorDistribution, bool useWeight)
        {
            int[] colorInt = new int[colorList.Count];
            for(int i=0;i<colorList.Count;i++) 
                colorInt[i] = colorList[i].ToArgb();
            int range = vectorList.Count;
            return AverageVector(vectorList, range, colorInt, colorDistribution,useWeight);          
        }

        /// <summary>
        /// Calculates a new average vector of a list of vectors. Counts the frequency (or the total weight) of each color for each position in all vectors,
        /// and writes the color with the highest frequency (or highest weight) in the new average vector. If the frequency for a position is the same for all colors,
        /// the color which has color the highest value in the color distribution is taken. 
        /// </summary>
        /// <param name="vectorList">The vector list to build the new average vector of.</param>
        /// <param name="colorList">The list of all possible colors as an integer array that can, but may not occur in the vectors. </param>
        /// <param name="colorDistribution">The color distribution of all possible colors that can, but may not occur in the vectors. </param>
        /// <param name="useWeight">if set to <c>true</c>, the weight instead the frequency is used to build the average vector.</param>
        /// <returns>The new average vector.</returns>
        public static Vector AverageVector(List<Vector> vectorList, int[] colorList, double[] colorDistribution, bool useWeight)
        {
            int range = vectorList.Count;
            return AverageVector(vectorList, range, colorList, colorDistribution, useWeight);   
        }

        /// <summary>
        /// Calculates a new average vector of a list of vectors. Counts the frequency (or the total weight) of each color for each position in all vectors,
        /// and writes the color with the highest frequency (or highest weight) in the new average vector. If the frequency for a position is the same for all colors,
        /// the color which has color the highest value in the color distribution is taken. 
        /// </summary>
        /// <param name="vectorList">The vector list to build the new average vector of.</param>
        /// <param name="range">The range, how many of the vectors in the vector list should be considered. If the value is smaller
        /// than the size of the vector list, the first vectors up to the given range of the list will be taken</param>
        /// <param name="colorList">The list of all possible colors as a list of color objects that can, but may not occur in the vectors. </param>
        /// <param name="colorDistribution">The color distribution of all possible colors that can, but may not occur in the vectors. </param>
        /// <param name="useWeight">if set to <c>true</c>, the weight instead the frequency is used to build the average vector.</param>
        /// <returns>The new average vector</returns>
        public static Vector AverageVector(List<Vector> vectorList, int range, List<Color> colorList, double[] colorDistribution, bool useWeight)
        {
            int[] colorInt = new int[colorList.Count];
            for (int i = 0; i < colorList.Count; i++)
                colorInt[i] = colorList[i].ToArgb();
            return AverageVector(vectorList, range, colorInt, colorDistribution, useWeight);
        }

        /// <summary>
        /// Creates a list of all possible vectors that can be created with the given amount of colors.
        /// </summary>
        /// <param name="colors">The possible colors that can, but may not appear in each vector.</param>
        /// <param name="dimX">The width of the pattern. The size of the vector will be the product of the given width and height of the pattern.</param>
        /// <param name="dimY">The height of the pattern. The size of the vector will be the product of the given width and height of the pattern.</param>
        /// <returns></returns>
        public static List<Vector> CreatePossibleVectors(List<Color> colors, int dimX, int dimY)
        {
            int size = (int)Math.Pow((double)colors.Count, (double)(dimX * dimY));
            List<Vector> possibleVectorList = new List<Vector>(size);

            int[] number = new int[dimX * dimY];
            for (int step = 0; step < size; step++)
            {
                Vector possibleVector = new Vector(dimX * dimY, colors);
                foreach (int c in number)
                    possibleVector.Add(colors[c].ToArgb());
                possibleVectorList.Add(possibleVector);
                for (int dec = 0; dec < number.Length; dec++)
                {
                    if (number[dec] < colors.Count - 1) { number[dec]++; break; }
                    if (number[dec] == colors.Count - 1) { number[dec] = 0; continue; }
                }
            }
            return possibleVectorList;
        }

        /// <summary>
        /// Calculates the percentage of the color distribution.
        /// </summary>
        /// <param name="decimals">How many decimal places the percentage should have.</param>
        /// <returns>An array containing the percentages for each color.</returns>
        public double[] ColorDistribution(int decimals)
        {
            double sqPctg = 1.0 / (double)(colors.Length);
            double[] pctgs = new double[colorList.Length];
            for (int p = 0; p < colorList.Length; p++)
                pctgs[p] = 0;
            for (int m = 0; m < colors.Length; m++)
                for (int p = 0; p < colorList.Length; p++)
                    try
                    {
                        if (colors[m] == colorList[p])
                            pctgs[p] += sqPctg;
                    }
                    catch (IndexOutOfRangeException ie)
                    {
                        pctgs[p] = 0;
                    }
            for (int p = 0; p < colorList.Length; p++)
                pctgs[p] = Math.Round(pctgs[p], decimals);
            return pctgs;
        }

        /// <summary>
        /// Returns a string which describes the percentage of the color distrubution.
        /// </summary>
        /// <param name="decimals">How many decimal places the percentage should have.</param>
        /// <returns>Describes the percentage of the color distrubution.</returns>
        public string ColorDistributionString(int decimals)
        {
            string s = "";
            double[] colDist = this.ColorDistribution(decimals);
            for (int i = 0; i < colDist.Length; i++)
                s += Constants.ColorIntToString(this.ColorList[i], true) + " " +(colDist[i]*100) + "% ";
            return s;
        }


    }
}
