using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using BMPBuilder;
using ASCLibrary;

namespace BMPAnalysis
{
    /// <summary>
    /// Creates and display text files that contain raw data with the fixations and results of the analysis.
    /// </summary>
    public class OutputFileRawData : OutputFile
    {
        private string outputFolder;

        private const string OUTPUT_PREFIX = "raw";
        private const string OUTPUT_PREFIX_LOOKUP = "lookup";
        private const string OUTPUT_PREFIX_RESULT = "result";

        private StreamWriter blockDataWriter = null;
        private StreamWriter lookupDataWriter = null;
        private StreamWriter resultDataWriter = null;


        /// <summary>
        /// Initializes a new instance of the <see cref="OutputFileRawData"/> class.
        /// </summary>
        /// <param name="parameterList">The parameter list.</param>
        /// <param name="experiment">The experiment data.</param>
        /// <param name="pictureList">The picture list.</param>
        /// <param name="patternList">The pattern list.</param>
        /// <param name="config">The config data.</param>
        /// <param name="ascData">The ASC data.</param>
        /// <param name="dataFile">The data file.</param>
        /// <param name="experimentFolder">The experiment folder.</param>
        public OutputFileRawData(OutputFileParameter parameterList, ExperimentData experiment, List<Picture> pictureList,
            List<Pattern> patternList, Config config, ASCData ascData, string dataFile, string experimentFolder)
            : base(parameterList, experiment, pictureList,
            patternList, config, ascData, dataFile, experimentFolder)
        {
            ;
        }

        /// <summary>
        /// Inits the output.
        /// </summary>
        protected override void initOutput()
        {
            this.outputFolder = Parameter.OutputFolder;
        }


        /// <summary>
        /// Called at the begin of a trial, when the pattern data is calculated.
        /// </summary>
        protected override void patternDataOutput()
        {
            blockDataWriter.Write("/* Pattern: "+PatternVector.ToString()+" | ID: ");
            for (int vNr = 1; vNr <= possiblePatternVectors.Count; vNr++)
            {
                if (PatternVector.Equals(possiblePatternVectors[vNr - 1]))
                {
                    blockDataWriter.Write(vNr.ToString());
                    break;
                }
            }
            blockDataWriter.Write(" | " + PatternVector.ColorDistributionString(2));
            blockDataWriter.WriteLine("*/");

        }

        /// <summary>
        /// Called when new fixation data has been calculated.
        /// </summary>
        /// <param name="posX">The vertical Position of the fixation.</param>
        /// <param name="posY">The horizontal Position of the fixation.</param>
        /// <param name="patternFixation">If set to <c>true</c> this function is also called if the fixation included the target pattern..</param>
        /// <param name="fix">The fixation data.</param>
        /// <param name="fixRect">The fixation rectangle.</param>
        /// <param name="fixationVectorList">The fixation vector list.</param>
        /// <param name="firstFixation">if set to <c>true</c> the fixation was the first fixation of the trial.</param>
        protected override void fixationOutput(int posX, int posY, bool patternFixation, ASCFixation fix, System.Drawing.Rectangle fixRect, List<Vector> fixationVectorList, bool firstFixation)
        {
            foreach (Vector fixVector in fixationVectorList)
            {
                for(int vNr=1;vNr<=possiblePatternVectors.Count;vNr++) {
                    if (fixVector.Equals(possiblePatternVectors[vNr-1]))
                    {
                        blockDataWriter.Write(vNr.ToString() + " ");
                        //fixationDataWriter.WriteLine(vNr.ToString());
                        break;
                    }
                }
                double[] colDist = PictureList[trialID].ColorDistribution(2,fixRect);
                for (int col=0;col<colDist.Length;col++) {
                    //fixationDataWriter.Write(colDist[col] + " ");
                    blockDataWriter.Write(colDist[col] + " ");
                }
                blockDataWriter.WriteLine();
            }

        }

        /// <summary>
        /// Called when new fixation data has been calculated and the fixation was outside the picture or included the target pattern.
        /// </summary>
        /// <param name="posX">The vertical position of the fixation (-1 if the fixation was outside).</param>
        /// <param name="posY">The horizontal position of the fixation (-1 if the fixation was outside).</param>
        /// <param name="patternFixation">if set to <c>true</c> the fixation included the target pattern..</param>
        protected override void fixationOutsideOutput(int posX, int posY, bool patternFixation)
        {
            ;
        }

        /// <summary>
        /// Called when the trial output starts.
        /// </summary>
        protected override void startTrialOutput()
        {
            blockDataWriter.WriteLine("/* Trial #"+(trialID+1)+" */");
        }

        /// <summary>
        /// Called when a new block of trials begins.
        /// </summary>
        protected override void newBlockOutput()
        {
            string expName = DataFile.Substring(DataFile.LastIndexOf(@"\")+1);
            expName = expName.Substring(0, expName.Length-4);
            if (blockDataWriter!=null) blockDataWriter.Close();
            blockDataWriter = new StreamWriter(outputFolder + expName + "_" + OUTPUT_PREFIX + (block + 1) + ".txt");
            if (lookupDataWriter != null) lookupDataWriter.Close();
            lookupDataWriter = new StreamWriter(outputFolder + expName + "_" + OUTPUT_PREFIX_LOOKUP + (block + 1) + ".txt");
            if (resultDataWriter != null) resultDataWriter.Close();
            resultDataWriter = new StreamWriter(outputFolder + expName + "_" + OUTPUT_PREFIX_RESULT + (block + 1) + ".txt");

            blockDataWriter.WriteLine("/*");
            blockDataWriter.WriteLine(Parameter.ToString());
            blockDataWriter.WriteLine("Block #" + block.ToString());
            blockDataWriter.WriteLine("*/");
          
            for (int vNr = 1; vNr <= possiblePatternVectors.Count; vNr++)
            {
                lookupDataWriter.WriteLine(vNr.ToString()+":"+possiblePatternVectors[vNr - 1].ToString());
            }
            
        }

        /// <summary>
        /// Writes the ranking.
        /// </summary>
        /// <param name="ranking">The ranking.</param>
        /// <param name="caption">The caption.</param>
        /// <param name="colorDist">The color dist.</param>
        private void writeRanking(List<Vector> ranking, string caption, double[] colorDist) {
            resultDataWriter.WriteLine(caption);
            for (int top10 = 0; top10 < Parameter.Top10 && top10 < ranking.Count; top10++)
            {
                int rank = top10 + 1;
                resultDataWriter.Write(rank + ":" + ranking[top10].ToString());
                resultDataWriter.Write(" | Frequency:" + ranking[top10].Frequency);
                resultDataWriter.Write(" | Weight:" + ranking[top10].Weight);
                resultDataWriter.Write(" | " + ranking[top10].ColorDistributionString(2));
                resultDataWriter.Write(" | Similarity " + PatternVector.Compare(ranking[top10]));
                resultDataWriter.WriteLine();

                if (rank > 1 && (rank == 3 || (rank % 5 == 0)))
                {
                    Vector top10Vector = Vector.AverageVector(ranking, rank, PictureList[trialID].Colors, colorDist, false);
                    Vector top10VectorWW = Vector.AverageVector(ranking, rank, PictureList[trialID].Colors, colorDist, true);
                    resultDataWriter.WriteLine("    Average Vector without Weight: " + top10Vector.ToString() + " | " + top10Vector.ColorDistributionString(2) + " | Similarity: " + PatternVector.Compare(top10Vector));
                    resultDataWriter.WriteLine("    Average Vector with Weight: " + top10VectorWW.ToString() + " | " + top10VectorWW.ColorDistributionString(2) + " | Similarity: " + PatternVector.Compare(top10VectorWW));

                }
            }
        }

        /// <summary>
        /// Called when the last item of a trial block has been passed
        /// </summary>
        /// <param name="ranking">The ranking list of fixations the current trial block, , ranked by frequency.</param>
        /// <param name="averageRanking">The ranking list of possbile Patterns with high similarity to the fixations, ranked by frequency.</param>
        /// <param name="rankingWithWeight">The ranking list of fixations the current trial block, , ranked by total duration.</param>
        /// <param name="averageRankingWithWeight">The ranking list of possbile Patterns with high similarity to the fixations, ranked by total duration.</param>
        /// <param name="averageVector">The overall average vector of all fixation.</param>
        /// <param name="averageVectorWW">The overall average vector, considering the duration. of the fixations.</param>
        /// <param name="overallColorDist">The overall color dist.</param>
        /// <param name="overallColorDist_M">The overall color dist_ M.</param>
        /// <param name="cornerFixationRanking">The  ranking of the sub-fixations.</param>
        /// <param name="cornerFixationRankingWithWeight">The ranking of the sub-fixations with weight.</param>
        /// <param name="cornerSimilarityRanking">The ranking of the sub-patterns with a high similarity to the target-pattern.</param>
        /// <param name="cornerSimilarityRankingWithWeight">The ranking of the sub-patterns with a high similarity to the target-pattern, ranked by weight</param>
        /// <param name="combinedCornerFixationRanking">The ranking of the sub-fixations with all combined to one pattern</param>
        /// <param name="combinedCornerFixationRankingWW">The ranking of the sub-fixations with all combined to one pattern, considering weight</param>
        /// <param name="combinedCornerSimilarityRanking">The ranking of the sub-patterns with a high similarity to the target pattern, all combined to one pattern</param>
        /// <param name="combinedCornerSimilarityRankingWW">The ranking of the sub-patterns with a high similarity to the target pattern, all combined to one pattern, considering weight</param>
        /// <param name="allCornerFixationRanking">A ranking of all sub-fixations, not divided by corners.</param>
        /// <param name="allCornerFixationRankingWW">A ranking of all sub-fixations, not divided by corners, cosidering weight.</param>
        /// <param name="allCornerSimilarityRanking">A ranking of all sub-fixations with a high similarity to the target pattern, not divided by corners.</param>
        /// <param name="allCornerSimilarityRankingWW">A ranking of all sub-fixations with a high similarity to the target pattern, not divided by corners, considering weight.</param>
        /// <param name="percentageRanking">A ranking where a score for each pattern was calculated.</param>
        protected override void lastItemOfBlockOutput(List<Vector> ranking, List<Vector> averageRanking, 
            List<Vector> rankingWithWeight, List<Vector> averageRankingWithWeight, 
            Vector averageVector, Vector averageVectorWW, 
            List<ColorDistribution>[] overallColorDist, double[] overallColorDist_M, 
            List<Vector>[] cornerFixationRanking, List<Vector>[] cornerFixationRankingWithWeight,
            List<Vector>[] cornerSimilarityRanking, List<Vector>[] cornerSimilarityRankingWithWeight,
            List<Vector> combinedCornerFixationRanking, List<Vector> combinedCornerFixationRankingWW,
            List<Vector> combinedCornerSimilarityRanking, List<Vector> combinedCornerSimilarityRankingWW,
            List<Vector> allCornerFixationRanking, List<Vector> allCornerFixationRankingWW,
            List<Vector> allCornerSimilarityRanking, List<Vector> allCornerSimilarityRankingWW,
            List<Vector> percentageRanking)
        {

            resultDataWriter.WriteLine("/*");
            resultDataWriter.WriteLine(Parameter.ToString());
            resultDataWriter.WriteLine("Block #" + block.ToString());
            resultDataWriter.WriteLine();

            resultDataWriter.WriteLine("Pattern Vector:" + PatternVector.ToString());
            resultDataWriter.WriteLine("Color Distribution:" + PatternVector.ColorDistributionString(2));
            resultDataWriter.WriteLine();

            resultDataWriter.WriteLine("Average Vector (all Fixations): " + averageVector.ToString());
            resultDataWriter.WriteLine("Color Distribution:" + averageVector.ColorDistributionString(2));
            resultDataWriter.WriteLine("Similarity to Pattern: " + PatternVector.Compare(averageVector));
            resultDataWriter.WriteLine();
            resultDataWriter.WriteLine();

            writeRanking(ranking, "High similarity ranking by frequency", overallColorDist_M);
            resultDataWriter.WriteLine("Target pattern rank: "+calculatePatternRank(ranking));
            resultDataWriter.WriteLine(); resultDataWriter.WriteLine();

            writeRanking(averageRanking, "Fixation ranking by frequency", overallColorDist_M);
            resultDataWriter.WriteLine(); resultDataWriter.WriteLine();

            writeRanking(rankingWithWeight, "High similarity ranking by weight", overallColorDist_M);
            resultDataWriter.WriteLine("Target pattern rank: " + calculatePatternRank(rankingWithWeight));
            resultDataWriter.WriteLine(); resultDataWriter.WriteLine();

            writeRanking(averageRankingWithWeight, "Fixation ranking by weight", overallColorDist_M);
            resultDataWriter.WriteLine(); resultDataWriter.WriteLine();
            
            resultDataWriter.WriteLine("Overall Color Distribution (mathematical):");
            for (int i = 0; i < overallColorDist_M.Length; i++)
                resultDataWriter.WriteLine("Color " + Constants.ColorIntToString(PatternVector.ColorList[i], true) + " " + (Math.Round(overallColorDist_M[i],2)*100) + "% ");

            resultDataWriter.WriteLine();
            
            resultDataWriter.WriteLine("Overall Color Distribution by Bins");
            for (int colNr = 0; colNr < overallColorDist.Length; colNr++)
            {
                resultDataWriter.WriteLine("Color " + Constants.ColorIntToString(PatternVector.ColorList[colNr], true));
                int rank = 1;
                foreach (ColorDistribution colorCount in overallColorDist[colNr])
                {
                    resultDataWriter.WriteLine((rank++) + " | " + (colorCount.Percentage*100) + "% | Frequency " + colorCount.Frequency);
                }
            }

            resultDataWriter.WriteLine(" */");
                
        }


        /// <summary>
        /// Called when the end of a trial has been passed.
        /// </summary>
        protected override void endTrialOutput()
        {
            ; 
        }

        /// <summary>
        /// Called at the end of all trials, now the calculated data can be displayed (if not already done).
        /// </summary>
        protected override void displayOutput()
        {
            ;
        }

        /// <summary>
        /// Always called at then end of all trials, even if exceptions/errors occured. Should be used to free all used resources.
        /// </summary>
        protected override void finishOutput()
        {
            if (blockDataWriter != null) blockDataWriter.Close();
            blockDataWriter = null;
            if (lookupDataWriter != null) lookupDataWriter.Close();
            lookupDataWriter = null;
            if (resultDataWriter != null) resultDataWriter.Close();
            resultDataWriter = null;
        }

        /// <summary>
        /// Calculates the pattern rank in the given ranking list.
        /// </summary>
        /// <param name="ranking">The ranking list.</param>
        /// <param name="caption">The caption.</param>
        /// <returns>The pattern rank</returns>
        private string calculatePatternRank(List<Vector> ranking)
        {
            int pos = 1;
            foreach (Vector v in ranking)
            {
                if (v.Equals(PatternVector)) break;
                pos++;
            }

            string positionSt = pos.ToString();
            if (pos > ranking.Count) positionSt = "Not found.";
            return positionSt;

        }
    }
}
