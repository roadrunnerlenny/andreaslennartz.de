namespace BMPAnalysis
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.experimentFolderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.chooseExperimentFolderLabel = new System.Windows.Forms.Label();
            this.experimentFolderLabel = new System.Windows.Forms.Label();
            this.chooseFileLabel = new System.Windows.Forms.Label();
            this.dataFileLabel = new System.Windows.Forms.Label();
            this.openDataFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.trialNumbersDescriptionLabel = new System.Windows.Forms.Label();
            this.trialNumbersLabel = new System.Windows.Forms.Label();
            this.fixationNumbersDescriptionLabel = new System.Windows.Forms.Label();
            this.fixationNumbersLabel = new System.Windows.Forms.Label();
            this.averageFixationsDescriptionLabel = new System.Windows.Forms.Label();
            this.averageFixationsLabel = new System.Windows.Forms.Label();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.infoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.generateBackgroundWorker = new System.ComponentModel.BackgroundWorker();
            this.outputProgressBar = new System.Windows.Forms.ProgressBar();
            this.outputLabel = new System.Windows.Forms.Label();
            this.radiusComboBox = new System.Windows.Forms.ComboBox();
            this.radiusLabel = new System.Windows.Forms.Label();
            this.includePatternFixationCheckBox = new System.Windows.Forms.CheckBox();
            this.similarityLabel = new System.Windows.Forms.Label();
            this.similarityComboBox = new System.Windows.Forms.ComboBox();
            this.fromLabel = new System.Windows.Forms.Label();
            this.fromTextBox = new System.Windows.Forms.TextBox();
            this.toLabel = new System.Windows.Forms.Label();
            this.toTextBox = new System.Windows.Forms.TextBox();
            this.top10Label = new System.Windows.Forms.Label();
            this.top10TextBox = new System.Windows.Forms.TextBox();
            this.rawDataFolderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.parameterGroupBox = new System.Windows.Forms.GroupBox();
            this.moveYComboBox = new System.Windows.Forms.ComboBox();
            this.moveLabel = new System.Windows.Forms.Label();
            this.moveXComboBox = new System.Windows.Forms.ComboBox();
            this.includeFirstFixationCheckBox = new System.Windows.Forms.CheckBox();
            this.ascDataGroupBox = new System.Windows.Forms.GroupBox();
            this.queueListView = new System.Windows.Forms.ListView();
            this.columnName = new System.Windows.Forms.ColumnHeader();
            this.columnRadius = new System.Windows.Forms.ColumnHeader();
            this.columnFrom = new System.Windows.Forms.ColumnHeader();
            this.columnTo = new System.Windows.Forms.ColumnHeader();
            this.moveXColumn = new System.Windows.Forms.ColumnHeader();
            this.moveYColumn = new System.Windows.Forms.ColumnHeader();
            this.addButton = new System.Windows.Forms.Button();
            this.deleteButton = new System.Windows.Forms.Button();
            this.generateExcelButton = new System.Windows.Forms.Button();
            this.rawDataButton = new System.Windows.Forms.Button();
            this.dataFileButton = new System.Windows.Forms.Button();
            this.experimentFolderButton = new System.Windows.Forms.Button();
            this.shortExcelCheckBox = new System.Windows.Forms.CheckBox();
            this.menuStrip.SuspendLayout();
            this.parameterGroupBox.SuspendLayout();
            this.ascDataGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // experimentFolderBrowserDialog
            // 
            this.experimentFolderBrowserDialog.SelectedPath = "C:\\Documents and Settings\\Lenny\\My Documents\\Visual Studio 2005\\Projects\\Thesis\\B" +
                "MPExperimentData";
            // 
            // chooseExperimentFolderLabel
            // 
            this.chooseExperimentFolderLabel.AutoSize = true;
            this.chooseExperimentFolderLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.chooseExperimentFolderLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chooseExperimentFolderLabel.Location = new System.Drawing.Point(50, 36);
            this.chooseExperimentFolderLabel.Name = "chooseExperimentFolderLabel";
            this.chooseExperimentFolderLabel.Size = new System.Drawing.Size(170, 16);
            this.chooseExperimentFolderLabel.TabIndex = 0;
            this.chooseExperimentFolderLabel.Text = "Choose Experiment Folder:";
            // 
            // experimentFolderLabel
            // 
            this.experimentFolderLabel.AutoSize = true;
            this.experimentFolderLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.experimentFolderLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.experimentFolderLabel.Location = new System.Drawing.Point(50, 56);
            this.experimentFolderLabel.MaximumSize = new System.Drawing.Size(300, 0);
            this.experimentFolderLabel.MinimumSize = new System.Drawing.Size(300, 0);
            this.experimentFolderLabel.Name = "experimentFolderLabel";
            this.experimentFolderLabel.Size = new System.Drawing.Size(300, 16);
            this.experimentFolderLabel.TabIndex = 1;
            // 
            // chooseFileLabel
            // 
            this.chooseFileLabel.AutoSize = true;
            this.chooseFileLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.chooseFileLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chooseFileLabel.Location = new System.Drawing.Point(50, 93);
            this.chooseFileLabel.Name = "chooseFileLabel";
            this.chooseFileLabel.Size = new System.Drawing.Size(115, 16);
            this.chooseFileLabel.TabIndex = 3;
            this.chooseFileLabel.Text = "Choose Data File:";
            // 
            // dataFileLabel
            // 
            this.dataFileLabel.AutoSize = true;
            this.dataFileLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dataFileLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataFileLabel.Location = new System.Drawing.Point(50, 112);
            this.dataFileLabel.MaximumSize = new System.Drawing.Size(300, 0);
            this.dataFileLabel.MinimumSize = new System.Drawing.Size(300, 0);
            this.dataFileLabel.Name = "dataFileLabel";
            this.dataFileLabel.Size = new System.Drawing.Size(300, 16);
            this.dataFileLabel.TabIndex = 4;
            // 
            // openDataFileDialog
            // 
            this.openDataFileDialog.Filter = "ASC Files | *.asc";
            // 
            // trialNumbersDescriptionLabel
            // 
            this.trialNumbersDescriptionLabel.AutoSize = true;
            this.trialNumbersDescriptionLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.trialNumbersDescriptionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trialNumbersDescriptionLabel.Location = new System.Drawing.Point(15, 26);
            this.trialNumbersDescriptionLabel.Name = "trialNumbersDescriptionLabel";
            this.trialNumbersDescriptionLabel.Size = new System.Drawing.Size(110, 16);
            this.trialNumbersDescriptionLabel.TabIndex = 7;
            this.trialNumbersDescriptionLabel.Text = "Number of Trials:";
            // 
            // trialNumbersLabel
            // 
            this.trialNumbersLabel.AutoSize = true;
            this.trialNumbersLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.trialNumbersLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trialNumbersLabel.Location = new System.Drawing.Point(131, 26);
            this.trialNumbersLabel.Name = "trialNumbersLabel";
            this.trialNumbersLabel.Size = new System.Drawing.Size(15, 16);
            this.trialNumbersLabel.TabIndex = 8;
            this.trialNumbersLabel.Text = "0";
            // 
            // fixationNumbersDescriptionLabel
            // 
            this.fixationNumbersDescriptionLabel.AutoSize = true;
            this.fixationNumbersDescriptionLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.fixationNumbersDescriptionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fixationNumbersDescriptionLabel.Location = new System.Drawing.Point(15, 49);
            this.fixationNumbersDescriptionLabel.Name = "fixationNumbersDescriptionLabel";
            this.fixationNumbersDescriptionLabel.Size = new System.Drawing.Size(129, 16);
            this.fixationNumbersDescriptionLabel.TabIndex = 9;
            this.fixationNumbersDescriptionLabel.Text = "Number of Fixations:";
            // 
            // fixationNumbersLabel
            // 
            this.fixationNumbersLabel.AutoSize = true;
            this.fixationNumbersLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.fixationNumbersLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fixationNumbersLabel.Location = new System.Drawing.Point(150, 49);
            this.fixationNumbersLabel.Name = "fixationNumbersLabel";
            this.fixationNumbersLabel.Size = new System.Drawing.Size(15, 16);
            this.fixationNumbersLabel.TabIndex = 10;
            this.fixationNumbersLabel.Text = "0";
            // 
            // averageFixationsDescriptionLabel
            // 
            this.averageFixationsDescriptionLabel.AutoSize = true;
            this.averageFixationsDescriptionLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.averageFixationsDescriptionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.averageFixationsDescriptionLabel.Location = new System.Drawing.Point(15, 73);
            this.averageFixationsDescriptionLabel.Name = "averageFixationsDescriptionLabel";
            this.averageFixationsDescriptionLabel.Size = new System.Drawing.Size(150, 16);
            this.averageFixationsDescriptionLabel.TabIndex = 11;
            this.averageFixationsDescriptionLabel.Text = "Average Fixations/Trial:";
            // 
            // averageFixationsLabel
            // 
            this.averageFixationsLabel.AutoSize = true;
            this.averageFixationsLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.averageFixationsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.averageFixationsLabel.Location = new System.Drawing.Point(171, 73);
            this.averageFixationsLabel.Name = "averageFixationsLabel";
            this.averageFixationsLabel.Size = new System.Drawing.Size(15, 16);
            this.averageFixationsLabel.TabIndex = 12;
            this.averageFixationsLabel.Text = "0";
            // 
            // menuStrip
            // 
            this.menuStrip.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.menuStrip.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.toolStripMenuItem1});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(679, 24);
            this.menuStrip.TabIndex = 13;
            this.menuStrip.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(40, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Image = global::BMPAnalysis.Properties.Resources.exit;
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.infoToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(26, 20);
            this.toolStripMenuItem1.Text = "?";
            // 
            // infoToolStripMenuItem
            // 
            this.infoToolStripMenuItem.Image = global::BMPAnalysis.Properties.Resources.help;
            this.infoToolStripMenuItem.Name = "infoToolStripMenuItem";
            this.infoToolStripMenuItem.Size = new System.Drawing.Size(111, 22);
            this.infoToolStripMenuItem.Text = "Info";
            this.infoToolStripMenuItem.Click += new System.EventHandler(this.infoToolStripMenuItem_Click);
            // 
            // generateBackgroundWorker
            // 
            this.generateBackgroundWorker.WorkerReportsProgress = true;
            this.generateBackgroundWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.generateBackgroundWorker_DoWork);
            this.generateBackgroundWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.generateBackgroundWorker_RunWorkerCompleted);
            this.generateBackgroundWorker.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.generateBackgroundWorker_ProgressChanged);
            // 
            // outputProgressBar
            // 
            this.outputProgressBar.Location = new System.Drawing.Point(386, 451);
            this.outputProgressBar.Name = "outputProgressBar";
            this.outputProgressBar.Size = new System.Drawing.Size(207, 23);
            this.outputProgressBar.Step = 1;
            this.outputProgressBar.TabIndex = 15;
            // 
            // outputLabel
            // 
            this.outputLabel.AutoSize = true;
            this.outputLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.outputLabel.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.outputLabel.Location = new System.Drawing.Point(249, 456);
            this.outputLabel.Name = "outputLabel";
            this.outputLabel.Size = new System.Drawing.Size(101, 16);
            this.outputLabel.TabIndex = 16;
            this.outputLabel.Text = "Waiting for data";
            // 
            // radiusComboBox
            // 
            this.radiusComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.radiusComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.radiusComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radiusComboBox.FormattingEnabled = true;
            this.radiusComboBox.Items.AddRange(new object[] {
            "0",
            "1"});
            this.radiusComboBox.Location = new System.Drawing.Point(74, 53);
            this.radiusComboBox.Name = "radiusComboBox";
            this.radiusComboBox.Size = new System.Drawing.Size(41, 24);
            this.radiusComboBox.TabIndex = 17;
            // 
            // radiusLabel
            // 
            this.radiusLabel.AutoSize = true;
            this.radiusLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radiusLabel.Location = new System.Drawing.Point(14, 56);
            this.radiusLabel.Name = "radiusLabel";
            this.radiusLabel.Size = new System.Drawing.Size(54, 16);
            this.radiusLabel.TabIndex = 18;
            this.radiusLabel.Text = "Radius:";
            // 
            // includePatternFixationCheckBox
            // 
            this.includePatternFixationCheckBox.AutoSize = true;
            this.includePatternFixationCheckBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.includePatternFixationCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.includePatternFixationCheckBox.Location = new System.Drawing.Point(18, 113);
            this.includePatternFixationCheckBox.Name = "includePatternFixationCheckBox";
            this.includePatternFixationCheckBox.Size = new System.Drawing.Size(161, 20);
            this.includePatternFixationCheckBox.TabIndex = 19;
            this.includePatternFixationCheckBox.Text = "Include Pattern Fixation";
            this.includePatternFixationCheckBox.UseVisualStyleBackColor = true;
            // 
            // similarityLabel
            // 
            this.similarityLabel.AutoSize = true;
            this.similarityLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.similarityLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.similarityLabel.Location = new System.Drawing.Point(14, 84);
            this.similarityLabel.Name = "similarityLabel";
            this.similarityLabel.Size = new System.Drawing.Size(121, 16);
            this.similarityLabel.TabIndex = 20;
            this.similarityLabel.Text = "Similarity Measure:";
            // 
            // similarityComboBox
            // 
            this.similarityComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.similarityComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.similarityComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.similarityComboBox.FormattingEnabled = true;
            this.similarityComboBox.Items.AddRange(new object[] {
            "0.70",
            "0.75",
            "0.80",
            "0.85",
            "0.90",
            "0.95",
            "0.99"});
            this.similarityComboBox.Location = new System.Drawing.Point(141, 81);
            this.similarityComboBox.Name = "similarityComboBox";
            this.similarityComboBox.Size = new System.Drawing.Size(44, 24);
            this.similarityComboBox.TabIndex = 21;
            // 
            // fromLabel
            // 
            this.fromLabel.AutoSize = true;
            this.fromLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.fromLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fromLabel.Location = new System.Drawing.Point(14, 29);
            this.fromLabel.Name = "fromLabel";
            this.fromLabel.Size = new System.Drawing.Size(39, 16);
            this.fromLabel.TabIndex = 23;
            this.fromLabel.Text = "From";
            // 
            // fromTextBox
            // 
            this.fromTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fromTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fromTextBox.Location = new System.Drawing.Point(54, 25);
            this.fromTextBox.Name = "fromTextBox";
            this.fromTextBox.Size = new System.Drawing.Size(40, 22);
            this.fromTextBox.TabIndex = 24;
            this.fromTextBox.Text = "1";
            // 
            // toLabel
            // 
            this.toLabel.AutoSize = true;
            this.toLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.toLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toLabel.Location = new System.Drawing.Point(100, 27);
            this.toLabel.Name = "toLabel";
            this.toLabel.Size = new System.Drawing.Size(19, 16);
            this.toLabel.TabIndex = 25;
            this.toLabel.Text = "to";
            // 
            // toTextBox
            // 
            this.toTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.toTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toTextBox.Location = new System.Drawing.Point(126, 25);
            this.toTextBox.Name = "toTextBox";
            this.toTextBox.Size = new System.Drawing.Size(40, 22);
            this.toTextBox.TabIndex = 26;
            this.toTextBox.Text = "9999";
            // 
            // top10Label
            // 
            this.top10Label.AutoSize = true;
            this.top10Label.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.top10Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.top10Label.Location = new System.Drawing.Point(16, 223);
            this.top10Label.Name = "top10Label";
            this.top10Label.Size = new System.Drawing.Size(82, 16);
            this.top10Label.TabIndex = 27;
            this.top10Label.Text = "Display Top";
            // 
            // top10TextBox
            // 
            this.top10TextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.top10TextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.top10TextBox.Location = new System.Drawing.Point(103, 221);
            this.top10TextBox.Name = "top10TextBox";
            this.top10TextBox.Size = new System.Drawing.Size(32, 22);
            this.top10TextBox.TabIndex = 28;
            this.top10TextBox.Text = "10";
            // 
            // rawDataFolderBrowserDialog
            // 
            this.rawDataFolderBrowserDialog.SelectedPath = "C:\\Documents and Settings\\Lenny\\My Documents\\Visual Studio 2005\\Projects\\Thesis\\B" +
                "MPExperimentData";
            // 
            // parameterGroupBox
            // 
            this.parameterGroupBox.Controls.Add(this.shortExcelCheckBox);
            this.parameterGroupBox.Controls.Add(this.moveYComboBox);
            this.parameterGroupBox.Controls.Add(this.moveLabel);
            this.parameterGroupBox.Controls.Add(this.moveXComboBox);
            this.parameterGroupBox.Controls.Add(this.includeFirstFixationCheckBox);
            this.parameterGroupBox.Controls.Add(this.top10TextBox);
            this.parameterGroupBox.Controls.Add(this.top10Label);
            this.parameterGroupBox.Controls.Add(this.toTextBox);
            this.parameterGroupBox.Controls.Add(this.toLabel);
            this.parameterGroupBox.Controls.Add(this.fromTextBox);
            this.parameterGroupBox.Controls.Add(this.fromLabel);
            this.parameterGroupBox.Controls.Add(this.similarityComboBox);
            this.parameterGroupBox.Controls.Add(this.similarityLabel);
            this.parameterGroupBox.Controls.Add(this.includePatternFixationCheckBox);
            this.parameterGroupBox.Controls.Add(this.radiusLabel);
            this.parameterGroupBox.Controls.Add(this.radiusComboBox);
            this.parameterGroupBox.Location = new System.Drawing.Point(11, 157);
            this.parameterGroupBox.Name = "parameterGroupBox";
            this.parameterGroupBox.Size = new System.Drawing.Size(209, 288);
            this.parameterGroupBox.TabIndex = 29;
            this.parameterGroupBox.TabStop = false;
            this.parameterGroupBox.Text = "Experiment Parameter";
            // 
            // moveYComboBox
            // 
            this.moveYComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.moveYComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.moveYComboBox.FormattingEnabled = true;
            this.moveYComboBox.Items.AddRange(new object[] {
            "Top",
            "Center",
            "Bottom"});
            this.moveYComboBox.Location = new System.Drawing.Point(110, 190);
            this.moveYComboBox.Name = "moveYComboBox";
            this.moveYComboBox.Size = new System.Drawing.Size(87, 24);
            this.moveYComboBox.TabIndex = 32;
            // 
            // moveLabel
            // 
            this.moveLabel.AutoSize = true;
            this.moveLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.moveLabel.Location = new System.Drawing.Point(13, 171);
            this.moveLabel.Name = "moveLabel";
            this.moveLabel.Size = new System.Drawing.Size(134, 16);
            this.moveLabel.TabIndex = 31;
            this.moveLabel.Text = "Move Fixation center:";
            // 
            // moveXComboBox
            // 
            this.moveXComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.moveXComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.moveXComboBox.FormattingEnabled = true;
            this.moveXComboBox.Items.AddRange(new object[] {
            "Left",
            "Center",
            "Right"});
            this.moveXComboBox.Location = new System.Drawing.Point(16, 190);
            this.moveXComboBox.Name = "moveXComboBox";
            this.moveXComboBox.Size = new System.Drawing.Size(88, 24);
            this.moveXComboBox.TabIndex = 30;
            // 
            // includeFirstFixationCheckBox
            // 
            this.includeFirstFixationCheckBox.AutoSize = true;
            this.includeFirstFixationCheckBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.includeFirstFixationCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.includeFirstFixationCheckBox.Location = new System.Drawing.Point(18, 139);
            this.includeFirstFixationCheckBox.Name = "includeFirstFixationCheckBox";
            this.includeFirstFixationCheckBox.Size = new System.Drawing.Size(131, 20);
            this.includeFirstFixationCheckBox.TabIndex = 29;
            this.includeFirstFixationCheckBox.Text = "Include 1st fixation";
            this.includeFirstFixationCheckBox.UseVisualStyleBackColor = true;
            // 
            // ascDataGroupBox
            // 
            this.ascDataGroupBox.Controls.Add(this.averageFixationsLabel);
            this.ascDataGroupBox.Controls.Add(this.averageFixationsDescriptionLabel);
            this.ascDataGroupBox.Controls.Add(this.fixationNumbersLabel);
            this.ascDataGroupBox.Controls.Add(this.fixationNumbersDescriptionLabel);
            this.ascDataGroupBox.Controls.Add(this.trialNumbersLabel);
            this.ascDataGroupBox.Controls.Add(this.trialNumbersDescriptionLabel);
            this.ascDataGroupBox.Location = new System.Drawing.Point(368, 36);
            this.ascDataGroupBox.Name = "ascDataGroupBox";
            this.ascDataGroupBox.Size = new System.Drawing.Size(217, 103);
            this.ascDataGroupBox.TabIndex = 30;
            this.ascDataGroupBox.TabStop = false;
            this.ascDataGroupBox.Text = "Data File Info";
            // 
            // queueListView
            // 
            this.queueListView.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.queueListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnName,
            this.columnRadius,
            this.columnFrom,
            this.columnTo,
            this.moveXColumn,
            this.moveYColumn});
            this.queueListView.Location = new System.Drawing.Point(236, 211);
            this.queueListView.Name = "queueListView";
            this.queueListView.Size = new System.Drawing.Size(420, 125);
            this.queueListView.TabIndex = 31;
            this.queueListView.UseCompatibleStateImageBehavior = false;
            this.queueListView.View = System.Windows.Forms.View.Details;
            this.queueListView.SelectedIndexChanged += new System.EventHandler(this.queueListView_SelectedIndexChanged);
            // 
            // columnName
            // 
            this.columnName.Text = "Name";
            this.columnName.Width = 203;
            // 
            // columnRadius
            // 
            this.columnRadius.Text = "R";
            this.columnRadius.Width = 25;
            // 
            // columnFrom
            // 
            this.columnFrom.Text = "From";
            // 
            // columnTo
            // 
            this.columnTo.Text = "To";
            // 
            // moveXColumn
            // 
            this.moveXColumn.Text = "X";
            this.moveXColumn.Width = 25;
            // 
            // moveYColumn
            // 
            this.moveYColumn.Text = "Y";
            this.moveYColumn.Width = 25;
            // 
            // addButton
            // 
            this.addButton.Enabled = false;
            this.addButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addButton.Image = global::BMPAnalysis.Properties.Resources.add48;
            this.addButton.Location = new System.Drawing.Point(236, 157);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(48, 48);
            this.addButton.TabIndex = 32;
            this.addButton.UseVisualStyleBackColor = true;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // deleteButton
            // 
            this.deleteButton.Enabled = false;
            this.deleteButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.deleteButton.Image = global::BMPAnalysis.Properties.Resources.delete48;
            this.deleteButton.Location = new System.Drawing.Point(302, 157);
            this.deleteButton.Name = "deleteButton";
            this.deleteButton.Size = new System.Drawing.Size(48, 48);
            this.deleteButton.TabIndex = 33;
            this.deleteButton.UseVisualStyleBackColor = true;
            this.deleteButton.Click += new System.EventHandler(this.deleteButton_Click);
            // 
            // generateExcelButton
            // 
            this.generateExcelButton.Enabled = false;
            this.generateExcelButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.generateExcelButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.generateExcelButton.Image = global::BMPAnalysis.Properties.Resources.about48;
            this.generateExcelButton.Location = new System.Drawing.Point(386, 359);
            this.generateExcelButton.Name = "generateExcelButton";
            this.generateExcelButton.Size = new System.Drawing.Size(88, 86);
            this.generateExcelButton.TabIndex = 14;
            this.generateExcelButton.Text = "Generate Excel Chart";
            this.generateExcelButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.generateExcelButton.UseVisualStyleBackColor = true;
            this.generateExcelButton.Click += new System.EventHandler(this.generateExcelButton_Click);
            // 
            // rawDataButton
            // 
            this.rawDataButton.Enabled = false;
            this.rawDataButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rawDataButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rawDataButton.Image = global::BMPAnalysis.Properties.Resources.clipboard;
            this.rawDataButton.Location = new System.Drawing.Point(254, 359);
            this.rawDataButton.Name = "rawDataButton";
            this.rawDataButton.Size = new System.Drawing.Size(96, 86);
            this.rawDataButton.TabIndex = 6;
            this.rawDataButton.Text = "Generate RawData";
            this.rawDataButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.rawDataButton.UseVisualStyleBackColor = true;
            this.rawDataButton.Click += new System.EventHandler(this.rawDataButton_Click);
            // 
            // dataFileButton
            // 
            this.dataFileButton.Enabled = false;
            this.dataFileButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dataFileButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataFileButton.Image = global::BMPAnalysis.Properties.Resources.open32;
            this.dataFileButton.Location = new System.Drawing.Point(12, 93);
            this.dataFileButton.Name = "dataFileButton";
            this.dataFileButton.Size = new System.Drawing.Size(32, 32);
            this.dataFileButton.TabIndex = 5;
            this.dataFileButton.UseVisualStyleBackColor = true;
            this.dataFileButton.Click += new System.EventHandler(this.dataFileButton_Click);
            // 
            // experimentFolderButton
            // 
            this.experimentFolderButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.experimentFolderButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.experimentFolderButton.Image = global::BMPAnalysis.Properties.Resources.find32;
            this.experimentFolderButton.Location = new System.Drawing.Point(12, 39);
            this.experimentFolderButton.Name = "experimentFolderButton";
            this.experimentFolderButton.Size = new System.Drawing.Size(32, 32);
            this.experimentFolderButton.TabIndex = 2;
            this.experimentFolderButton.UseVisualStyleBackColor = true;
            this.experimentFolderButton.Click += new System.EventHandler(this.experimentFolderButton_Click);
            // 
            // shortExcelCheckBox
            // 
            this.shortExcelCheckBox.AutoSize = true;
            this.shortExcelCheckBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.shortExcelCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.shortExcelCheckBox.Location = new System.Drawing.Point(19, 262);
            this.shortExcelCheckBox.Name = "shortExcelCheckBox";
            this.shortExcelCheckBox.Size = new System.Drawing.Size(135, 20);
            this.shortExcelCheckBox.TabIndex = 33;
            this.shortExcelCheckBox.Text = "Short excel reports";
            this.shortExcelCheckBox.UseVisualStyleBackColor = true;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(679, 502);
            this.Controls.Add(this.deleteButton);
            this.Controls.Add(this.addButton);
            this.Controls.Add(this.queueListView);
            this.Controls.Add(this.ascDataGroupBox);
            this.Controls.Add(this.parameterGroupBox);
            this.Controls.Add(this.outputLabel);
            this.Controls.Add(this.outputProgressBar);
            this.Controls.Add(this.generateExcelButton);
            this.Controls.Add(this.rawDataButton);
            this.Controls.Add(this.dataFileButton);
            this.Controls.Add(this.dataFileLabel);
            this.Controls.Add(this.chooseFileLabel);
            this.Controls.Add(this.experimentFolderButton);
            this.Controls.Add(this.experimentFolderLabel);
            this.Controls.Add(this.chooseExperimentFolderLabel);
            this.Controls.Add(this.menuStrip);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip;
            this.Name = "MainForm";
            this.Text = "Experiment Analysis";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.parameterGroupBox.ResumeLayout(false);
            this.parameterGroupBox.PerformLayout();
            this.ascDataGroupBox.ResumeLayout(false);
            this.ascDataGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FolderBrowserDialog experimentFolderBrowserDialog;
        private System.Windows.Forms.Label chooseExperimentFolderLabel;
        private System.Windows.Forms.Label experimentFolderLabel;
        private System.Windows.Forms.Button experimentFolderButton;
        private System.Windows.Forms.Label chooseFileLabel;
        private System.Windows.Forms.Label dataFileLabel;
        private System.Windows.Forms.OpenFileDialog openDataFileDialog;
        private System.Windows.Forms.Button dataFileButton;
        private System.Windows.Forms.Button rawDataButton;
        private System.Windows.Forms.Label trialNumbersDescriptionLabel;
        private System.Windows.Forms.Label trialNumbersLabel;
        private System.Windows.Forms.Label fixationNumbersDescriptionLabel;
        private System.Windows.Forms.Label fixationNumbersLabel;
        private System.Windows.Forms.Label averageFixationsDescriptionLabel;
        private System.Windows.Forms.Label averageFixationsLabel;
        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem infoToolStripMenuItem;
        private System.Windows.Forms.Button generateExcelButton;
        private System.ComponentModel.BackgroundWorker generateBackgroundWorker;
        private System.Windows.Forms.ProgressBar outputProgressBar;
        private System.Windows.Forms.Label outputLabel;
        private System.Windows.Forms.ComboBox radiusComboBox;
        private System.Windows.Forms.Label radiusLabel;
        private System.Windows.Forms.CheckBox includePatternFixationCheckBox;
        private System.Windows.Forms.Label similarityLabel;
        private System.Windows.Forms.ComboBox similarityComboBox;
        private System.Windows.Forms.Label fromLabel;
        private System.Windows.Forms.TextBox fromTextBox;
        private System.Windows.Forms.Label toLabel;
        private System.Windows.Forms.TextBox toTextBox;
        private System.Windows.Forms.Label top10Label;
        private System.Windows.Forms.TextBox top10TextBox;
        private System.Windows.Forms.FolderBrowserDialog rawDataFolderBrowserDialog;
        private System.Windows.Forms.GroupBox parameterGroupBox;
        private System.Windows.Forms.GroupBox ascDataGroupBox;
        private System.Windows.Forms.CheckBox includeFirstFixationCheckBox;
        private System.Windows.Forms.Label moveLabel;
        private System.Windows.Forms.ComboBox moveXComboBox;
        private System.Windows.Forms.ComboBox moveYComboBox;
        private System.Windows.Forms.ListView queueListView;
        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.Button deleteButton;
        private System.Windows.Forms.ColumnHeader columnName;
        private System.Windows.Forms.ColumnHeader columnRadius;
        private System.Windows.Forms.ColumnHeader columnFrom;
        private System.Windows.Forms.ColumnHeader columnTo;
        private System.Windows.Forms.ColumnHeader moveXColumn;
        private System.Windows.Forms.ColumnHeader moveYColumn;
        private System.Windows.Forms.CheckBox shortExcelCheckBox;
    }
}

