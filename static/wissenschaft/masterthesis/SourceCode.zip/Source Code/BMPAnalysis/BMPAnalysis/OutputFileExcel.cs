using System;
using System.Collections.Generic;
using System.Text;
using Excel = Microsoft.Office.Interop.Excel;
using Interop = System.Runtime.InteropServices;
using BMPBuilder;
using ASCLibrary;
using System.Drawing;



namespace BMPAnalysis
{
    /// <summary>
    /// Creates and displays excel sheets with the data output.
    /// </summary>
    public class OutputFileExcel : OutputFile
    {
        /* Excel Variables */
        private Excel.Application excel = null;
        private Excel.Workbook wb = null;
        private Excel.Worksheet ws = null;
        private Excel.Range rng = null;
        private object missing = Type.Missing;
        
        /* Actual Position in Excel Table */
        private int excelRow = 1;

        private int excelColumn = 0;

        /* Constants */
        private const int COLUMN_INDENT = 1;

        private static string[] Letters = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", 
            "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "AA", "AB", "AC", "AD", "AE", "AF", "AG", "AH", "AI",
            "AJ", "AK", "AL", "AM", "AN", "AO", "AP", "AQ", "AR", "AS", "AT", "AU", "AV", "AW", "AX", "AY", "AZ", 
            "BA", "BB", "BC", "BD", "BE", "BF", "BG", "BH", "BI", "BJ", "BK", "BL", "BM", "BN", "BO", "BP", "BQ", "BR", "BS",
            "BT", "BU", "BV", "BW", "BX","BY","BZ" };


        /// <summary>
        /// Initializes a new instance of the <see cref="OutputFileExcel"/> class.
        /// </summary>
        /// <param name="parameterList">The parameter list.</param>
        /// <param name="experiment">The experiment data.</param>
        /// <param name="pictureList">The picture list.</param>
        /// <param name="patternList">The pattern list.</param>
        /// <param name="config">The config data.</param>
        /// <param name="ascData">The ASC data.</param>
        /// <param name="dataFile">The data file.</param>
        /// <param name="experimentFolder">The experiment folder.</param>
        public OutputFileExcel(OutputFileParameter parameterList, ExperimentData experiment, List<Picture> pictureList,
            List<Pattern> patternList, Config config, ASCData ascData, string dataFile, string experimentFolder)
            : base(parameterList, experiment, pictureList,
            patternList, config, ascData, dataFile, experimentFolder)
        {
            ;
        }

        /// <summary>
        /// Inits the output.
        /// </summary>
        protected override void initOutput()
        {
            ;
        }
        /// <summary>
        /// Called when a new block of trials begins.
        /// </summary>
        protected override void newBlockOutput()  
        {

            excel = new Excel.Application();
            wb = excel.Workbooks.Add(Type.Missing);
            ws = (Excel.Worksheet)wb.ActiveSheet;
            excelColumn = 0;
            excelRow = 1;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn] + excelRow.ToString(), missing);
            rng.Value2 = "Experiment Metadata";
            rng.Font.Bold = true;
            rng.Font.Size = 14;
            excelRow++; excelColumn++;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn] + excelRow.ToString(), missing);
            rng.Value2 = "Filename:" + DataFile;
            excelRow++;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn] + excelRow.ToString(), missing);
            rng.Value2 = "Folder:" + ExperimentFolder;
            excelRow++;
            excelRow++;
            if (!Parameter.ShortExcelReport)
            {
                rng = ws.get_Range(OutputFileExcel.Letters[excelColumn] + excelRow.ToString(), missing);
                rng.Value2 = Parameter.ToString(); rng.Font.Bold = true;
                excelRow++;
                excelRow++;
            }


        }

        /// <summary>
        /// Called when the trial output starts.
        /// </summary>
        protected override void startTrialOutput()
        {
            if (Parameter.ShortExcelReport) return;

            excelColumn = 0;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn] + excelRow.ToString(), missing);
            rng.Value2 = "Trial No.:"; rng.Font.Bold = true;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn+3] + excelRow.ToString(), missing);
            rng.Value2 = AscData.TrialDataList[trialID].TrialMetaData.TrialID.ToString();
            excelRow++;  

            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn] + excelRow.ToString(), missing);
            rng.Value2 = "Name:"; rng.Font.Bold = true;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn+3] + excelRow.ToString(), missing);
            rng.Value2 = AscData.TrialDataList[trialID].TrialMetaData.TrialName.ToString();
            excelRow++; 

            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn] + excelRow.ToString(), missing);
            rng.Value2 = "Block No.:"; rng.Font.Bold = true;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn + 3] + excelRow.ToString(), missing);
            int blockOutput = block + 1;
            rng.Value2 = blockOutput.ToString();
            excelRow++; 

            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn] + excelRow.ToString(), missing);
            rng.Value2 = "Timeout:"; rng.Font.Bold = true;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn+3] + excelRow.ToString(), missing);
            rng.Value2 = AscData.TrialDataList[trialID].TrialMetaData.Timeout;
            excelRow++;

            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn] + excelRow.ToString(), missing);
            rng.Value2 = "Duration of Trial:"; rng.Font.Bold = true;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn+3] + excelRow.ToString(), missing);
            rng.Value2 = AscData.TrialDataList[trialID].TrialMetaData.EndTime - AscData.TrialDataList[trialID].TrialMetaData.StartTime;
            excelRow++;

            excelRow++;

            excelColumn = 0 + COLUMN_INDENT;
            /* Headline Type */
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = "Type"; rng.Font.Underline = true;
            /* Headlines PosX and PosY */
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = "PosX"; rng.Font.Underline = true;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = "PosY"; rng.Font.Underline = true;
            /* Headlines Squares X and Squares Y */
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = "Sq.Y"; rng.Font.Underline = true;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = "Sq.X"; rng.Font.Underline = true;
            /* Headlines ViewX and ViewY */
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = "ViewX"; rng.Font.Underline = true;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = "ViewY"; rng.Font.Underline = true;
            /* Headline Duration */
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = "Dur."; rng.Font.Underline = true;
            /* Headline Pupil Size */
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = "Pup.Size"; rng.Font.Underline = true;
            /* Seperator */
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = "-"; rng.ColumnWidth = 4;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = "Distr."; rng.Font.Underline = true; rng.ColumnWidth = 20;
            /* Headline AverageVector */
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = "Avg.Vector."; rng.Font.Underline = true; rng.ColumnWidth = 20;
            /* Headline Vector Comparisation*/
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = "Vector Comp."; rng.Font.Underline = true;
            excelColumn++;
            /* Headline Pattern grid */
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = "X/Y"; rng.Font.Underline = true;
            rng.HorizontalAlignment = Excel.XlHAlign.xlHAlignRight;

        }

        /// <summary>
        /// Called at the begin of a trial, when the pattern data is calculated.
        /// </summary>
        protected override void patternDataOutput()
        {
            if (Parameter.ShortExcelReport) return;

            /* Display grid numbers for pattern */
            for (int k = 0; k < PatternList[trialID].SquaresX; k++)
            {
                int X = k + PictureList[trialID].PatternPositionX;
                rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
                rng.Value2 = X.ToString();
            }
            for (int letterPos = excelColumn - PatternList[trialID].SquaresY - 1, row = excelRow + 1, l = 0; l < PatternList[trialID].SquaresY; l++, row++)
            {
                int Y = l + PictureList[trialID].PatternPositionY;
                rng = ws.get_Range(OutputFileExcel.Letters[letterPos] + row.ToString(), missing);
                rng.Value2 = Y.ToString();
            }

            excelColumn = 0 + COLUMN_INDENT;
            excelRow++;

            /* Display Pattern Data */
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = "Pattern"; rng.Font.Italic = true;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = PictureList[trialID].PatternPositionX+1;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = PictureList[trialID].PatternPositionY + 1;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = PatternList[trialID].SquaresX;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = PatternList[trialID].SquaresY;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = PictureList[trialID].PatternPositionX.ToString();
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = PictureList[trialID].PatternPositionY.ToString();
            excelColumn++; //Skip Duration
            excelColumn++; //Skip Pupil Size

            excelColumn++; //Skip seperator

            /* Display Color Distributin */
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = PatternVector.ColorDistributionString(2);

            /* Display Pattern Vector */
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = PatternVector.ToString();

            /* Display the pattern */
            excelRow = displayPattern(excelColumn + 3, excelRow);
            
            /* Correct the column size of the pattern display (and as well for the display of the fixations) */
            for (int pos = excelColumn+3; pos < excelColumn+10; pos++)
            {
                rng = ws.get_Range(OutputFileExcel.Letters[pos] + excelRow.ToString(), missing);
                rng.ColumnWidth = 2;
            }
            excelRow++;
        }



        /// <summary>
        /// Called when new fixation data has been calculated.
        /// </summary>
        /// <param name="posX">The vertical Position of the fixation.</param>
        /// <param name="posY">The horizontal Position of the fixation.</param>
        /// <param name="patternFixation">If set to <c>true</c> this function is also called if the fixation included the target pattern..</param>
        /// <param name="fix">The fixation data.</param>
        /// <param name="fixRect">The fixation rectangle.</param>
        /// <param name="fixationVectorList">The fixation vector list.</param>
        /// <param name="firstFixation">if set to <c>true</c> the fixation was the first fixation of the trial.</param>
        protected override void fixationOutput(int posX, int posY, bool patternFixation, ASCFixation fix, Rectangle fixRect, List<Vector> fixationVectorList, bool firstFixation)
        {
            if (Parameter.ShortExcelReport) return;

            excelColumn = 0+COLUMN_INDENT;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = "FIX";
            if (patternFixation)
                rng.Value2 += "(P)";
            if (firstFixation)
                rng.Value2 += "(1st)";
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = posX.ToString();
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = posY.ToString();
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = fixRect.Width.ToString();
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = fixRect.Height.ToString();
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = fixRect.X.ToString(); 
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = fixRect.Y.ToString();

            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = fix.Duration.ToString();
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = fix.AveragePupilSize.ToString();


            excelColumn++; //Skip seperator

            /* Display Average Vector details */
            try
            {
                Vector averageVector = Vector.AverageVector(fixationVectorList, PictureList[trialID].Colors, PatternList[trialID].ColorDistribution(2), false);

                /* Display Color Distribution */
                rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
                rng.Value2 = averageVector.ColorDistributionString(2); 

                /* Display average Vector */
                rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
                rng.Value2 = averageVector.ToString();
            }
            catch (NullReferenceException ne) { ; }


            /* Display comparison Values */
            int column2 = excelColumn;
            int row2 = excelRow;
            foreach (Vector fixVector in fixationVectorList)
            {
                double similarity = fixVector.Compare(PatternVector);
                rng = ws.get_Range(OutputFileExcel.Letters[column2++] + row2.ToString(), missing);
                rng.Value2 = similarity.ToString();
                if (column2 % (fixRect.Width + 1 - PatternList[trialID].SquaresX) == excelColumn % (fixRect.Width + 1 - PatternList[trialID].SquaresX))
                {
                    column2 = excelColumn;
                    row2++;
                }
            }
            excelColumn += PatternList[trialID].SquaresX;
            excelColumn++;

            /* Display the Fixation Area itself */
            for (int k = fixRect.Y, row = excelRow; k < fixRect.Y+fixRect.Height; k++, row++)
            {
                for (int column = excelColumn, l = fixRect.X; l < fixRect.X+fixRect.Width; l++, column++)
                {
                    //Attention: l und k are swapped
                    rng = ws.get_Range(OutputFileExcel.Letters[column] + row.ToString(), missing);
                    rng.Font.Color = PictureList[trialID].Structure[l, k];
                    rng.Font.Bold = true;
                    rng.Interior.Color = PictureList[trialID].Structure[l, k];

                    rng.Value2 = Constants.ColorIntToString(PictureList[trialID].Structure[l, k], true);
                    //if (rng.ColumnWidth != 2) rng.ColumnWidth = 2;
                }
            }

            excelRow = excelRow + fixRect.Height + 1;
        }

        /// <summary>
        /// Called when new fixation data has been calculated and the fixation was outside the picture or included the target pattern.
        /// </summary>
        /// <param name="posX">The vertical position of the fixation (-1 if the fixation was outside).</param>
        /// <param name="posY">The horizontal position of the fixation (-1 if the fixation was outside).</param>
        /// <param name="patternFixation">if set to <c>true</c> the fixation included the target pattern..</param>
        protected override void fixationOutsideOutput(int posX, int posY, bool patternFixation)
        {
            if (Parameter.ShortExcelReport) return;

            excelColumn = COLUMN_INDENT;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            if (!patternFixation)
                rng.Value2 = "OUTSIDE";
            else
                rng.Value2 = "PFIX";
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = posX;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = posY;
            excelRow += 2;
        }

        /// <summary>
        /// Called when the end of a trial has been passed.
        /// </summary>
        protected override void endTrialOutput()
        {
            if (Parameter.ShortExcelReport) return;
            excelRow += 3;
        }


        /// <summary>
        /// Called when the last item of a trial block has been passed
        /// </summary>
        /// <param name="ranking">The ranking list of fixations the current trial block, , ranked by frequency.</param>
        /// <param name="averageRanking">The ranking list of possbile Patterns with high similarity to the fixations, ranked by frequency.</param>
        /// <param name="rankingWithWeight">The ranking list of fixations the current trial block, , ranked by total duration.</param>
        /// <param name="averageRankingWithWeight">The ranking list of possbile Patterns with high similarity to the fixations, ranked by total duration.</param>
        /// <param name="averageVector">The overall average vector of all fixation.</param>
        /// <param name="averageVectorWW">The overall average vector, considering the duration. of the fixations.</param>
        /// <param name="overallColorDist">The overall color dist.</param>
        /// <param name="overallColorDist_M">The overall color dist_ M.</param>
        /// <param name="cornerFixationRanking">The fixation ranking of the sub-fixations.</param>
        /// <param name="cornerFixationRankingWithWeight">The fixation ranking of the sub-fixations with weight.</param>
        /// <param name="cornerSimilarityRanking">The ranking of the sub-patterns with a high similarity to the target-pattern.</param>
        /// <param name="cornerSimilarityRankingWithWeight">The ranking of the sub-patterns with a high similarity to the target-pattern, ranked by weight</param>
        /// <param name="combinedCornerFixationRanking">The ranking of the sub-fixations with all combined to one pattern</param>
        /// <param name="combinedCornerFixationRankingWW">The ranking of the sub-fixations with all combined to one pattern, considering weight</param>
        /// <param name="combinedCornerSimilarityRanking">The ranking of the sub-patterns with a high similarity to the target pattern, all combined to one pattern</param>
        /// <param name="combinedCornerSimilarityRankingWW">The ranking of the sub-patterns with a high similarity to the target pattern, all combined to one pattern, considering weight</param>
        /// <param name="allCornerFixationRanking">A ranking of all sub-fixations, not divided by corners.</param>
        /// <param name="allCornerFixationRankingWW">A ranking of all sub-fixations, not divided by corners, cosidering weight.</param>
        /// <param name="allCornerSimilarityRanking">A ranking of all sub-fixations with a high similarity to the target pattern, not divided by corners.</param>
        /// <param name="allCornerSimilarityRankingWW">A ranking of all sub-fixations with a high similarity to the target pattern, not divided by corners, considering weight.</param>
        /// <param name="percentageRanking">A ranking where a score for each pattern was calculated.</param>
        protected override void lastItemOfBlockOutput(List<Vector> ranking, List<Vector> averageRanking, 
            List<Vector> rankingWithWeight, List<Vector> averageRankingWithWeight, 
            Vector averageVector, Vector averageVectorWW, 
            List<ColorDistribution>[] overallColorDist, double[] overallColorDist_M, 
            List<Vector>[] cornerFixationRanking, List<Vector>[] cornerFixationRankingWithWeight,
            List<Vector>[] cornerSimilarityRanking, List<Vector>[] cornerSimilarityRankingWithWeight,
            List<Vector> combinedCornerFixationRanking, List<Vector> combinedCornerFixationRankingWW,
            List<Vector> combinedCornerSimilarityRanking, List<Vector> combinedCornerSimilarityRankingWW,
            List<Vector> allCornerFixationRanking, List<Vector> allCornerFixationRankingWW,
            List<Vector> allCornerSimilarityRanking, List<Vector> allCornerSimilarityRankingWW,
            List<Vector> percentageRanking)
        {
            /* If no fixation List has been displayed before, the column width of the pattern graphics
             * has to be adjusted */
            if (Parameter.ShortExcelReport)
            {
                for (int pos = 17; pos < 25; pos++)
                {
                    rng = ws.get_Range(OutputFileExcel.Letters[pos] + excelRow.ToString(), missing);
                    rng.ColumnWidth = 2;
                }
            }

            excelColumn = 1;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn] + excelRow.ToString(), missing);
            rng.Value2 = "Block:"+(block+1); rng.Font.Bold = true; excelRow++;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn] + excelRow.ToString(), missing);
            rng.Value2 = Parameter.ToString(); rng.Font.Bold = true; excelRow += 2;

            /* Color distributions */
            displayColorDistribution_M(overallColorDist_M);
            displayColorDistribution(overallColorDist);

            /* Ranking by frequency */
            displayAverageVector(averageVector, "Average vector of all Fixations:");

            displayRanking(averageRanking, "Top " + Parameter.Top10 + " of fixations, ranked by frequency", overallColorDist_M);
            displayRanking(ranking, "Top " + Parameter.Top10 + " patterns with high similarity to target pattern, ranked by frequency", overallColorDist_M);
            displayPatternRank(ranking, " Rank of target pattern: ");

            displayRanking(percentageRanking, "Top" + Parameter.Top10 + " of patterns with heigh similarity to target pattern, ranked by score", overallColorDist_M);
            displayPatternRank(percentageRanking, " Rank of target pattern: ");

            displayRanking(allCornerFixationRanking, "Top " + Parameter.Top10 + " of sub-fixations not divided into their corner positions", overallColorDist_M);
            displayRanking(allCornerSimilarityRanking, "Top " + Parameter.Top10 + " of sub-patterns with high similarity to target pattern, not divided into their corner positions", overallColorDist_M);

            displayRanking(cornerFixationRanking[0], "Top " + Parameter.Top10 + " of sub-fixations, upper left corner", overallColorDist_M);
            displayRanking(cornerFixationRanking[1], "Top " + Parameter.Top10 + " of sub-fixations, upper right corner", overallColorDist_M);
            displayRanking(cornerFixationRanking[2], "Top " + Parameter.Top10 + " of sub-fixations, bottom left corner", overallColorDist_M);
            displayRanking(cornerFixationRanking[3], "Top " + Parameter.Top10 + " of sub-fixations, bottom right corner", overallColorDist_M);

            displayRanking(cornerSimilarityRanking[0], "Top " + Parameter.Top10 + " of sub-patterns with high similarity to target pattern, upper left corner", overallColorDist_M);
            displayRanking(cornerSimilarityRanking[1], "Top " + Parameter.Top10 +  " of sub-patterns with high similarity to target pattern, upper right corner", overallColorDist_M);
            displayRanking(cornerSimilarityRanking[2], "Top " + Parameter.Top10 + "  of sub-patterns with high similarity to target pattern, bottom left corner", overallColorDist_M);
            displayRanking(cornerSimilarityRanking[3], "Top " + Parameter.Top10 + "  of sub-patterns with high similarity to target pattern, bottom right corner", overallColorDist_M);

            displayRanking(combinedCornerFixationRanking, "Top " + Parameter.Top10 + " of combined sub-fixations", overallColorDist_M);
            displayPatternRank(combinedCornerFixationRanking, " Rank of target pattern: ");
            displayRanking(combinedCornerSimilarityRanking, "Top " + Parameter.Top10 + " of combined sub-patterns with high similarity to target pattern", overallColorDist_M);
            displayPatternRank(combinedCornerSimilarityRanking, " Rank of target pattern: ");

            /* Ranking by Weight */
            displayAverageVector(averageVectorWW, "Average vector of all Fixations, by duration:");
 
            displayRanking(averageRankingWithWeight, "Top " + Parameter.Top10 + " of fixations, ranked by duration", overallColorDist_M);
            displayRanking(rankingWithWeight, "Top " + Parameter.Top10 + " patterns with high similarity to target pattern, ranked by duration", overallColorDist_M);
            displayPatternRank(rankingWithWeight, " Rank of target pattern: ");

            displayRanking(allCornerFixationRankingWW, "Top " + Parameter.Top10 + " of sub-fixations not divided into their corner positions, ranked by duration", overallColorDist_M);
            displayRanking(allCornerSimilarityRankingWW, "Top " + Parameter.Top10 + " of sub-patterns with high similarity to target pattern, not divided into their corner positions, ranked by duration", overallColorDist_M);

            displayRanking(cornerFixationRankingWithWeight[0], "Top " + Parameter.Top10 + " of sub-fixations, upper left corner, ranked by duration", overallColorDist_M);
            displayRanking(cornerFixationRankingWithWeight[1], "Top " + Parameter.Top10 + " of sub-fixations, upper right corner, ranked by duration", overallColorDist_M);
            displayRanking(cornerFixationRankingWithWeight[2], "Top " + Parameter.Top10 + " of sub-fixations, bottom left corner, ranked by duration", overallColorDist_M);
            displayRanking(cornerFixationRankingWithWeight[3], "Top " + Parameter.Top10 + " of sub-fixations, bottom right corner, ranked by duration", overallColorDist_M);

            displayRanking(cornerSimilarityRankingWithWeight[0], "Top " + Parameter.Top10 + "  of sub-patterns with high similarity to target pattern, upper left corner, ranked by duration", overallColorDist_M);
            displayRanking(cornerSimilarityRankingWithWeight[1], "Top " + Parameter.Top10 + "  of sub-patterns with high similarity to target pattern, upper right corner, ranked by duration", overallColorDist_M);
            displayRanking(cornerSimilarityRankingWithWeight[2], "Top " + Parameter.Top10 + "  of sub-patterns with high similarity to target pattern, bottom left corner, ranked by duration", overallColorDist_M);
            displayRanking(cornerSimilarityRankingWithWeight[3], "Top " + Parameter.Top10 + " of sub-patterns with high similarity to target pattern, bottom right corner, ranked by duration", overallColorDist_M);

            displayRanking(combinedCornerFixationRankingWW, "Top " + Parameter.Top10 + " of combined sub-fixations ranked by duration", overallColorDist_M);
            displayPatternRank(combinedCornerFixationRankingWW, " Rank of target pattern: ");
            displayRanking(combinedCornerSimilarityRankingWW, "Top " + Parameter.Top10 + " of combined sub-patterns with high similarity to target pattern, ranked by duration", overallColorDist_M);
            displayPatternRank(combinedCornerSimilarityRankingWW, " Rank of target pattern: ");

            try
            {
                excel.Visible = true;
                wb.Activate();
                Interop.Marshal.ReleaseComObject(excel);
                excel = null;
            }
            catch (Exception e) { ; }
        }


        /// <summary>
        /// Called at the end of all trials, now the calculated data can be displayed (if not already done).
        /// </summary>
        protected override void displayOutput()
        {
            ;
        }

        /// <summary>
        /// Always called at then end of all trials, even if exceptions/errors occured. Should be used to free all used resources.
        /// </summary>
        protected override void finishOutput()
        {
            try
            {
                if (excel != null) Interop.Marshal.ReleaseComObject(excel);
                excel = null;
            }
            catch (Exception e) { ; }
        }

        /// <summary>
        /// Displays the mathetical mean of the color distribution.
        /// </summary>
        /// <param name="colDist">The mathetical mean of the color distribution in an array.</param>
        private void displayColorDistribution_M(double[] colDist)
        {
            excelColumn = 1;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn] + excelRow.ToString(), missing);
            rng.Value2 = "Overall Color Distribution (mathematical)"; rng.Font.Bold = true;
            excelColumn = 6;
            for (int i = 0; i < colDist.Length; i++)
            {
                rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
                rng.Value2 = Constants.ColorIntToString(PatternVector.ColorList[i], true) + " " + (Math.Round(colDist[i], 2) * 100) + "%";
            }
            excelRow += 2;
        }

        /// <summary>
        /// Displays the color distribution ordered in bins.
        /// </summary>
        /// <param name="overallColorDist">The overall color dist by bins as a list.</param>
        private void displayColorDistribution(List<ColorDistribution>[] overallColorDist)
        {
            excelColumn = 1;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn] + excelRow.ToString(), missing);
            rng.Value2 = "Overall Color Distribution by Bins"; rng.Font.Bold = true;
            excelRow ++;
            for (int colNr = 0; colNr < overallColorDist.Length; colNr++)
            {
                excelColumn = 3;
                rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
                rng.Value2 = "Color " + Constants.ColorIntToString(PatternVector.ColorList[colNr], true); rng.Font.Underline = true;
                excelRow++;
                rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
                rng.Value2 = "Rank";
                rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
                rng.Value2 = "Percent ";
                rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
                rng.Value2 = "Frequency";
                excelRow++;
                int rank = 1;
                foreach (ColorDistribution colorCount in overallColorDist[colNr])
                {
                    excelColumn = 4;
                    rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
                    rng.Value2 = rank++; rng.Font.Bold = true;
                    rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
                    rng.Value2 = (colorCount.Percentage * 100) + "%";
                    rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
                    rng.Value2 = colorCount.Frequency;
                    excelRow++;
                }
            }
        }


        /// <summary>
        /// Displays the average vector.
        /// </summary>
        /// <param name="vector">The average vector.</param>
        /// <param name="caption">The caption for this average Vector.</param>
        private void displayAverageVector(Vector vector, string caption)
        {
            excelRow++; excelRow++;

            excelColumn = 7;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = caption; rng.Font.Bold = true;
            excelColumn = 12;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = vector.ColorDistributionString(2);
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = vector.ToString();
            excelRow = this.displayVector(vector, excelColumn + 4, excelRow, PatternList[trialID].SquaresX);
            excelRow++; excelRow++;
        }

        /// <summary>
        /// Displays the pattern rank.
        /// </summary>
        /// <param name="ranking">The ranking list.</param>
        /// <param name="caption">The caption.</param>
        private void displayPatternRank(List<Vector> ranking, string caption)
        {
            excelColumn = 11;
            int pos = 1;
            foreach (Vector v in ranking)
            {
                if (v.Equals(PatternVector)) break;
                pos++;
            }

            string positionSt = pos.ToString();
            if (pos > ranking.Count) positionSt = "Not found.";
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = caption + positionSt; rng.Font.Bold = true;

        }

        /// <summary>
        /// Displays the ranking.
        /// </summary>
        /// <param name="ranking">The ranking list.</param>
        /// <param name="caption">The caption.</param>
        /// <param name="colorDist">The overall color distribution for average Vectors in the ranking list.</param>
        private void displayRanking(List<Vector> ranking, string caption, double[] colorDist) {
            excelRow++; excelRow++;

            excelColumn = 10;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = caption; rng.Font.Bold = true;
            excelRow++;
            excelColumn = 9;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn] + excelRow.ToString(), missing);
            rng.Value2 = "Pattern:"; excelColumn += 2;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = PatternVector.ColorDistributionString(2);
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = PatternVector.ToString();
            
            excelRow = this.displayPattern(excelColumn + 4, excelRow);
            excelRow++;
            excelColumn = 10;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = "Rank"; rng.Font.Underline = true;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = "Color Distr."; rng.Font.Underline = true;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = "Vector"; rng.Font.Underline = true;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = "Frequency"; rng.Font.Underline = true;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = "Weight"; rng.Font.Underline = true;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = "Similarity"; rng.Font.Underline = true;
            excelRow++;

            for (int rank = 0; rank < Parameter.Top10 && rank < ranking.Count; rank++)
            {
                excelColumn = 10;
                rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
                rng.Value2 = rank + 1; rng.Font.Bold = true ;
                rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
                rng.Value2 = ranking[rank].ColorDistributionString(2);
                rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
                rng.Value2 = ranking[rank].ToString();
                rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
                rng.Value2 = ranking[rank].Frequency.ToString();
                rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
                rng.Value2 = ranking[rank].Weight.ToString();
                rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
                if (PatternVector.Size==ranking[rank].Size)
                    rng.Value2 = PatternVector.Compare(ranking[rank]).ToString();
                
                int squaresX = PatternList[trialID].SquaresX;
                if (ranking[rank].Size != PatternVector.Size) //Sub-Fixations is displayed
                    squaresX -= 1;
                excelRow = displayVector(ranking[rank], excelColumn+1, excelRow, squaresX);
                excelRow++;

                if (rank>0 && ( (rank+1) == 3 || ((rank+1) % 5==0) ))
                {
                    excelRow++;
                    Vector top10Vector = Vector.AverageVector(ranking, rank+1, PictureList[trialID].Colors, colorDist,false);
                    Vector top10VectorWW = Vector.AverageVector(ranking, rank+1, PictureList[trialID].Colors, colorDist, true);

                    displayAvgVector(top10Vector, false);
                    displayAvgVector(top10VectorWW, true);
                }
            }
            excelRow++; excelRow++;
        }

        /// <summary>
        /// Displays an average vector.
        /// </summary>
        /// <param name="top10Vector">The vector.</param>
        /// <param name="usingWeight">if set to <c>true</c> the average is calculated considering the duration.</param>
        private void displayAvgVector(Vector top10Vector, bool usingWeight)
        {
            excelColumn = 7;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn] + excelRow.ToString(), missing);
            rng.Value2 = "Average Vector"; rng.Font.Bold = true;
            if (usingWeight) rng.Value2 += "using Weight";
            excelColumn = 11;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = top10Vector.ColorDistributionString(2);
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            rng.Value2 = top10Vector.ToString();
            excelColumn += 2;
            rng = ws.get_Range(OutputFileExcel.Letters[excelColumn++] + excelRow.ToString(), missing);
            if (PatternVector.Size == top10Vector.Size)
                rng.Value2 = PatternVector.Compare(top10Vector).ToString();

            int squaresX = PatternList[trialID].SquaresX;
            if (top10Vector.Size != PatternVector.Size) //Sub-Fixations is displayed
                squaresX -= 1;
            excelRow = displayVector(top10Vector, excelColumn + 1, excelRow, squaresX);

            excelRow += 2;
        }


        /// <summary>
        /// Displays the pattern.
        /// </summary>
        /// <param name="column">The actual column in the excel sheet.</param>
        /// <param name="row">The actual row in the actual sheet.</param>
        /// <returns>The new row in the excel sheet.</returns>
        private int displayPattern(int column, int row)
        {
            for (int k = 0; k < PatternList[trialID].SquaresX; k++)
            {
                for (int letterPos = column, l = 0; l < PatternList[trialID].SquaresY; l++, letterPos++)
                {
                    rng = ws.get_Range(OutputFileExcel.Letters[letterPos] + row.ToString(), missing);
                    //Attention: l und k are swapped!
                    rng.Font.Color = PatternList[trialID].Structure[l, k];
                    rng.Font.Bold = true;
                    rng.Interior.Color = PatternList[trialID].Structure[l, k];
                    rng.Value2 = Constants.ColorIntToString(PatternList[trialID].Structure[k, l], true);
                }
                row++;
            }
            return row;
        }

        /// <summary>
        /// Displays a vector.
        /// </summary>
        /// <param name="vector">The vector.</param>
        /// <param name="column">The actual column.</param>
        /// <param name="row">The actual row.</param>
        /// <param name="width">The vertical size (width) of the pattern that the vector represents.</param>
        /// <returns>The new current column</returns>
        private int displayVector(Vector vector, int column, int row, int width)
        {
            for (int letterpos = column, pos = 0; pos < vector.Size; pos++)
            {
                rng = ws.get_Range(OutputFileExcel.Letters[letterpos++] + row.ToString(), missing);

                if (pos % width == width-1) { row++; letterpos = column; }
                rng.Font.Color = vector.Colors[pos];
                rng.Font.Bold = true;
                rng.Interior.Color = vector.Colors[pos];
                rng.Value2 = Constants.ColorIntToString(vector.Colors[pos], true);
            }
            return row;
        }



    }
}
