using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using BMPBuilder;
using ASCLibrary;
using System.ComponentModel;


namespace BMPAnalysis
{
    /// <summary>
    /// Analyzes the data and makes all the necessary calculations to create the analysis output file - 
    /// to implement this class, the abstract methods should generate the equivalent output for its specified file format.
    /// </summary>
    public abstract class OutputFile
    {
        private OutputFileParameter parameter;

        /// <summary>
        /// Gets or sets the parameter.
        /// </summary>
        /// <value>The parameter.</value>
        public OutputFileParameter Parameter
        {
            get { return parameter; }
            set { parameter = value; }
        }

        private ExperimentData experiment;

        /// <summary>
        /// Gets or sets the experiment.
        /// </summary>
        /// <value>The experiment.</value>
        public ExperimentData Experiment
        {
            get { return experiment; }
            set { experiment = value; }
        }

        private List<Picture> pictureList;

        /// <summary>
        /// Gets or sets the picture list.
        /// </summary>
        /// <value>The picture list.</value>
        public List<Picture> PictureList
        {
            get { return pictureList; }
            set { pictureList = value; }
        }
 
        private List<Pattern> patternList;

        /// <summary>
        /// Gets or sets the pattern list.
        /// </summary>
        /// <value>The pattern list.</value>
        public List<Pattern> PatternList
        {
            get { return patternList; }
            set { patternList = value; }
        }

        private Config config;

        /// <summary>
        /// Gets or sets the config data.
        /// </summary>
        /// <value>The config data.</value>
        public Config Config
        {
            get { return config; }
            set { config = value; }
        }

        private ASCData ascData;

        /// <summary>
        /// Gets or sets the ASC data.
        /// </summary>
        /// <value>The ASc=C data.</value>
        public ASCData AscData
        {
            get { return ascData; }
            set { ascData = value; }
        }

        private string dataFile;

        /// <summary>
        /// Gets or sets the data file.
        /// </summary>
        /// <value>The data file.</value>
        public string DataFile
        {
            get { return dataFile; }
            set { dataFile = value; }
        }

        private string experimentFolder;

        /// <summary>
        /// Gets or sets the experiment folder.
        /// </summary>
        /// <value>The experiment folder.</value>
        public string ExperimentFolder
        {
            get { return experimentFolder; }
            set { experimentFolder = value; }
        }

        private Vector patternVector = null;

        /// <summary>
        /// Gets or sets the pattern vector.
        /// </summary>
        /// <value>The pattern vector.</value>
        public Vector PatternVector
        {
            get { return patternVector; }
            set { patternVector = value; }
        }

        /// <summary>
        /// The List of all possible Patterns, as a Vector.
        /// </summary>
        protected List<Vector> possiblePatternVectors = null;

        /// <summary>
        /// The current trial ID processing
        /// </summary>
        protected int trialID;

        /// <summary>
        /// The current trial block processing 
        /// </summary>
        protected int block;

        /// <summary>
        /// If the current trial timed out.
        /// </summary>
        protected bool timeOut;

        /// <summary>
        /// A list of all patterns that are similar to the fixations of the current block.
        /// </summary>
        protected List<Vector> blockSimilarityList = null;
        /// <summary>
        /// A list of all fixations of the current block
        /// </summary>
        protected List<Vector> blockFixationList = null;

        /// <summary>
        /// A list of all sub-fixations of the current block. 
        /// A sub-fixations divides the fixations into 4 smaller fixations, divided into its corners.
        /// </summary>
        protected List<Vector>[] cornerFixationList = null;
        
        /// <summary>
        /// A list of all sub-patterns that are similar to the fixations of the current block. A sub-fixations divides the pattern into
        /// 4 smaller patterns.
        /// </summary>
        protected List<Vector>[] cornerSimilarityList = null;

        /// <summary>
        /// A list of all sub-fixations of the current block, without dividing the list into 4 corners. 
        /// A sub-fixations divides the fixations into 4 smaller fixations.
        /// </summary>
        protected List<Vector> allCornerFixationList = null;

        /// <summary>
        /// A list of all sub-patterns that are similar to the fixations of the current block, without dividing it into its corners.
        /// A sub-fixations divides the pattern into4 smaller patterns.
        /// </summary>
        protected List<Vector> allCornerSimilarityList = null;

        /// <summary>
        /// The overall average Color distribution.
        /// </summary>
        protected List<double[]> averageColorDistributionList = null;

        /// <summary>
        /// Initializes a new instance of the <see cref="OutputFile"/> class.
        /// </summary>
        /// <param name="parameterList">The parameter list.</param>
        /// <param name="experiment">The experiment data.</param>
        /// <param name="pictureList">The picture list.</param>
        /// <param name="patternList">The pattern list.</param>
        /// <param name="config">The config data.</param>
        /// <param name="ascData">The ASC data.</param>
        /// <param name="dataFile">The data file.</param>
        /// <param name="experimentFolder">The experiment folder.</param>
        public OutputFile(OutputFileParameter parameterList, ExperimentData experiment, List<Picture> pictureList,
            List<Pattern> patternList, Config config, ASCData ascData, string dataFile, string experimentFolder)
        {
            this.Parameter = parameterList;
            this.Config = config;
            this.Experiment = experiment;
            this.PictureList = pictureList;
            this.PatternList = patternList;
            this.AscData = ascData;
            this.DataFile = dataFile;
            this.ExperimentFolder = experimentFolder;
        }

        /// <summary>
        /// Creates the output file.
        /// </summary>
        /// <param name="worker">The background worker object, to which progress is reported.</param>
        public void CreateOutputFile(BackgroundWorker worker)
        {
            try
            {
                /* Validate From and To - Parameter */
                validateParameter();

                /* Block state flags to indicate if a new Block has started or if it the last item of a block */
                bool newBlock = true; bool lastBlock = false; 
                int blockCount = 0;

                /* Initialization of experiment output  */
                initOutput(); 

                /* Calculations and Output for each trial and block of trial */
                for (trialID = 0, block=0, blockCount=0; trialID < ascData.TrialDataList.Count; trialID++,blockCount++)
                {      
                    /* For compability purposes with previous versions and data files*/
                    //patternList[trialID].transform(); pictureList[trialID].transform();

                    /* Set the block state flags */
                    setBlockState(ref blockCount, ref newBlock, ref lastBlock);

                    /* Check if this trial is in range */
                    if (trialID < Parameter.From) { continue; }
                    if (trialID == Parameter.From) { newBlock = true; };
                    if (trialID == Parameter.To) { lastBlock = true; }
                    else if (trialID == (Parameter.To+1)) { break; }

                    /* Create a vector of the actual pattern of the trial */
                    patternVector = new Vector(patternList[trialID].Structure, patternList[trialID].Colors);

                    if (newBlock)
                    {
                        possiblePatternVectors = Vector.CreatePossibleVectors(patternList[trialID].Colors, experiment.Trials[block].Preview.PatternSquaresX, experiment.Trials[block].Preview.PatternSquaresY);
                        newBlockOutput();
                        resetVectorLists();
                    }
    

                    /* Check if data is valid */
                    verifyData();

                    /*Output for start of trial */
                    startTrialOutput();
                    patternDataOutput();

                    /* Foreach Fixation */
                    bool firstFix = !Parameter.IncludeFirstFixation; bool firstRound = true;  int posX1st = 1; int posY1st = -1;
                    foreach (ASCFixation fix in ascData.TrialDataList[trialID].FixationList)
                    {
                        int posX = pictureList[trialID].CalculatePosX(fix.AverageX, experiment.Trials[block].Preview.SizeX);
                        int posY = pictureList[trialID].CalculatePosY(fix.AverageY, experiment.Trials[block].Preview.SizeY);
                        
                        posX += Parameter.MoveX;
                        posY += Parameter.MoveY;

                        if (posX > 0 && posY > 0)
                        {
                            if (firstRound)
                            {
                                posX1st = posX; posY1st = posY;
                                firstRound = false;
                            }
                            else if (firstFix)
                            {
                                if (posX1st != posX || posY1st != posY)
                                    firstFix = false;
                            }

                            Rectangle fixRect = calcFixationRect(patternList[trialID].SquaresX, patternList[trialID].SquaresY, posX, posY, pictureList[trialID].SquaresX, pictureList[trialID].SquaresY);
                            List<Vector> fixationVectorList = calcFixationVectorList(fixRect, pictureList[trialID], fix.Duration, patternList[trialID].SquaresX, patternList[trialID].SquaresY);                        
                            
                            bool isPatternFixation = pictureList[trialID].IsPatternFixation(new Point(posX, posY), parameter.Radius, parameter.IncludePatternFixation);
                            if (!isPatternFixation)
                                fixationOutput(posX, posY, pictureList[trialID].IsPatternFixation(new Point(posX, posY), parameter.Radius), fix, fixRect, fixationVectorList, firstFix);
                            else
                                fixationOutsideOutput(posX, posY, pictureList[trialID].IsPatternFixation(new Point(posX, posY), parameter.Radius));

                            if (!isPatternFixation && !firstFix)
                            {
                                foreach (Vector fixV in fixationVectorList)
                                {
                                    addToFixationList(fixV);
                                    addToSimilarityList(fixV);
                                    averageColorDistributionList.Add(fixV.ColorDistribution(2));
                                }
                            }
                        }
                        else
                        {
                            fixationOutsideOutput(posX, posY, false);
                        }
                    }

                    /* Output for end of trial */
                    endTrialOutput();

                    if (lastBlock)
                    {
                        List<ColorDistribution>[] avgColorDistribution = calcAverageColorDist_Classified(averageColorDistributionList);
                        double[] avgColorDistribution_Math = calcAverageColorDist_Mathematical(averageColorDistributionList);

                        Vector avgVector = Vector.AverageVector(blockFixationList, pictureList[trialID].Colors, avgColorDistribution_Math,false);
                        Vector avgVectorWW = Vector.AverageVector(blockFixationList, pictureList[trialID].Colors, avgColorDistribution_Math, true);
                        

                        List<Vector> fixationRanking = calcRankingList(blockFixationList,false);
                        //List<Vector> fixationRankingWW = calcRankingList(blockFixationListWW,true);
                        List<Vector> fixationRankingWW = calcRankingList(blockFixationList, true);

                        List<Vector> similarityRanking = calcRankingList(blockSimilarityList,false);
                        List<Vector> similarityRankingWW = calcRankingList(blockSimilarityList, true);
                        //List<Vector> similarityRankingWW = calcRankingList(blockSimilarityListWW,true);

                        List<Vector> percentageList = new List<Vector>();
                        foreach (Vector v in similarityRanking)
                        {
                            Vector newV = new Vector(v, v.Frequency, 1);
                            foreach (Vector u in possiblePatternVectors)
                            {
                                if (u.Compare(v) > 0.6)
                                {
                                    newV.Weight += (long)v.Frequency * (long)(100.0 * u.Compare(v));
                                }
                            }
                            percentageList.Add(newV);
                        }
                        List<Vector> percentageRanking = calcRankingList(percentageList, true);

                        List<Vector>[] cornerFixationRanking = new List<Vector>[4];
                        List<Vector>[] cornerFixationRankingWW = new List<Vector>[4];
                        for (int i = 0; i < 4; i++)
                        {
                            cornerFixationRanking[i] = calcRankingList(cornerFixationList[i], false);
                            cornerFixationRankingWW[i] = calcRankingList(cornerFixationList[i], true);
                        }

                        List<Vector> combinedCornerFixationRanking = calcCombinedRankingList(cornerFixationRanking,false);
                        List<Vector> combinedCornerFixationRankingWW = calcCombinedRankingList(cornerFixationRankingWW, true);

                        List<Vector>[] cornerSimilarityRanking = new List<Vector>[4];
                        List<Vector>[] cornerSimilarityRankingWW = new List<Vector>[4];
                        for (int i = 0; i < 4; i++)
                        {
                            cornerSimilarityRanking[i] = calcRankingList(cornerSimilarityList[i], false);
                            cornerSimilarityRankingWW[i] = calcRankingList(cornerSimilarityList[i], true);
                        }

                        List<Vector> combinedCornerSimilarityRanking = calcCombinedRankingList(cornerSimilarityRanking, false);
                        List<Vector> combinedCornerSimilarityRankingWW = calcCombinedRankingList(cornerSimilarityRankingWW, true);

                        List<Vector> allCornerFixationRanking = calcRankingList(allCornerFixationList, false);
                        List<Vector> allCornerFixationRankingWW = calcRankingList(allCornerFixationList, true);

                        List<Vector> allCornerSimilarityRanking = calcRankingList(allCornerSimilarityList, false);
                        List<Vector> allCornerSimilarityRankingWW = calcRankingList(allCornerSimilarityList, true);

                        
                        lastItemOfBlockOutput(similarityRanking, fixationRanking, 
                            similarityRankingWW, fixationRankingWW, 
                            avgVector, avgVectorWW, 
                            avgColorDistribution, avgColorDistribution_Math, 
                            cornerFixationRanking, cornerFixationRankingWW, 
                            cornerSimilarityRanking, cornerSimilarityRankingWW,
                            combinedCornerFixationRanking, combinedCornerFixationRankingWW,
                            combinedCornerSimilarityRanking, combinedCornerSimilarityRankingWW,
                            allCornerFixationRanking, allCornerFixationRankingWW,
                            allCornerSimilarityRanking, allCornerSimilarityRankingWW,
                            percentageRanking);
                    }

                    int progress = (int)(((double)(trialID+1-Parameter.From)) / ((double)Parameter.To-Parameter.From) * ((double)100.0));
                    if (progress > 100) progress = 100;
                    if (progress < 0) progress = 0;
                    worker.ReportProgress(progress);
           
                }

                /* Display output for end of experiment data */
                displayOutput(); 
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show("Error while creating Output files - execution cancelled:" + e.ToString(), "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
            }
            finally
            {
                /* Clean up */
                finishOutput();
            }
        }

        /// <summary>
        /// Resets the vector lists.
        /// </summary>
        private void resetVectorLists()
        {
            blockSimilarityList = new List<Vector>();
            blockFixationList = new List<Vector>();
            //blockSimilarityListWW = new List<Vector>();
            //blockFixationListWW = new List<Vector>();
            averageColorDistributionList = new List<double[]>();

            allCornerFixationList = new List<Vector>();
            allCornerSimilarityList = new List<Vector>();

            cornerFixationList = new List<Vector>[4];
            for (int i = 0; i < 4; i++)
                cornerFixationList[i] = new List<Vector>();

            cornerSimilarityList = new List<Vector>[4];
            for (int i = 0; i < 4; i++)
                cornerSimilarityList[i] = new List<Vector>();
        }

        /// <summary>
        /// Validates the parameter.
        /// </summary>
        private void validateParameter()
        {
            if (Parameter.From > AscData.TrialDataList.Count) Parameter.From = AscData.TrialDataList.Count;
            if (Parameter.From > Parameter.To || Parameter.From < 0) Parameter.From = 0;
        }

        /// <summary>
        /// Calculate the most likely vectors out of the list from all possible Vectors and adds them to similarity list.
        /// </summary>
        /// <param name="fixVector">The fixation vector.</param>
        protected void addToSimilarityList(Vector fixVector)
        {
            foreach (Vector possiblePattern in possiblePatternVectors)
            {
                double similarity = fixVector.Compare(possiblePattern);
                if (similarity >= parameter.SimilarityMeasure && similarity < 0.99)
                {
                    //highSimilarityVectorList.Add(new Vector(possiblePattern,fixVector.Weight,1));
                    Vector simV = new Vector(possiblePattern, fixVector.Weight, 1);
                    blockSimilarityList.Add(simV);

                    /* Calculate sub-pattern List */
                    for (int corner = 0; corner < 4; corner++)
                    {
                        Vector cornerV = new Vector((PatternList[trialID].SquaresX - 1) * (PatternList[trialID].SquaresY - 1), simV.Weight, simV.ColorList);
                        int offset = corner;
                        if (corner >= 2) offset += PatternList[trialID].SquaresY - 2;
                        for (int i = 0, posY = offset; i < PatternList[trialID].SquaresY - 1; posY = posY + PatternList[trialID].SquaresY, i++)
                        {
                            for (int posX = 0; posX < PatternList[trialID].SquaresX - 1; posX++)
                            {
                                cornerV.Add(simV.Colors[posX + posY]);
                            }
                        }
                        cornerSimilarityList[corner].Add(cornerV);
                        allCornerSimilarityList.Add(cornerV);
                    }
                    //blockSimilarityListWW.Add(new Vector(possiblePattern, fixVector.Weight, 1));
                }
            }
        }

        /// <summary>
        /// Adds the Vector to the fixation list.
        /// </summary>
        /// <param name="fixVector">The fixation vector.</param>
        protected void addToFixationList(Vector fixVector)
        {
            blockFixationList.Add(new Vector(fixVector, fixVector.Weight, 1));
            //blockFixationListWW.Add(new Vector(fixVector, fixVector.Weight, 1));

            /* Calculate sub-pattern List */
            for (int corner = 0; corner < 4; corner++)
            {
                Vector cornerV = new Vector((PatternList[trialID].SquaresX - 1) * (PatternList[trialID].SquaresY - 1), fixVector.Weight, fixVector.ColorList);
                int offset = corner;
                if (corner >= 2) offset += PatternList[trialID].SquaresY - 2;
                for (int i = 0, posY = offset; i < PatternList[trialID].SquaresY - 1; posY = posY + PatternList[trialID].SquaresY, i++)
                {
                    for (int posX = 0; posX < PatternList[trialID].SquaresX - 1; posX++)
                    {
                        cornerV.Add(fixVector.Colors[posX + posY]);
                    }
                }
                cornerFixationList[corner].Add(cornerV);
                allCornerFixationList.Add(cornerV);
            }
            

        }

        /// <summary>
        /// Sets the state of the newBlock and lastBlock flags.
        /// </summary>
        /// <param name="blockCount">The current block count.</param>
        /// <param name="newBlock">The newBlock flag to be set.</param>
        /// <param name="lastBlock">The lastBlock flag to be set.</param>
        protected void setBlockState(ref int blockCount, ref bool newBlock,ref bool lastBlock)
        {
            /* Check if a new block has started */
            if (blockCount == experiment.Trials[block].TrialNumbers || trialID == 0)
            {
                blockCount = 0;
                if (!(trialID == 0)) block++;
                newBlock = true;
                lastBlock = false;
            }
            /* Check if it is the last item of a block */
            else if (blockCount == experiment.Trials[block].TrialNumbers - 1)
            {
                lastBlock = true;
                newBlock = false;
            }
            else
            {
                if (newBlock) newBlock = false;
                if (lastBlock) lastBlock = false;
            }
        }

        /// <summary>
        /// Verifies the data.
        /// </summary>
        protected void verifyData()
        {
            /* Verify Trial Name from ASC-File with BMPBuilder-Files*/
            if (!experiment.Trials[block].Name.Equals(ascData.TrialDataList[trialID].TrialMetaData.TrialName))
                throw new Exception("Fehler beim Parsen von Trial " + trialID.ToString());

            /* For compability purposes with previous versions and data files: */
            /* check if position was already calculated, otherwise calculate again */
            if (pictureList[trialID].StartLocation.X == 0 && pictureList[trialID].StartLocation.Y == 0)
            {
                pictureList[trialID].StartLocation = Constants.CalcPictureLocation(
                    experiment.Trials[block].Preview.SameScreen,
                    pictureList[trialID].SquaresX, experiment.Trials[block].Preview.SizeX,
                    pictureList[trialID].SquaresY, experiment.Trials[block].Preview.SizeY
                );
            }
        }

        /// <summary>
        /// Calculates the fixation rectangle.
        /// </summary>
        /// <param name="patternSquaresX">Number of pattern squares in vertical directions.</param>
        /// <param name="patternSquaresY">Number of pattern squares in horizontal directions.</param>
        /// <param name="posX">The vertical position of the fixation.</param>
        /// <param name="posY">The horizontal position of the fixation.</param>
        /// <param name="maxSquaresX">The maximum number of squares in vertical direction..</param>
        /// <param name="maxSquaresY">The maximum number of squares in horizontal direction.</param>
        /// <returns></returns>
        protected Rectangle calcFixationRect(int patternSquaresX, int patternSquaresY, int posX, int posY, int maxSquaresX, int maxSquaresY)
        {
            double halfX = Math.Round(((double)patternSquaresX) / 2.0);
            double halfY = Math.Round(((double)patternSquaresY) / 2.0);
            int startX = posX - (int)(halfX) - parameter.Radius;
            int startY = posY - (int)(halfY) - parameter.Radius;
            if (startX < 0) startX = 0;
            if (startY < 0) startY = 0;
            int endX = posX + (int)(halfX) + parameter.Radius;
            int endY = posY + (int)(halfY) + parameter.Radius;
            if ((endX - startX) < patternSquaresX) endX = startX + patternSquaresX - 1;
            if ((endY - startY) < patternSquaresY) endY = startY + patternSquaresY - 1;
            if (endX > maxSquaresX - 1) endX = maxSquaresX - 1;
            if (endY > maxSquaresY - 1) endY = maxSquaresY - 1;
            int widthX = endX - startX + 1;
            int widthY = endY - startY + 1;
            return new Rectangle(startX, startY, widthX, widthY);
        }

        /// <summary>
        /// Calculates the fixation vector list of a given rectangle. Extracts each pattern of this fixation with the 
        /// given pattern size.
        /// </summary>
        /// <param name="fixRect">The coordinates of the fixation square, as a rectangle.</param>
        /// <param name="picture">The picture.</param>
        /// <param name="fix">The fixation.</param>
        /// <param name="squaresX">Number of squares of a pattern in vertical direction</param>
        /// <param name="squaresY">Number of squares of a pattern in horizontal direction.</param>
        /// <returns>A list of all fixations with the size of the pattern in the fixation rectangle.</returns>
        protected List<Vector> calcFixationVectorList(Rectangle fixRect, Picture picture, int weight, int squaresX, int squaresY)
        {
            /* Calculate Fixation area vectors */
            int patternsInFixation = ((fixRect.Width + 1) - squaresX) * ((fixRect.Height + 1) - squaresY);
            List<Vector> fixationVectorList = new List<Vector>();
            if (patternsInFixation > 0)
            {
                for (int t = 0, offsetX = 0, offsetY = 0; t < patternsInFixation; t++, offsetX++)
                {
                    Vector fixationVector = new Vector(squaresX * squaresY, (long)Math.Round((double)weight/10.0),pictureList[trialID].Colors);
                    bool inRange = true;
                    if ((t > 0 && (t % squaresX) == 0) || (offsetX + fixRect.X + squaresX > picture.SquaresX))
                    {
                        offsetX = 0;
                        offsetY++;
                    }
                    for (int u = 0; u < squaresX; u++)
                    {
                        for (int v = 0; v < squaresY; v++)
                        {
                            /* Attention: u and v are swapped */
                            try
                            {
                                fixationVector.Add(picture.Structure[fixRect.X + offsetX + v, fixRect.Y + offsetY + u]);
                            }
                            catch (IndexOutOfRangeException)
                            {
                                inRange = false;
                                if (!inRange) break;
                            }
                        }
                        if (!inRange) break;
                    }
                    if (inRange)
                        fixationVectorList.Add(fixationVector);
                }
            }
            return fixationVectorList;
        }

        /// <summary>
        /// Calcs the ranking list of a given vector list.
        /// </summary>
        /// <param name="vectorList">The vector list to be ranked.</param>
        /// <param name="useWeight">if set to <c>true</c> the duration is used for ranking. If set to <c>false</c>,
        /// the frequency is used for ranking.</param>
        /// <returns>A vector list, sorted by its rank (either by frequency or by duration).</returns>
        protected List<Vector> calcRankingList(List<Vector> vectorList, bool useWeight)
        {
            List<Vector> ranking = new List<Vector>();
            for (int i = 0; i < vectorList.Count;i++)
            {
                if (!ranking.Contains(vectorList[i]))
                {
                    long frequency = (vectorList.FindAll(vectorList[i].Equals)).Count;
                    long weight = vectorList[i].Weight * frequency;
                    ranking.Add(new Vector(vectorList[i],weight,frequency));
                }
            }
            if (!useWeight)
                ranking.Sort();
            else
                ranking.Sort(Vector.CompareToUsingWeight);
            return ranking;
        }

        /// <summary>
        /// Calculates a ranking list of sub patterns. Works only for 2x2 size sub-pattern to create a 3x3 combined Pattern.
        /// </summary>
        /// <param name="vectorListArray">The array containing a list of all sub-patterns that the function should combine.</param>
        /// <param name="useWeight">If set to <c>true</c> use weight.</param>
        /// <returns>A list of the combined sub-patterns</returns>
        protected List<Vector> calcCombinedRankingList(List<Vector>[] vectorListArray, bool useWeight)
        {
            List<Vector> combinedRanking = new List<Vector>();
            try
            {
                for (int i = 0; i < Parameter.Top10; i++)
                {
                    if (vectorListArray[0][i].Size != 4)
                        throw new Exception("Method does only suppoert 2x2 sub patterns to generate 3x3 combined patterns!");
                    Vector combinedVector = new Vector(9, patternList[trialID].Colors);

                    /* This function needs to be modified, so that it is more automatic and sophisticated! */
                    #region calculate for each position which sub-pattern has either the higher frequency or weight
                    if (!useWeight)
                    {
                        for (int pos = 0; pos < combinedVector.Size; pos++)
                        {
                            if (pos == 0) combinedVector.Add(vectorListArray[0][i].Colors[0]);
                            else if (pos == 1)
                                if (vectorListArray[0][i].Frequency > vectorListArray[1][i].Frequency)
                                    combinedVector.Add(vectorListArray[0][i].Colors[1]);
                                else
                                    combinedVector.Add(vectorListArray[1][i].Colors[0]);
                            else if (pos == 2) combinedVector.Add(vectorListArray[1][i].Colors[1]);
                            else if (pos == 3)
                                if (vectorListArray[0][i].Frequency > vectorListArray[2][i].Frequency)
                                    combinedVector.Add(vectorListArray[0][i].Colors[2]);
                                else
                                    combinedVector.Add(vectorListArray[2][i].Colors[0]);
                            else if (pos == 4)
                                if ((vectorListArray[0][i].Frequency > vectorListArray[1][i].Frequency) &&
                                    (vectorListArray[0][i].Frequency > vectorListArray[2][i].Frequency) &&
                                    (vectorListArray[0][i].Frequency > vectorListArray[3][i].Frequency))
                                    combinedVector.Add(vectorListArray[0][i].Colors[3]);
                                else if ((vectorListArray[1][i].Frequency > vectorListArray[0][i].Frequency) &&
                                    (vectorListArray[1][i].Frequency > vectorListArray[2][i].Frequency) &&
                                    (vectorListArray[1][i].Frequency > vectorListArray[3][i].Frequency))
                                    combinedVector.Add(vectorListArray[1][i].Colors[2]);
                                else if ((vectorListArray[2][i].Frequency > vectorListArray[0][i].Frequency) &&
                                    (vectorListArray[2][i].Frequency > vectorListArray[1][i].Frequency) &&
                                    (vectorListArray[2][i].Frequency > vectorListArray[3][i].Frequency))
                                    combinedVector.Add(vectorListArray[2][i].Colors[1]);
                                else
                                    combinedVector.Add(vectorListArray[3][i].Colors[0]);
                            else if (pos == 5)
                                if (vectorListArray[1][i].Frequency > vectorListArray[3][i].Frequency)
                                    combinedVector.Add(vectorListArray[1][i].Colors[3]);
                                else
                                    combinedVector.Add(vectorListArray[3][i].Colors[1]);
                            else if (pos == 6) combinedVector.Add(vectorListArray[2][i].Colors[2]);
                            else if (pos == 7)
                                if (vectorListArray[2][i].Frequency > vectorListArray[3][i].Frequency)
                                    combinedVector.Add(vectorListArray[2][i].Colors[3]);
                                else
                                    combinedVector.Add(vectorListArray[3][i].Colors[2]);
                            else if (pos == 8) combinedVector.Add(vectorListArray[3][i].Colors[3]);
                        }
                    }
                    else
                    {
                        for (int pos = 0; pos < combinedVector.Size; pos++)
                        {
                            if (pos == 0) combinedVector.Add(vectorListArray[0][i].Colors[0]);
                            else if (pos == 1)
                                if (vectorListArray[0][i].Weight > vectorListArray[1][i].Weight)
                                    combinedVector.Add(vectorListArray[0][i].Colors[1]);
                                else
                                    combinedVector.Add(vectorListArray[1][i].Colors[0]);
                            else if (pos == 2) combinedVector.Add(vectorListArray[1][i].Colors[1]);
                            else if (pos == 3)
                                if (vectorListArray[0][i].Weight > vectorListArray[2][i].Weight)
                                    combinedVector.Add(vectorListArray[0][i].Colors[2]);
                                else
                                    combinedVector.Add(vectorListArray[2][i].Colors[0]);
                            else if (pos == 4)
                                if ((vectorListArray[0][i].Weight > vectorListArray[1][i].Weight) &&
                                    (vectorListArray[0][i].Weight > vectorListArray[2][i].Weight) &&
                                    (vectorListArray[0][i].Weight > vectorListArray[3][i].Weight))
                                    combinedVector.Add(vectorListArray[0][i].Colors[3]);
                                else if ((vectorListArray[1][i].Weight > vectorListArray[0][i].Weight) &&
                                    (vectorListArray[1][i].Weight > vectorListArray[2][i].Weight) &&
                                    (vectorListArray[1][i].Weight > vectorListArray[3][i].Weight))
                                    combinedVector.Add(vectorListArray[1][i].Colors[2]);
                                else if ((vectorListArray[2][i].Weight > vectorListArray[0][i].Weight) &&
                                    (vectorListArray[2][i].Weight > vectorListArray[1][i].Weight) &&
                                    (vectorListArray[2][i].Weight > vectorListArray[3][i].Weight))
                                    combinedVector.Add(vectorListArray[2][i].Colors[1]);
                                else
                                    combinedVector.Add(vectorListArray[3][i].Colors[0]);
                            else if (pos == 5)
                                if (vectorListArray[1][i].Weight > vectorListArray[3][i].Weight)
                                    combinedVector.Add(vectorListArray[1][i].Colors[3]);
                                else
                                    combinedVector.Add(vectorListArray[3][i].Colors[1]);
                            else if (pos == 6) combinedVector.Add(vectorListArray[2][i].Colors[2]);
                            else if (pos == 7)
                                if (vectorListArray[2][i].Weight > vectorListArray[3][i].Weight)
                                    combinedVector.Add(vectorListArray[2][i].Colors[3]);
                                else
                                    combinedVector.Add(vectorListArray[3][i].Colors[2]);
                            else if (pos == 8) combinedVector.Add(vectorListArray[3][i].Colors[3]);
                        }
                    }
                    #endregion

                    combinedVector.Frequency = vectorListArray[0][i].Frequency + vectorListArray[1][i].Frequency +
                        vectorListArray[2][i].Frequency + vectorListArray[3][i].Frequency;
                    combinedVector.Weight = vectorListArray[0][i].Weight + vectorListArray[1][i].Weight +
                        vectorListArray[2][i].Weight + vectorListArray[3][i].Weight;
                    combinedRanking.Add(combinedVector);
                }
            }
            catch (ArgumentOutOfRangeException ae) { ; } 
            return combinedRanking;
        }

        /// <summary>
        /// Calculates the average color distribution by calculating the mathematical mean.
        /// </summary>
        /// <param name="averageColorDistributionList">The average color distribution list.</param>
        /// <returns>An array with the the mathematical mean for each color.</returns>
        protected double[] calcAverageColorDist_Mathematical(List<double[]> averageColorDistributionList)
        {
            double[] overallColDist = new double[PatternList[trialID].Colors.Count];
            foreach (double[] colDist in averageColorDistributionList)
            {
                int colNr = 0;
                foreach (double d in colDist)
                {
                    overallColDist[colNr] += d / averageColorDistributionList.Count;
                    colNr++;
                }
            }
            return overallColDist;
        }

        /// <summary>
        /// Calcs the average color distribution by bins.
        /// </summary>
        /// <param name="averageColorDistributionList">The average color distribution list</param>
        /// <returns></returns>
        protected List<ColorDistribution>[] calcAverageColorDist_Classified(List<double[]> averageColorDistributionList)
        {
            List<ColorDistribution>[] overallColDist = new List<ColorDistribution>[PatternList[trialID].Colors.Count];
            for (int i = 0; i < PatternList[trialID].Colors.Count; i++)
                overallColDist[i] = new List<ColorDistribution>();
            foreach (double[] colDist in averageColorDistributionList)
            {
                int colNr = 0;
                foreach (double d in colDist)
                {
                    bool add = false;
                    foreach (ColorDistribution colorCount in overallColDist[colNr])
                    {
                        if (colorCount.Percentage == colDist[colNr]) {
                            colorCount.Frequency++; 
                            add = true;
                        }
                    }
                    if (!add) overallColDist[colNr].Add(new ColorDistribution(colDist[colNr],0));
                    colNr++;
                }
            }
            for (int i = 0; i < PatternList[trialID].Colors.Count; i++)
                overallColDist[i].Sort();
            return overallColDist;
        }

        /// <summary>
        /// Inits the output.
        /// </summary>
        protected abstract void initOutput();

        /// <summary>
        /// Called when a new block of trials begins.
        /// </summary>
        protected abstract void newBlockOutput();

        /// <summary>
        /// Called when the last item of a trial block has been passed
        /// </summary>
        /// <param name="ranking">The ranking list of fixations the current trial block, , ranked by frequency.</param>
        /// <param name="averageRanking">The ranking list of possbile Patterns with high similarity to the fixations, ranked by frequency.</param>
        /// <param name="rankingWithWeight">The ranking list of fixations the current trial block, , ranked by total duration.</param>
        /// <param name="averageRankingWithWeight">The ranking list of possbile Patterns with high similarity to the fixations, ranked by total duration.</param>
        /// <param name="averageVector">The overall average vector of all fixation.</param>
        /// <param name="averageVectorWW">The overall average vector, considering the duration. of the fixations.</param>
        /// <param name="overallColorDist">The overall color dist.</param>
        /// <param name="overallColorDist_M">The overall color dist_ M.</param>
        /// <param name="cornerFixationRanking">The  ranking of the sub-fixations, , divided into their corner positions.</param>
        /// <param name="cornerFixationRankingWithWeight">The ranking of the sub-fixations , divided into their corner positions, with weight.</param>
        /// <param name="cornerSimilarityRanking">The ranking of the sub-patterns with a high similarity to the target-pattern, divided into their corner positions,</param>
        /// <param name="cornerSimilarityRankingWithWeight">The ranking of the sub-patterns with a high similarity to the target-pattern, divided into their corner positions, ranked by weight</param>
        /// <param name="combinedCornerFixationRanking">The ranking of the sub-fixations with all combined to one pattern</param>
        /// <param name="combinedCornerFixationRankingWW">The ranking of the sub-fixations with all combined to one pattern, considering weight</param>
        /// <param name="combinedCornerSimilarityRanking">The ranking of the sub-patterns with a high similarity to the target pattern, all combined to one pattern</param>
        /// <param name="combinedCornerSimilarityRankingWW">The ranking of the sub-patterns with a high similarity to the target pattern, all combined to one pattern, considering weight</param>
        /// <param name="allCornerFixationRanking">A ranking of all sub-fixations, not divided by corners.</param>
        /// <param name="allCornerFixationRankingWW">A ranking of all sub-fixations, not divided by corners, cosidering weight.</param>
        /// <param name="allCornerSimilarityRanking">A ranking of all sub-fixations with a high similarity to the target pattern, not divided by corners.</param>
        /// <param name="allCornerSimilarityRankingWW">A ranking of all sub-fixations with a high similarity to the target pattern, not divided by corners, considering weight.</param>
        /// <param name="percentageRanking">A ranking where a score for each pattern was calculated.</param>
        protected abstract void lastItemOfBlockOutput(List<Vector> ranking, List<Vector> averageRanking, 
            List<Vector> rankingWithWeight, List<Vector> averageRankingWithWeight, 
            Vector averageVector, Vector averageVectorWW, 
            List<ColorDistribution>[] overallColorDist, double[] overallColorDist_M, 
            List<Vector>[] cornerFixationRanking, List<Vector>[] cornerFixationRankingWithWeight, 
            List<Vector>[] cornerSimilarityRanking, List<Vector>[] cornerSimilarityRankingWithWeight,
            List<Vector> combinedCornerFixationRanking, List<Vector> combinedCornerFixationRankingWW,
            List<Vector> combinedCornerSimilarityRanking, List<Vector> combinedCornerSimilarityRankingWW,
            List<Vector> allCornerFixationRanking, List<Vector> allCornerFixationRankingWW,
            List<Vector> allCornerSimilarityRanking, List<Vector> allCornerSimilarityRankingWW,
            List<Vector> percentageRanking);

        /// <summary>
        /// Called when the trial output starts.
        /// </summary>
        protected abstract void startTrialOutput();

        /// <summary>
        /// Called at the begin of a trial, when the pattern data is calculated.
        /// </summary>
        protected abstract void patternDataOutput();

        /// <summary>
        /// Called when new fixation data has been calculated.
        /// </summary>
        /// <param name="posX">The vertical Position of the fixation.</param>
        /// <param name="posY">The horizontal Position of the fixation.</param>
        /// <param name="patternFixation">If set to <c>true</c> this function is also called if the fixation included the target pattern..</param>
        /// <param name="fix">The fixation data.</param>
        /// <param name="fixRect">The fixation rectangle.</param>
        /// <param name="fixationVectorList">The fixation vector list.</param>
        /// <param name="firstFixation">if set to <c>true</c> the fixation was the first fixation of the trial.</param>
        protected abstract void fixationOutput(int posX, int posY, bool patternFixation, ASCFixation fix, Rectangle fixRect, List<Vector> fixationVectorList, bool firstFixation);

        /// <summary>
        /// Called when new fixation data has been calculated and the fixation was outside the picture or included the target pattern.
        /// </summary>
        /// <param name="posX">The vertical position of the fixation (-1 if the fixation was outside).</param>
        /// <param name="posY">The horizontal position of the fixation (-1 if the fixation was outside).</param>
        /// <param name="patternFixation">if set to <c>true</c> the fixation included the target pattern..</param>
        protected abstract void fixationOutsideOutput(int posX, int posY, bool patternFixation);

        /// <summary>
        /// Called when the end of a trial has been passed.
        /// </summary>
        protected abstract void endTrialOutput();

        /// <summary>
        /// Called at the end of all trials, now the calculated data can be displayed (if not already done).
        /// </summary>
        protected abstract void displayOutput();

        /// <summary>
        /// Always called at then end of all trials, even if exceptions/errors occured. Should be used to free all used resources.
        /// </summary>
        protected abstract void finishOutput();



    }
}
