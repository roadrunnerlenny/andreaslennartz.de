using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;
using System.Drawing;
using BMPBuilder;
using ASCLibrary;
using System.IO;


namespace BMPAnalysis
{
    /// <summary>
    /// Displays the main GUI for the analysis tool. 
    /// </summary>
    public partial class MainForm : Form
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MainForm"/> class.
        /// </summary>
        public MainForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// This contains a list of all Data Objects to be analysed.
        /// </summary>
        List<AnalysisObject> dataList = new List<AnalysisObject>();

        /// <summary>
        /// The actual data object which informations are currently processed by the GUI
        /// </summary>
        AnalysisObject actData = null;

        /// <summary>
        /// Handles the Click event of the experimentFolderButton control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void experimentFolderButton_Click(object sender, EventArgs e)
        {
            if (experimentFolderBrowserDialog.ShowDialog() == DialogResult.OK)
            {
                clearDataFileInformation();
                addButton.Enabled = false;
                dataFileButton.Enabled = false;
                dataFileLabel.Text = "";

                string experimentFolder = experimentFolderBrowserDialog.SelectedPath;

                if (parseFolderData(experimentFolder))
                {
                    experimentFolderLabel.ForeColor = Color.Black;
                    experimentFolderLabel.Text = actData.Name;
                    dataFileButton.Enabled = true;
                    openDataFileDialog.InitialDirectory = experimentFolder;   
                }
                else
                {
                    experimentFolderLabel.ForeColor = Color.Red;
                    experimentFolderLabel.Text = "Not a valid directory!!!";
                    dataFileButton.Enabled = false;
                }
            }
        }

        /// <summary>
        /// Reads the experiment folder data.
        /// </summary>
        /// <param name="experimentFolder">The experiment folder.</param>
        /// <returns><c>True</c>, if folder looks consistent.</returns>
        private bool parseFolderData(string experimentFolder)
        {
            actData = new AnalysisObject();
            actData.Experiment = new ExperimentData();
            actData.PatternList = new List<Pattern>();
            actData.PictureList = new List<Picture>();

            if (File.Exists(experimentFolder + @"\" + Constants.ConfigFileName) &&
                    Directory.Exists(experimentFolder + @"\" + Constants.ImageFolderName) &&
                    Directory.Exists(experimentFolder + @"\" + Constants.DataFolderName)
                )
            {
                actData.Experiment = ExperimentData.LoadExperiment(experimentFolder + @"\" + Constants.ExperimentFileName);
                actData.Config = new Config(experimentFolder + @"\" + Constants.ConfigFileName);

                int trialNr = 1;
                foreach (TrialData trialBlock in actData.Experiment.Trials)
                {
                    for (int i=0;i<trialBlock.TrialNumbers;i++) {
                        actData.PatternList.Add((Pattern)(Pattern.Load(experimentFolder + @"\" + Constants.DataFolderName + @"\" + Constants.PatternDataPrefix + trialNr.ToString() + Constants.DataPostfix)));
                        actData.PictureList.Add((Picture)(Picture.Load(experimentFolder + @"\" + Constants.DataFolderName + @"\" + Constants.PictureDataPrefix + trialNr.ToString() + Constants.DataPostfix)));
                        trialNr++;
                    }
                        
                }
                actData.ExperimentFolder = experimentFolder;
                actData.Name = experimentFolder.Substring(experimentFolder.LastIndexOf(@"\") + 1);

                return true;
            }
            else
            {
                return false;
            }
        }


        /// <summary>
        /// Handles the Click event of the dataFileButton control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void dataFileButton_Click(object sender, EventArgs e)
        {

            if (openDataFileDialog.ShowDialog() == DialogResult.OK)
            {
                string dataFile = openDataFileDialog.FileName;
                dataFileLabel.Text = dataFile.Substring(dataFile.LastIndexOf(@"\") + 1);

                if (parseDataFile(dataFile))
                {
                    rawDataButton.Enabled = true;
                    generateExcelButton.Enabled = true;
                    addButton.Enabled = true;
                    setDataFileInformation();
                    addButton.Enabled = true;
                }
                else
                {
                    rawDataButton.Enabled = false;
                    generateExcelButton.Enabled = false;
                    addButton.Enabled = false;
                    clearDataFileInformation();
                    addButton.Enabled = false;
                }
            }
        }

        /// <summary>
        /// Reads the ASC-Data file.
        /// </summary>
        /// <param name="dataFile">The ASC-data file.</param>
        /// <returns><c>True</c> if data is consitent</returns>
        private bool parseDataFile(string dataFile)
        {
            actData.AscData = new ASCData();
            actData.DataFile = dataFile;
            actData.AscData.LoadData(dataFile);
       
            if (actData.AscData != null)
                return true;
            else 
                return false;
        }

        /// <summary>
        /// Updates the data file information in the GUI.
        /// </summary>
        private void setDataFileInformation() 
        {

                int trialNumbers = actData.AscData.TrialDataList.Count;
                trialNumbersLabel.Text = trialNumbers.ToString();
                int fixationNumber = 0;
                foreach (ASCTrialData trialData in actData.AscData.TrialDataList)
                    fixationNumber += trialData.FixationList.Count;
                fixationNumbersLabel.Text = fixationNumber.ToString();
                int averageFixation = (int)Math.Round( (decimal)(fixationNumber / trialNumbers));
                averageFixationsLabel.Text = averageFixation.ToString();
                this.fromTextBox.Text = "1";
                this.toTextBox.Text = actData.AscData.TrialDataList.Count.ToString();

        }

        /// <summary>
        /// Clears the data file information in the GUI
        /// </summary>
        private void clearDataFileInformation()
        {
            trialNumbersLabel.Text = "0";
            fixationNumbersLabel.Text = "0";
            averageFixationsLabel.Text = "0";
        }

        /// <summary>
        /// Handles the Click event of the exitToolStripMenuItem control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            System.Windows.Forms.Application.Exit();
        }


        /// <summary>
        /// Deactivates the generate buttons.
        /// </summary>
        private void deactivateButtons()
        {
            if (generateExcelButton.Enabled) generateExcelButton.Enabled = false;
            if (rawDataButton.Enabled) rawDataButton.Enabled = false;
            outputLabel.Text = "Please Wait!";
        }

        /// <summary>
        /// Activates the generate buttons.
        /// </summary>
        private void activateButtons()
        {
            outputLabel.Text = "Done!";
            if (!rawDataButton.Enabled) rawDataButton.Enabled = true;
            if (!generateExcelButton.Enabled) generateExcelButton.Enabled = true;
        }

        /// <summary>
        /// Parses the parameter data from the GUI
        /// </summary>
        /// <returns></returns>
        private bool parseParameterData()
        {
            try
            {
                actData.ParameterList = new OutputFileParameter();
                actData.ParameterList.IncludePatternFixation = includePatternFixationCheckBox.Checked;
                actData.ParameterList.SimilarityMeasure = double.Parse(similarityComboBox.Text);
                actData.ParameterList.IncludeFirstFixation = includeFirstFixationCheckBox.Checked;
                actData.ParameterList.ShortExcelReport = shortExcelCheckBox.Checked;
                actData.ParameterList.Radius = (int.Parse(radiusComboBox.Text) - 1);
                actData.ParameterList.From = (int.Parse(fromTextBox.Text) - 1);
                actData.ParameterList.To = (int.Parse(toTextBox.Text) - 1);
                actData.ParameterList.Top10 = int.Parse(top10TextBox.Text);
                if (moveXComboBox.SelectedItem.ToString().Equals("Left"))
                    actData.ParameterList.MoveX = -1;
                else if (moveXComboBox.SelectedItem.ToString().Equals("Center"))
                    actData.ParameterList.MoveX = 0;
                else if (moveXComboBox.SelectedItem.ToString().Equals("Right"))
                    actData.ParameterList.MoveX = 1;
                if (moveYComboBox.SelectedItem.ToString().Equals("Top"))
                    actData.ParameterList.MoveY = -1;
                else if (moveYComboBox.SelectedItem.ToString().Equals("Center"))
                    actData.ParameterList.MoveY = 0;
                else if (moveYComboBox.SelectedItem.ToString().Equals("Bottom"))
                    actData.ParameterList.MoveY = 1;

                return true;
            }
            catch (FormatException fe)
            {
                 return false;
            }
        }

        /// <summary>
        /// Handles the DoWork event of the generateBackgroundWorker control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.ComponentModel.DoWorkEventArgs"/> instance containing the event data.</param>
        private void generateBackgroundWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            // Get the BackgroundWorker that raised this event.
            BackgroundWorker worker = sender as BackgroundWorker;
            List<AnalysisObject> outputDataList = (List<AnalysisObject>)(e.Argument);

            int count = 1;
            foreach (AnalysisObject outputData in outputDataList)
            {
                if (outputData.ParameterList.Excel)
                {
                    OutputFileExcel excelOutput = new OutputFileExcel(outputData.ParameterList, outputData.Experiment, outputData.PictureList, outputData.PatternList, outputData.Config, outputData.AscData, outputData.DataFile, outputData.ExperimentFolder);
                    excelOutput.CreateOutputFile(worker);
                }
                else if (outputData.ParameterList.RawData)
                {
                    OutputFileRawData rawDataOutput = new OutputFileRawData(outputData.ParameterList, outputData.Experiment, outputData.PictureList, outputData.PatternList, outputData.Config, outputData.AscData, outputData.DataFile, outputData.ExperimentFolder);
                    rawDataOutput.CreateOutputFile(worker);
                }
        
            }
        }

        /// <summary>
        /// Handles the ProgressChanged event of the generateBackgroundWorker control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.ComponentModel.ProgressChangedEventArgs"/> instance containing the event data.</param>
        private void generateBackgroundWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            this.outputProgressBar.Value = e.ProgressPercentage;
        }

        /// <summary>
        /// Handles the RunWorkerCompleted event of the generateBackgroundWorker control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.ComponentModel.RunWorkerCompletedEventArgs"/> instance containing the event data.</param>
        private void generateBackgroundWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            activateButtons();
        }

        /// <summary>
        /// Handles the Click event of the generateExcelButton control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void generateExcelButton_Click(object sender, EventArgs e)
        {

            this.deactivateButtons();
            foreach (AnalysisObject data in dataList)
            {
                data.ParameterList.Excel = true;
            }
            generateBackgroundWorker.RunWorkerAsync(dataList);
        }

        /// <summary>
        /// Handles the Click event of the rawDataButton control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void rawDataButton_Click(object sender, EventArgs e)
        {
            this.deactivateButtons();
            string rawDataFolder = "";
            if (rawDataFolderBrowserDialog.ShowDialog() == DialogResult.OK)
            {
                rawDataFolder = rawDataFolderBrowserDialog.SelectedPath+@"\";
                foreach (AnalysisObject data in dataList)
                {
                    data.ParameterList.OutputFolder = rawDataFolder;
                    data.ParameterList.RawData = true;
                }
                generateBackgroundWorker.RunWorkerAsync(dataList);
            }
            else
            {
                MessageBox.Show(this,"Could not create Raw Data Files!","Creation cancelled",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
                activateButtons();
                return;
            }
        
        }

        /// <summary>
        /// Handles the Click event of the infoToolStripMenuItem control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void infoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Info info = new Info();
            info.ShowDialog();
            info.Focus();
        }

        /// <summary>
        /// Handles the Load event of the MainForm control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void MainForm_Load(object sender, EventArgs e)
        {
            radiusComboBox.SelectedIndex = 1;
            similarityComboBox.SelectedIndex = 3;
            moveXComboBox.SelectedIndex = 1;
            moveYComboBox.SelectedIndex = 1;
        }

        /// <summary>
        /// Handles the Click event of the addButton control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void addButton_Click(object sender, EventArgs e)
        {
            actData.ParameterList = new OutputFileParameter();
            if (parseParameterData())
            {
                dataList.Add(actData);

                ListViewItem queueItem = new ListViewItem(actData.Name, 0);
                int radius = (actData.ParameterList.Radius)+1;
                queueItem.SubItems.Add(radius.ToString());
                int from = (actData.ParameterList.From)+1;
                queueItem.SubItems.Add(from.ToString());
                int to = (actData.ParameterList.To)+1;
                queueItem.SubItems.Add(to.ToString());
                queueItem.SubItems.Add(actData.ParameterList.MoveX.ToString());
                queueItem.SubItems.Add(actData.ParameterList.MoveY.ToString());
                queueListView.Items.AddRange(new ListViewItem[] { queueItem });

                clearDataFileInformation();
                dataFileButton.Enabled = false;
                addButton.Enabled = false;
                dataFileLabel.Text = "";
                experimentFolderLabel.Text = "";
                actData = null;
            }
            else
            {
                MessageBox.Show(this, "Not all Parameters properly defined!", "Error parsing parameters", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        /// <summary>
        /// Handles the SelectedIndexChanged event of the queueListView control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void queueListView_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (queueListView.SelectedItems.Count > 0)
            {
                deleteButton.Enabled = true;
            }
            else
            {
                deleteButton.Enabled = false;
            }
        }

        /// <summary>
        /// Handles the Click event of the deleteButton control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void deleteButton_Click(object sender, EventArgs e)
        {
            try
            {
                int itemNumber = queueListView.Items.IndexOf(queueListView.SelectedItems[0]);
                dataList.RemoveAt(itemNumber);
                queueListView.Items.RemoveAt(itemNumber);
            }
            catch (ArgumentOutOfRangeException ae) { ;}
        }




    }
}