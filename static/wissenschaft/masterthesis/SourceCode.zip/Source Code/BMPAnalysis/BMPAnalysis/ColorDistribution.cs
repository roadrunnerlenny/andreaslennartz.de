using System;
using System.Collections.Generic;
using System.Text;

namespace BMPAnalysis
{
    /// <summary>
    /// Defines a color distribution of two or more colors - a distribution contains the percentage.
    /// </summary>
    public class ColorDistribution : IComparable
    {
        private double percentage;

        /// <summary>
        /// Gets or sets the percentage.
        /// </summary>
        /// <value>The percentage.</value>
        public double Percentage
        {
            get { return percentage; }
            set { percentage = value; }
        }

        private long frequency;

        /// <summary>
        /// Gets or sets the frequency.
        /// </summary>
        /// <value>The frequency.</value>
        public long Frequency
        {
            get { return frequency; }
            set { frequency = value; }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ColorDistribution"/> class.
        /// </summary>
        /// <param name="percentage">The percentage.</param>
        /// <param name="frequency">The frequency.</param>
        public ColorDistribution(double percentage, long frequency)
        {
            this.percentage = percentage;
            this.frequency = frequency;
        }

        /// <summary>
        /// Compares the current instance with another object of the same type.
        /// </summary>
        /// <param name="obj">An object to compare with this instance.</param>
        /// <returns>
        /// A 32-bit signed integer that indicates the relative order of the objects being compared. The return value has these meanings: Value Meaning Less than zero This instance is less than obj. Zero This instance is equal to obj. Greater than zero This instance is greater than obj.
        /// </returns>
        /// <exception cref="T:System.ArgumentException">obj is not the same type as this instance. </exception>
        public int CompareTo(object obj)
        {
            if (obj is ColorDistribution)
            {
                ColorDistribution cd = (ColorDistribution)obj;
                if (frequency > cd.frequency) return -1;
                else if (frequency < cd.frequency) return 1;
                else return 0;
            }
            else throw new ArgumentException("Argument not of type ColorDistribution!");
        }
    }
}
