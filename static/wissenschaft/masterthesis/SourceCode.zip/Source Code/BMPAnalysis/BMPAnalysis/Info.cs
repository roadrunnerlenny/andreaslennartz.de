using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BMPAnalysis
{
    /// <summary>
    /// Displays the Info window with description about the author and program. 
    /// </summary>
    public partial class Info : Form
    {
        public Info()
        {
            InitializeComponent();
        }
    }
}