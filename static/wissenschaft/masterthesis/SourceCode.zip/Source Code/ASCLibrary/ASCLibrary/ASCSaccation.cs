using System;
using System.Collections.Generic;
using System.Text;

namespace ASCLibrary
{
    /// <summary>
    /// Contains all information about a saccade event in an ASC-Data File.
    /// </summary>
    [Serializable]
    public class ASCSaccation
    {
        private int startTime;

        /// <summary>
        /// Gets or sets the start time in ms, relative to the start of the experiment.
        /// </summary>
        /// <value>The start time in ms, relative to the start of the experiment.</value>
        public int StartTime
        {
            get { return startTime; }
            set { startTime = value; }
        }

        private int endTime;

        /// <summary>
        /// Gets or sets the end time in ms, relative to the start of the experiment.
        /// </summary>
        /// <value>The end time in ms, relative to the start of the experiment.</value>
        public int EndTime
        {
            get { return endTime; }
            set { endTime = value; }
        }

        private int duration;

        /// <summary>
        /// Gets or sets the duration in ms.
        /// </summary>
        /// <value>The duration in ms.</value>
        public int Duration
        {
            get { return duration; }
            set { duration = value; }
        }

        private int startX;

        /// <summary>
        /// Gets or sets the start X-position on the screen.
        /// </summary>
        /// <value>The start X-position on the screen.</value>
        public int StartX
        {
            get { return startX; }
            set { startX = value; }
        }

        private int startY;

        /// <summary>
        /// Gets or sets the start Y-position on the screen.
        /// </summary>
        /// <value>The start Y-position on the screen.</value>
        public int StartY
        {
            get { return startY; }
            set { startY = value; }
        }

        private int endX;

        /// <summary>
        /// Gets or sets the end X-position on the screen.
        /// </summary>
        /// <value>The end X-position on the screen.</value>
        public int EndX
        {
            get { return endX; }
            set { endX = value; }
        }

        private int endY;

        /// <summary>
        /// Gets or sets the end Y-position on the screen.
        /// </summary>
        /// <value>The end Y-position on the screen.</value>
        public int EndY
        {
            get { return endY; }
            set { endY = value; }
        }

        private decimal saccadicAmplitude;

        /// <summary>
        /// Gets or sets the saccadic amplitude.
        /// </summary>
        /// <value>The saccadic amplitude.</value>
        public decimal SaccadicAmplitude
        {
            get { return saccadicAmplitude; }
            set { saccadicAmplitude = value; }
        }

        private int peakVelocity;

        /// <summary>
        /// Gets or sets the peak velocity.
        /// </summary>
        /// <value>The peak velocity.</value>
        public int PeakVelocity
        {
            get { return peakVelocity; }
            set { peakVelocity = value; }
        }



    }
}
