using System;
using System.Collections.Generic;
using System.Text;

namespace ASCLibrary
{
    /// <summary>
    /// Contains all information about a Fixation-Event in an ASC-Data File.
    /// </summary>
    [Serializable]
    public class ASCFixation
    {
        private int startTime;

        /// <summary>
        /// Gets or sets the start time of the fixation in ms, relative to the start of the experiment.
        /// </summary>
        /// <value>The start time of the fixation in ms, relative to the start of the experiment.</value>
        public int StartTime
        {
            get { return startTime; }
            set { startTime = value; }
        }

        private int endTime;

        /// <summary>
        /// Gets or sets the end time of the fixation in ms, relative to the start of the experiment.
        /// </summary>
        /// <value>The end time of the fixation in ms, relative to the start of the experiment.</value>
        public int EndTime
        {
            get { return endTime; }
            set { endTime = value; }
        }

        private int duration;

        /// <summary>
        /// Gets or sets the duration of the fixation in ms.
        /// </summary>
        /// <value>The duration of the fixation in ms.</value>
        public int Duration
        {
            get { return duration; }
            set { duration = value; }
        }

        private int averageX;

        /// <summary>
        /// Gets or sets the average X fixation value on the screen. 
        /// </summary>
        /// <value>The average X fixation value on the screen. </value>
        public int AverageX
        {
            get { return averageX; }
            set { averageX = value; }
        }

        private int averageY;

        /// <summary>
        /// Gets or sets the average Y fixation value on the screen. 
        /// </summary>
        /// <value>The average Y fixation value on the screen. </value>
        public int AverageY
        {
            get { return averageY; }
            set { averageY = value; }
        }

        private int averagePupilSize;

        /// <summary>
        /// Gets or sets the average size of the pupil in pixel.
        /// </summary>
        /// <value>The average size of the pupil in pixel.</value>
        public int AveragePupilSize
        {
            get { return averagePupilSize; }
            set { averagePupilSize = value; }
        }

        private int posX;

        /// <summary>
        /// Gets or sets the X-Position  of the fixation. Not used/deprecated.
        /// </summary>
        /// <value>The X-Position  of the fixation. Not used/deprecated</value>
        public int PosX
        {
            get { return posX; }
            set { posX = value; }
        }

        private int posY;

        /// <summary>
        /// Gets or sets the Y-Pos of the fixation. Not used/deprecated
        /// </summary>
        /// <value>The Y-Pos  of the fixation. Not used/deprecated.</value>
        public int PosY
        {
            get { return posY; }
            set { posY = value; }
        }
    }
}
