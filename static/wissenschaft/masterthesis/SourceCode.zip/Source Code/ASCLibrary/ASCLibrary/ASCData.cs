using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace ASCLibrary
{
    /// <summary>
    /// Contains all information of events in an ASC-Data File, that is extracted from an .edf-File of an EyeTracker experiment.
    /// </summary>
    [Serializable]
    public class ASCData
    {
        List<ASCTrialData> trialDataList = new List<ASCTrialData>();

        /// <summary>
        /// Gets or sets the trial data list.
        /// </summary>
        /// <value>The trial data list.</value>
        public List<ASCTrialData> TrialDataList
        {
            get { return trialDataList; }
            set { trialDataList = value; }
        }

        /// <summary>
        /// Loads the data of an ASC-File.
        /// </summary>
        /// <param name="filename">The filename.</param>
        public void LoadData(string filename)
        {
            bool trial = false;
            ASCTrialData actTrialData = null;

            try
            {
                using (TextReader tr = new StreamReader(filename))
                {
                    string line = "";
                    while ((line = tr.ReadLine()) != null)
                    {
                        try
                        {
                            if (line.StartsWith("**")) continue;
                            else if (line.StartsWith("MSG"))
                            {
                                if (!trial) //Define a new trial
                                {
                                    actTrialData = new ASCTrialData();
                                    trial = true;
                                }
                                string[] content = line.Split('\t', ' ');

                                if (content[2].StartsWith("TRIALID"))
                                {
                                    if (content[3].Contains("IMG"))
                                    {
                                        actTrialData.TrialMetaData.TrialID = Int32.Parse(content[3].Substring(content[3].IndexOf("IMG") + 3));
                                    }
                                }
                                else if (content[2].StartsWith("TRIAL_VAR_DATA"))
                                {
                                    actTrialData.TrialMetaData.TrialName = line.Substring(line.IndexOf("TRIAL_VAR_DATA") + 15);
                                }
                                else if (content[2].StartsWith("TIMEOUT"))
                                {
                                    actTrialData.TrialMetaData.Timeout = true;
                                    actTrialData.TrialMetaData.TimeoutTime = Int32.Parse(content[1]);
                                }
                            }
                            else if (line.StartsWith("START"))
                            {
                                string[] content = line.Split('\t');
                                actTrialData.TrialMetaData.StartTime = Int32.Parse(content[1]);
                            }
                            else if (line.StartsWith("EFIX"))
                            {
                                string[] content = line.Split('\t');
                                ASCFixation fixation = new ASCFixation();
                                fixation.StartTime = Int32.Parse(content[0].Substring(9));
                                fixation.EndTime = Int32.Parse(content[1]);
                                fixation.Duration = Int32.Parse(content[2]);
                                fixation.AverageX = (int)Decimal.Round(Decimal.Parse(content[3]));
                                fixation.AverageY = (int)Decimal.Round(Decimal.Parse(content[4]));
                                fixation.AveragePupilSize = Int32.Parse(content[5]);
                                actTrialData.FixationList.Add(fixation);
                            }
                            else if (line.StartsWith("ESACC"))
                            {
                                string[] content = line.Split('\t');
                                ASCSaccation saccation = new ASCSaccation();
                                saccation.StartTime = Int32.Parse(content[0].Substring(8));
                                saccation.EndTime = Int32.Parse(content[1]);
                                saccation.Duration = Int32.Parse(content[2]);
                                saccation.StartX = (int)Decimal.Round(Decimal.Parse(content[3]));
                                saccation.StartY = (int)Decimal.Round(Decimal.Parse(content[4]));
                                saccation.EndX = (int)Decimal.Round(Decimal.Parse(content[5]));
                                saccation.EndY = (int)Decimal.Round(Decimal.Parse(content[6]));
                                saccation.SaccadicAmplitude = Decimal.Parse(content[7]);
                                saccation.PeakVelocity = Int32.Parse(content[8]);
                                actTrialData.SaccationList.Add(saccation);
                            }
                            else if (line.StartsWith("EBLINK"))
                            {
                                string[] content = line.Split('\t');
                                ASCBlink blink = new ASCBlink();
                                blink.StartTime = Int32.Parse(content[0].Substring(9));
                                blink.EndTime = Int32.Parse(content[1]);
                                blink.Duration = Int32.Parse(content[2]);
                                actTrialData.BlinkList.Add(blink);
                            }
                            else if (line.StartsWith("END"))
                            {
                                string[] content = line.Split('\t');
                                actTrialData.TrialMetaData.EndTime = Int32.Parse(content[1]);
                                trialDataList.Add(actTrialData);
                                trial = false;
                            }
                        }
                        catch (Exception ex)
                        {
                            continue;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
  
    }
}
