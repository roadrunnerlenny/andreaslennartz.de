using System;
using System.Collections.Generic;
using System.Text;

namespace ASCLibrary
{
    /// <summary>
    /// Contains all information about a Blink-Event in an ASC-Data File.
    /// </summary>
    [Serializable]
    public class ASCBlink
    {
        private int duration;

        /// <summary>
        /// Gets or sets the duration of the blink in ms.
        /// </summary>
        /// <value>The duration of the blink in ms.</value>
        public int Duration
        {
            get { return duration; }
            set { duration = value; }
        }

        private int startTime;

        /// <summary>
        /// Gets or sets the start time of the blink in ms, relative to the start of the experiment.
        /// </summary>
        /// <value>The start time of the blink in ms, relative to the start of the experiment.</value>
        public int StartTime
        {
            get { return startTime; }
            set { startTime = value; }
        }

        private int endTime;

        /// <summary>
        /// Gets or sets the end time of the blink in ms, relative to the start of the experiment.
        /// </summary>
        /// <value>The end time of the blink in ms, relative to the start of the experiment.</value>
        public int EndTime
        {
            get { return endTime; }
            set { endTime = value; }
        }
    }
}
