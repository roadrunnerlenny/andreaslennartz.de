using System;
using System.Collections.Generic;
using System.Text;

namespace ASCLibrary
{
    /// <summary>
    /// Contains all metadata information of an ASC-File
    /// </summary>
    [Serializable]
    public class ASCTrialMetaData
    {
        private int trialID;

        /// <summary>
        /// Gets or sets the trial ID.
        /// </summary>
        /// <value>The trial ID.</value>
        public int TrialID
        {
            get { return trialID; }
            set { trialID = value; }
        }

        private string trialName;

        /// <summary>
        /// Gets or sets the name of the trial.
        /// </summary>
        /// <value>The name of the trial.</value>
        public string TrialName
        {
            get { return trialName; }
            set { trialName = value; }
        }

        private bool timeout;

        /// <summary>
        /// Gets or sets a value indicating whether this trial <see cref="ASCTrialMetaData"/> timed out.
        /// </summary>
        /// <value><c>true</c> if timed out; otherwise, <c>false</c>.</value>
        public bool Timeout
        {
            get { return timeout; }
            set { timeout = value; }
        }

        private int timeoutTime;

        /// <summary>
        /// Gets or sets the time after which the time out happened.
        /// </summary>
        /// <value>The timeout time.</value>
        public int TimeoutTime
        {
            get { return timeoutTime; }
            set { timeoutTime = value; }
        }

        private int startTime;

        /// <summary>
        /// Gets or sets the start time.
        /// </summary>
        /// <value>The start time.</value>
        public int StartTime
        {
            get { return startTime; }
            set { startTime = value; }
        }

        private int endTime;

        /// <summary>
        /// Gets or sets the end time.
        /// </summary>
        /// <value>The end time.</value>
        public int EndTime
        {
            get { return endTime; }
            set { endTime = value; }
        }

    }
}
