using System;
using System.Collections.Generic;
using System.Text;

namespace ASCLibrary
{
    /// <summary>
    /// Contains the event information of a trial, namely all saccades, fixations, blinks and the trial metadata.
    /// </summary>
    [Serializable]
    public class ASCTrialData
    {
        private List<ASCFixation> fixationList = new List<ASCFixation>();

        /// <summary>
        /// Gets or sets the fixation list.
        /// </summary>
        /// <value>The fixation list.</value>
        public List<ASCFixation> FixationList 
        {
            get { return fixationList; }
            set { fixationList = value; }
        }

        private List<ASCSaccation> saccationList = new List<ASCSaccation>();

        /// <summary>
        /// Gets or sets the saccation list.
        /// </summary>
        /// <value>The saccation list.</value>
        public List<ASCSaccation> SaccationList
        {
            get { return saccationList; }
            set { saccationList = value; }
        }

        private List<ASCBlink> blinkList = new List<ASCBlink>();

        /// <summary>
        /// Gets or sets the blink list.
        /// </summary>
        /// <value>The blink list.</value>
        public List<ASCBlink> BlinkList
        {
          get { return blinkList; }
          set { blinkList = value; }
        }

        private ASCTrialMetaData trialMetaData = new ASCTrialMetaData();

        /// <summary>
        /// Gets or sets the trial meta data.
        /// </summary>
        /// <value>The trial meta data.</value>
        public ASCTrialMetaData TrialMetaData
        {
            get { return trialMetaData; }
            set { trialMetaData = value; }
        }


    }
}
