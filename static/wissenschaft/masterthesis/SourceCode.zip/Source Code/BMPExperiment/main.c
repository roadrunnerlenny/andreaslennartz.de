/*****************************************************************************
 * BMP Experiment 
 * The Experiment engine displays and runs an experiment created by the 
 * Experiment Building tool. While running the experiment, it communicates 
 * with the EyeTracker and takes care of controlling the eyetracker according 
 * to the experiment needs.
 *
 *****************************************************************************/


#include <string.h>
#include <stdlib.h>
#include "picture.h"
#include <sdl_text_support.h>
#ifdef WIN32
#include <w32_dialogs.h>
#endif


int is_eyelink2;   /* set if we are connected to EyeLink II tracker*/
DISPLAYINFO dispinfo; /* display information: size, colors, refresh rate */
/* Name for experiment: goes in task bar, and in EDF file */
char program_name[100] = "Pattern recognition Experiment";
SDL_Surface  *window = NULL;

/*The colors of the target and background for calibration and drift correct */
SDL_Color target_background_color ={255,255,255};
SDL_Color target_foreground_color ={0,0,0};
char *trackerip = NULL; /* use default IP address */



int exit_eyelink()
{
	/* CLEANUP*/
	close_expt_graphics();           /* tell EXPTSPPT to release window */
	close_eyelink_connection();      /* disconnect from tracker */
	return 0;
}

int end_expt(char * our_file_name)
{
	/*END: close, transfer EDF file */
	set_offline_mode(); /* set offline mode so we can transfer file */
	pump_delay(500);    /* delay so tracker is ready */
	/* close data file */
	eyecmd_printf("close_data_file");

	if(break_pressed())
	  return exit_eyelink(); /* don't get file if we aborted experiment */
	if(our_file_name[0])   /* make sure we created a file */
	{
		close_expt_graphics();           /* tell EXPTSPPT to release window */
		receive_data_file(our_file_name, "", 0);
	}
	/* transfer the file, ask for a local name */

	return exit_eyelink();
}


int app_main(char * trackerip, DISPLAYINFO * disp)
{
	UINT16 i, j;
	char our_file_name[260] = "PRFile";
#ifdef WIN32
    edit_dialog(NULL,"Create EDF File", "Enter Tracker EDF file name:", our_file_name,260);
#endif
	if(trackerip)
		set_eyelink_address(trackerip);
	if(open_eyelink_connection(0)) //set to 0 for real mode, 1 for simulation mode
	  return -1;       /* abort if we can't open link*/
	set_offline_mode();
	flush_getkey_queue();/* initialize getkey() system */
	is_eyelink2 = (2 <= eyelink_get_tracker_version(NULL) );



	if(init_expt_graphics(NULL, disp))
	  return exit_eyelink();   /* register window with EXPTSPPT*/
	window = SDL_GetVideoSurface();

	get_display_information(&dispinfo); /* get window size, characteristics*/

	/* NOTE: Camera display does not support 16-color modes
	 NOTE: Picture display examples don't work well with 256-color modes
		   However, all other sample programs should work well.
	*/
	if(dispinfo.palsize==16)      /* 16-color modes not functional */
	{
	  alert_printf("This program cannot use 16-color displays");
	  return exit_eyelink();
	}

	/* 256-color modes: palettes not supported by this example*/
	if(dispinfo.palsize)
	  alert_printf("This program is not optimized for 256-color displays");



	i = SCRWIDTH/60;        /* select best size for calibration target */
	j = SCRWIDTH/300;       /* and focal spot in target  */
	if(j < 2) j = 2;
	set_target_size(i, j);  /* tell DLL the size of target features */
	set_calibration_colors(&target_foreground_color, &target_background_color); /* tell EXPTSPPT the colors*/

	set_cal_sounds("", "", "");
	set_dcorr_sounds("", "off", "off");


	clear_full_screen_window(target_background_color);    // clear screen
	get_new_font("Times Roman", SCRHEIGHT/32, 1);         // select a font
														// Draw text
	graphic_printf(window, target_foreground_color, LEFT, 100, 1*SCRHEIGHT/30,
				 "Pattern Recognition Experiment");
	graphic_printf(window, target_foreground_color, LEFT,100, 6*SCRHEIGHT/30,
				"Instruction: Try to memorize the pattern in the center.");
	graphic_printf(window, target_foreground_color, LEFT,100, 7*SCRHEIGHT/30,
				 "Wait a few seconds, and search for the pattern. ");
	graphic_printf(window, target_foreground_color, LEFT,100, 8*SCRHEIGHT/30,
				 "When you think you found the pattern, ");
	graphic_printf(window, target_foreground_color, LEFT,100, 9*SCRHEIGHT/30,
				 "keep looking at it and press the button.");
	graphic_printf(window, target_foreground_color, LEFT,100, 14*SCRHEIGHT/30,
				 "Press ESCAPE to start.");
	SDL_Flip(window);

	while (1) {
	  if (escape_pressed()) break;
	}
	while(getkey());


	if(our_file_name[0])    /* If file name set, open it */
	{
	  /* add extension */
	  if(!strstr(our_file_name, ".")) strcat(our_file_name, ".EDF");
	  i = open_data_file(our_file_name); /* open file */
	  if(i!=0)                           /* check for error */
		{
		  alert_printf("Cannot create EDF file '%s'", our_file_name);
		  return exit_eyelink();
		}                                /* add title to preamble */
	  eyecmd_printf("add_file_preamble_text 'RECORDED BY %s' ", program_name);
	}

	/* Now configure tracker for display resolution */
	/* Set display resolution */
	eyecmd_printf("screen_pixel_coords = %ld %ld %ld %ld",
				 dispinfo.left, dispinfo.top, dispinfo.right, dispinfo.bottom);
	/* Setup calibration type */
	eyecmd_printf("calibration_type = HV9");

	/* Add resolution to EDF file */
	eyemsg_printf("DISPLAY_COORDS %ld %ld %ld %ld",
				 dispinfo.left, dispinfo.top, dispinfo.right, dispinfo.bottom);
	if(dispinfo.refresh>40)
	eyemsg_printf("FRAMERATE %1.2f Hz.", dispinfo.refresh);

	/* SET UP TRACKER CONFIGURATION */
	/* set parser saccade thresholds (conservative settings) */
	if(is_eyelink2)
	{
	  /* 0 = standard sensitivity */
	  eyecmd_printf("select_parser_configuration 0");
	}
	else
	{
	  eyecmd_printf("saccade_velocity_threshold = 35");
	  eyecmd_printf("saccade_acceleration_threshold = 9500");
	}
	/* set EDF file contents */
	eyecmd_printf("file_event_filter = LEFT,RIGHT,FIXATION,SACCADE,BLINK,MESSAGE,BUTTON");
	eyecmd_printf("file_sample_data  = LEFT,RIGHT,GAZE,AREA,GAZERES,STATUS");
	/* set link data (used for gaze cursor) */
	eyecmd_printf("link_event_filter = LEFT,RIGHT,FIXATION,SACCADE,BLINK,BUTTON");
	eyecmd_printf("link_sample_data  = LEFT,RIGHT,GAZE,GAZERES,AREA,STATUS");
	/* Program button #5 for use in drift correction */
	eyecmd_printf("button_function 5 'accept_target_fixation'");

	/* make sure we're still alive */
	if(!eyelink_is_connected() || break_pressed())
	  return end_expt(our_file_name);

	/*
	   RUN THE EXPERIMENTAL TRIALS (code depends on type of experiment)
	   Calling run_trials() performs a calibration followed by trials
	   This is equivalent to one block of an experiment
	   It will return ABORT_EXPT if the program should exit
	*/
	i = run_trials();
	return end_expt(our_file_name);
}


void clear_full_screen_window(SDL_Color c)
{
	SDL_FillRect(window, NULL, SDL_MapRGB(window->format, c.r,  c.g, c.b));
	SDL_Flip(window);
	SDL_FillRect(window, NULL, SDL_MapRGB(window->format, c.r,  c.g, c.b));

}

int parseArgs(int argc, char **argv, char **trackerip, DISPLAYINFO *disp )
{
	int i =0;
	int displayset =0;
	memset(disp,0,sizeof(DISPLAYINFO));
	for( i =1; i < argc; i++)
	{
		if(_stricmp(argv[i],"-tracker") ==0 && argv[i+1])
		{
			*trackerip = argv[i+1];
			i++;
		}
		else if(strcmp(argv[i],"-width") ==0 && argv[i+1])
		{
			i++;
			disp->width = atoi(argv[i]);
			displayset = 1;
		}
		else if(_stricmp(argv[i],"-height") ==0 && argv[i+1])
		{
			i++;
			disp->height = atoi(argv[i]);
			displayset = 1;
		}
		else if(_stricmp(argv[i],"-bpp") ==0 && argv[i+1])
		{
			i++;
			disp->bits = atoi(argv[i]);
		}
		else if(_stricmp(argv[i],"-refresh") ==0 && argv[i+1])
		{
			i++;
			disp->refresh = (float)atoi(argv[i]);
		}
		else
		{
			printf("%d \n", i);
			printf("usage %s \n", argv[0]);
			printf("\t options: \n");
			printf("\t[-tracker <tracker address > ] eg. 100.1.1.1 \n");
			printf("\t[-width   <screen width>]  eg. 640, 800, 1280\n");
			printf("\t[-height  <screen height>] eg. 480, 600, 1024\n");
			printf("\t[-bpp     <color depth>]   eg. 16,24,32\n");
			printf("\t[-refresh refresh value]   eg. 60, 85, 85 \n");
			return 1;
		}

	}
	if(displayset && !disp->width && !disp->height)
		return 1;
	return 0;
}
#if  defined(WIN32) && !defined(_CONSOLE)
/* WinMain - Windows calls this to execute application */
int PASCAL WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	app_main(NULL,NULL);/* call our real program */
	return 0;
}
#else
/* non windows application or win32 console application. */
int main(int argc, char ** argv)
{
	DISPLAYINFO disp;
	char *trackerip = NULL;
	int rv = parseArgs(argc,argv, &trackerip, &disp);
	if(rv) return rv;

	if(disp.width)
		app_main(trackerip, &disp);/* call our real program */
	else
		app_main(trackerip, NULL);/* call our real program - no display parameters set*/
	return 0;
}
#endif