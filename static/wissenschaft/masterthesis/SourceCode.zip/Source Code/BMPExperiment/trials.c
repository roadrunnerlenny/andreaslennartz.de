/*****************************************************************************
 * BMP Experiment 
 * The Experiment engine displays and runs an experiment created by the 
 * Experiment Building tool. While running the experiment, it communicates 
 * with the EyeTracker and takes care of controlling the eyetracker according 
 * to the experiment needs.
 *
 *****************************************************************************/

#include "picture.h"
#include <sdl_text_support.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_rotozoom.h>
#include <stdlib.h>
#include <stdio.h>




int NTRIALS = 0;



SDL_Surface * image_file_bitmap(char *fname, int keepsize, int dx, int dy,
								int bgcolor)
{
  SDL_Surface *image = NULL;

  image = IMG_Load(fname);
  if(!image)
  {
	 printf( "Error opening  Image %s. %s \n", 
		 fname, SDL_GetError());
	 return NULL;
  }
  if(keepsize)
	return image;

  if(!dx || !dy) /* dx or dy is 0 - make it to full screen size */
  {
	  SDL_Surface * mainsurface = SDL_GetVideoSurface();
	  dx = mainsurface->w;
	  dy = mainsurface->h;
  }

  if(dx && dy && dx != image->w && dy != image->h)
  {
	  double zx = (double)dx/(double)image->w;
	  double zy = (double)dy/(double)image->h;
	  SDL_Surface *zoomed = zoomSurface(image,zx,zy,0);

	  if(zoomed)
	  {
		  SDL_FreeSurface(image);
		  return zoomed;
	  }
  }
  return image;

}

/* 
	Create foreground and background bitmaps of picture
*/
SDL_Surface * create_image_bitmap(char *imgname)
{ 

  set_calibration_colors(&target_foreground_color, &target_background_color); /* tell EXPTSPPT the colors */
  clear_full_screen_window(target_background_color);

  eyecmd_printf("clear_screen 0");         /* clear EyeLink display */
  eyecmd_printf("draw_box %d %d %d %d 15", /* Box around fixation point */
           SCRWIDTH/2-16, SCRHEIGHT/2-16, SCRWIDTH/2+16, SCRHEIGHT/2+16);

  /* NOTE:*** THE FOLLOWING TEXT SHOULD NOT APPEAR IN A REAL EXPERIMENT!!!!***/
  //get_new_font("Arial", 24, 1);
  //graphic_printf(window, target_foreground_color, CENTER, SCRWIDTH/2, SCRHEIGHT/2, 
	//				"Loading image...");
  //Flip(window);

  /* normal image */
  eyemsg_printf("IMGLOAD FILL %s",imgname);
  return image_file_bitmap(imgname,0,SCRWIDTH,SCRHEIGHT,0);

}

/***************************TRIAL SETUP AND RUN*******************************/
/* 
	FOR EACH TRIAL:
		- set title, TRIALID
		- Create bitmaps and EyeLink display graphics
		- Check for errors in creating bitmaps
		- Run the trial recording loop
		- Delete bitmaps
		- Return any error code
 */

/* 
	Given trial number, execute trials
	Returns trial result code
*/
int do_picture_trial(int num)
{
  SDL_Surface * bitmap;
  SDL_Surface * pattern;
  int i;
  SDL_Rect rect;
  int concol, concolr,concolg,concolb = 0;
  int same_screen = 0;
  long max_duration = 0;
  int pattern_disp_time = 0;

  FILE *inputFilePtr = NULL;

  char line[255] = "";
  char imgname[60] = "";
  char pattername[60] = "";
  char txtname[60] = "";
  char imgname_st[60] = "images/trial_";
  char pattername_st[60] = "images/trialPattern_";
  char dataname_st[60] = "data/trialData_";
  char imgname_en[10] = ".bmp";
  char txtname_en[10] = ".txt";
  char trialname[255];

  rect.x =0;rect.y=0,rect.h=0,rect.w=0;

  sprintf(imgname,"%s%d%s",imgname_st,num,imgname_en);
  sprintf(pattername,"%s%d%s",pattername_st,num,imgname_en);
  sprintf(txtname,"%s%d%s",dataname_st,num,txtname_en);

  /* reads the data from file */
  inputFilePtr = fopen(txtname, "r");
  if (inputFilePtr != NULL) {
	  fgets(trialname,255,inputFilePtr);
	  same_screen = atoi(fgets(line,255,inputFilePtr));
	  pattern_disp_time = atoi(fgets(line,255,inputFilePtr));
	  max_duration = atoi(fgets(line,255,inputFilePtr));
	  rect.x = atoi(fgets(line,255,inputFilePtr));
	  rect.y = atoi(fgets(line,255,inputFilePtr));
	  rect.w = atoi(fgets(line,255,inputFilePtr));
	  rect.h = atoi(fgets(line,255,inputFilePtr));
	  concolr = atoi(fgets(line,255,inputFilePtr));
  	  concolg = atoi(fgets(line,255,inputFilePtr));
	  concolb = atoi(fgets(line,255,inputFilePtr));
  }

  fclose(inputFilePtr);

  /* This supplies the title at the bottom of the eyetracker display  */
  eyecmd_printf("record_status_message 'Imagename %s, TRIAL NR %d/%d, Trial Block name: %s' ", imgname,num, NTRIALS, trialname);

  /* Always send a TRIALID message before starting to record. 
     It should contain trial condition data required for analysis.
   */
  eyemsg_printf("TRIALID IMG%d of %d, Imagename: %s, Datafile: %s", num, NTRIALS, imgname, txtname);

  /* TRIAL_VAR_DATA message is recorded for EyeLink Data Viewer analysis
     It specifies the list of trial variables value for the trial 
     This must be specified within the scope of an individual trial (i.e., after 
	 "TRIALID" and before "TRIAL_RESULT") 
  */
  eyemsg_printf("TRIAL_VAR_DATA %s", trialname);	

  set_offline_mode();/* Must be offline to draw to EyeLink screen */

  if (!same_screen) {
	    pattern = create_image_bitmap(pattername); 
	    if(!pattern)
	    {
			alert_printf("ERROR: could not create pattern %d", num);
			return SKIP_TRIAL;		
		}
  }


  /*NOTE:** THE FOLLOWING TEXT SHOULD NOT APPEAR IN A REAL EXPERIMENT!!!! **/
  //clear_full_screen_window(target_background_color);
  //get_new_font("Arial", 24, 1);
  //graphic_printf(window,target_foreground_color, CENTER, SCRWIDTH/2, SCRHEIGHT/2, "Sending image to EyeLink...%d %d %d %d %s",rect.x,rect.y,rect.w,rect.h,txtname);
  //Flip(window);
  
  bitmap = create_image_bitmap(imgname); 
  if(!bitmap)
    {
      alert_printf("ERROR: could not create image %d", num);
      return SKIP_TRIAL;
    }
  concol = SDL_MapRGB(bitmap->format, concolr,concolg,concolb);
  
  /* Transfer bitmap to tracker as backdrop for gaze cursors */
  bitmap_to_backdrop(bitmap, 0, 0, 0, 0,0, 0, BX_MAXCONTRAST|(is_eyelink2?0:BX_GRAYSCALE));  
  
  /* record the trial */
  i = bitmap_recording_trial(bitmap,pattern, rect, max_duration*1000,  pattern_disp_time, concol); //add pattern

  SDL_FreeSurface(bitmap);
  
  //exit(0);
  return i;
}

/******************************* TRIAL LOOP ********************************/


/*
	This code sequences trials within a block 
	It calls run_trial() to execute a trial, 
	then interprets result code. 
	It places a result message in the EDF file 
	This example allows trials to be repeated 
	from the tracker ABORT menu. 

*/
int run_trials(void)
{
  FILE *inputFilePtr = NULL;
  int i;
  int trial;
  char line[255] = "";
  int disX,disY = 0;
  
  inputFilePtr = fopen("config.txt", "r");
  if (inputFilePtr != NULL) {
	  fgets(line,255,inputFilePtr);
	  disX = atoi(line);
	  fgets(line,255,inputFilePtr);
	  disY = atoi(line);
	  fgets(line,255,inputFilePtr);
	  NTRIALS = atoi(line);
  }
  

  SETCOLOR(target_background_color,255,255,255);   /* This should match the display  */
  set_calibration_colors(&target_foreground_color, &target_background_color); 
  /*	TRIAL_VAR_LABELS message is recorded for EyeLink Data Viewer analysisIt specifies the list of trial variables for the trial 
		This should be written once only and put before the recording of individual trials
  */
  eyemsg_printf("TRIAL_VAR_LABELS TYPE");

  /* PERFORM CAMERA SETUP, CALIBRATION */
  do_tracker_setup();

  /* loop through trials */
  for(trial=1;trial<=NTRIALS;trial++)
    {
	  /* drop out if link closed */
      if(eyelink_is_connected()==0 || break_pressed())    
		return ABORT_EXPT;
	
				/* RUN THE TRIAL */
      i = do_picture_trial(trial);
      end_realtime_mode();

      switch(i)         	/* REPORT ANY ERRORS */
		{
		  case ABORT_EXPT:/* handle experiment abort or disconnect */
			eyemsg_printf("EXPERIMENT ABORTED");
			return ABORT_EXPT;
		  case REPEAT_TRIAL:	  /* trial restart requested */
			eyemsg_printf("TRIAL REPEATED");
			trial--;
			break;
		  case SKIP_TRIAL:	  /* skip trial */
			eyemsg_printf("TRIAL ABORTED");
			break;
		  case TRIAL_OK:          // successful trial
			eyemsg_printf("TRIAL OK");
			break;
		  default:                // other error code
			eyemsg_printf("TRIAL ERROR");
			break;
		}
    }  // END OF TRIAL LOOP
  return 0;
}

