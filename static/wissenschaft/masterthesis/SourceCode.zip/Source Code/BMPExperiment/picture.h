/*****************************************************************************
 * BMP Experiment 
 * The Experiment engine displays and runs an experiment created by the 
 * Experiment Building tool. While running the experiment, it communicates 
 * with the EyeTracker and takes care of controlling the eyetracker according 
 * to the experiment needs.
 *
 *****************************************************************************/

#ifndef __SR_RESEARCH__PICTURE_H__
#define __SR_RESEARCH__PICTURE_H__

#include <sdl_expt.h>


extern DISPLAYINFO dispinfo;  /* display information: size, colors, refresh rate*/
extern SDL_Surface *window;   /* SDL surface for drawing */
extern SDL_Color target_background_color;   /* SDL color for the background */
extern SDL_Color target_foreground_color;   /* SDL color for the foreground drawing (text, calibration target, etc)*/
extern int is_eyelink2;		  /* set if we are connected to EyeLink II tracker*/

int run_trials(void);   /* This code sequences trials within a block. */
void clear_full_screen_window(SDL_Color c);  /* Clear the window with a specific color */

/* Run a single trial, recording to EDF file only */
int simple_recording_trial(char *text, UINT32 time_limit);


/* Run a single bitmap trial, recording to EDF file only */
int bitmap_recording_trial(SDL_Surface *gbm, SDL_Surface *pattern, SDL_Rect rect, UINT32 time_limit, UINT32 pattern_disp_time, UINT32 concol);

/* Helper function: Draws a rectangle / draws the conclusion rectangle */
void draw_rect(SDL_Rect rect, SDL_Surface *bitmap, int color);
void draw_concl_rect(SDL_Rect rect, SDL_Surface *bitmap, int color, int offset);


/* convenient macros */
#define SETCOLOR(x,red,green,blue) x.r =red; x.g = green; x.b =blue; 

/* Border thickness of the conclusion rectangle(s) */ 
#define BORDERSIZE 2
/* Number of conclusion rectangles */ 
#define NUMBER 5
/* 5 sec will the conclusion of the trial be displayed */
#define CONCL_DISP_TIME 5000 

#ifndef WIN32
#define _stricmp strcasecmp
#endif
#endif
