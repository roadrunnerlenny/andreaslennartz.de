/**********************************************************************************
 * EYELINK COMPATIBILITY EXPT SUPPORT      (c) 1996, 2003 by SR Research          *
 *     8 September 2003 by Suganthan Subramaniam       For non-commercial use only*
 * Header file for standard functions                                             *
 * This module is for user applications   Use is granted for non-commercial       *
 * applications by Eyelink licencees only                                         *
 *                                                                                *
 *                                                                                *
 ******************************************* WARNING ******************************
 *                                                                                *
 * UNDER NO CIRCUMSTANCES SHOULD PARTS OF THESE FILES BE COPIED OR COMBINED.      *
 * This will make your code impossible to upgrade to new releases in the future,  *
 * and SR Research will not give tech support for reorganized code.               *
 *                                                                                *
 * This file should not be modified. If you must modify it, copy the entire file  *
 * with a new name, and change the the new file.                                  *
 *                                                                                *
 **********************************************************************************/

#ifndef W32EXPTSPPTINCL
#define W32EXPTSPPTINCL
#include "gdi_expt.h"
#endif