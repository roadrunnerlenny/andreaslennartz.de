package Client;
/**
 * Client:
 * Program which manages the mainfunctions of a simple client-programM
 *
 * ClientMain:
 * The class generates two instances (UserInput, ServerCom). It
 * coordinates them as threads.
 *
 * Authors:  Andreas Lennartz
 * Deploymentperiod: October 2004 till January 2005
 */

import java.net.*;


public class ClientMain {
  // variables of the class
  Socket conToServ;
  ClientGui gui;


  public ClientMain() {


    // instantiate Gui
    gui = new ClientGui(this);
    gui.setSize(685, 375);
    gui.show();

  }// end of constructor

  // creation of socket
  public boolean startService(String ip) {
    try {
      conToServ = new Socket (ip, 4711);
    }
    catch (Exception e) {
      System.out.print ("\nServer not found!\n");
      e.printStackTrace();
      return false;
    }

    // instantiate objects for the control
    ServerCom server = new ServerCom(conToServ, this);
    gui.setSocket(conToServ);

    // construct threads
    Thread thr_serv = new Thread (server);
    thr_serv.start();

    return true;
  }

  public static void main(String[] args) {
    ClientMain client_Main1 = new ClientMain();
  }

  // text which is displayed
  public void display(String string) {
    // queries of #serverinfo -> Message from Server
    // #serverinfo roomname
    if ( string.split(" ")[0].equalsIgnoreCase("#serverinfo")) {
      // Server teilt etwas mit
      /*(#gesendet)
        Antwort vom Server
       (#create "Raumname")
       (#enter)
       nix
       (#rauminfo)
       #serverinfo raum "raum"
       (#raumliste)
       #serverinfo raumliste "..."
       -> Raeume mit leerzeichen getrennt
       ohne Anfrage:
       #serverinfo raumliste "..."
       -> Raeume mit leerzeichen getrennt
       */

      // shows the current room
      if (string.split(" ")[1].equalsIgnoreCase("room")) {
        gui.label1.setText("Conversation in room: "+string.split(" ")[2]);
      }
      // getting the roomlist
      if (string.split(" ")[1].equalsIgnoreCase("roomlist")) {
        actRoomlist(string);
      }
      // actualising the Userlist
      if (string.split(" ")[1].equalsIgnoreCase("userlist")) {
        actUserlist(string);
      }
      if (string.split(" ")[1].equalsIgnoreCase("change")) {
        gui.pOut.println("#roominfo");
      }

    } // orders from server end here
    else
    {
      gui.setDisplay(string);
    }
  }

  private void actUserlist(String string) {
    gui.addUserlist("#delete");
    try
    {
      for (int i = 2; ; i++) {
        gui.addUserlist(string.split(" ")[i]);
      }
    }
    catch (Exception ex)
    {
      // Array out of Bounds
    }
  }

  private void actRoomlist(String string) {
    // Roomlist from position [2] to the end...
    gui.addRoomlist("#delete");
    try
    {
      for (int i = 2; ; i++) {
        gui.addRoomlist(string.split(" ")[i]);
      }
    }
    catch (Exception ex)
    {
      // Array out of Bounds
    }
  }
}// End of the class
