package Client;
/**
 * ServerCom:
 * This class manages the communication of the client with the
 * server.
 */

import java.io.*;
import java.net.*;

public class ServerCom implements Runnable{
  // variables of the class
  ClientMain mother;
  Socket serv_sock;
  String str;
  BufferedReader buffRead;

  public ServerCom(Socket sock, ClientMain mother) {
    serv_sock = sock;
    this.mother = mother;

    // get inputstream of socket
    try {
      buffRead = new BufferedReader(new InputStreamReader(serv_sock.
          getInputStream()));
    }
    catch (IOException ex) {
      mother.display("\nWasn�t able to find InputStream of Server!");
      mother.display(ex.getMessage());
    }
  }

  public void run() {
    while (true) {
      try {
        Thread.sleep (100*2);
      }
      catch (InterruptedException ex) {
      }
      // Chat:
      communicate();
      }
    }// end of while

  private void communicate() {
    // get and display answers from the server
    try {
      str = buffRead.readLine();
      if (str == null){
        mother.display("\nServer is down. End of program.");
        System.exit(0);
      }
      mother.display ( str);
    }
    catch (IOException ex) {
    }
  }
}
