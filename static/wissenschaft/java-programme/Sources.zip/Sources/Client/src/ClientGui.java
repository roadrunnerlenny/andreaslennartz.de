package Client;
/**
 * ClientMain:
 * This class creates the user interface for the client. It receives the inputs
 * from the user and hands over them to the class ServerCom.
 *
 */

import javax.swing.*;
import java.awt.*;
import java.net.*;
import java.io.*;
import java.awt.event.*;




public class ClientGui extends JFrame {
  Socket serv_sock;
  PrintStream pOut;
  String str;
  ClientMain mother;

  JButton btn_Send = new JButton();
  TextArea textArea_Receive = new TextArea();
  JTextField jTextField_Send = new JTextField();
  List list1 = new List();
  JButton enterRoomButton = new JButton();
  JTextField jTextField_IP = new JTextField();
  JButton jButton_Connect = new JButton();
  JTextField jTextField_CreateRoom = new JTextField();
  JButton jButton_CreateRoom = new JButton();
  List list2 = new List();
  Label label1 = new Label();
  Label label2 = new Label();
  Label label3 = new Label();

  public ClientGui(ClientMain mother) {
    // assume socket
    this.mother = mother;

    try {
      jbInit();
    }
    catch (Exception e) {
      e.printStackTrace();
    }

    setHandling (false);
    // set focus to input
    jTextField_Send.requestFocus();
  }


  private void setHandling (boolean zustand)
  {
    enterRoomButton.setEnabled(zustand);
    jButton_Connect.setEnabled(!zustand);
    jButton_CreateRoom.setEnabled(zustand);
    btn_Send.setEnabled(zustand);
  }

  public void setSocket(Socket serv_sock)
  {
    this.serv_sock = serv_sock;
    // get OutputStream of the socket
    try {
      pOut = new PrintStream(serv_sock.getOutputStream());
    }
    catch (IOException ex) {
      System.out.print("\nIt wasn�t possible to find " +
      	"Outputstream of the server!\n");
      textArea_Receive.append(
          "\nIt wasn�t possible to find Outputstream " +
          "of the server!\n");
      ex.printStackTrace();
      return;
    }
    setHandling(true);
  }

  // Creation of the user interface
  private void jbInit() throws Exception {
    this.getContentPane().setLayout(null);
    btn_Send.setBounds(new Rectangle(16, 280, 366, 29));
    btn_Send.setActionCommand("Send");
    btn_Send.setText("Send");
    btn_Send.addActionListener(new ClientGui_btn_Send_actionAdapter(this));
    this.addWindowListener(new ClientGui_this_windowAdapter(this));
    textArea_Receive.setEditable(false);
    textArea_Receive.setEnabled(true);
    textArea_Receive.setText("");
    textArea_Receive.setBounds(new Rectangle(17, 31, 367, 218));
    jTextField_Send.setText("anonymous");
    jTextField_Send.setBounds(new Rectangle(17, 253, 365, 24));
    jTextField_Send.addKeyListener(new ClientGui_jTextField_Send_keyAdapter(this));
    list1.setBounds(new Rectangle(393, 32, 142, 208));
    enterRoomButton.setBounds(new Rectangle(393, 242, 141, 26));
    enterRoomButton.setToolTipText("");
    enterRoomButton.setText("Enter room");
    enterRoomButton.addActionListener(new
                                      ClientGui_enterRoomButton_actionAdapter(this));
    jTextField_IP.setText("localhost");
    jTextField_IP.setBounds(new Rectangle(452, 317, 124, 24));
    jButton_Connect.setBounds(new Rectangle(580, 317, 89, 23));
    jButton_Connect.setText("connect");
    jButton_Connect.addActionListener(new ClientGui_jButton_Connect_actionAdapter(this));
    this.setTitle("Chat Client");
    jTextField_CreateRoom.setText("room");
    jTextField_CreateRoom.setBounds(new Rectangle(392, 270, 76, 22));
    jButton_CreateRoom.setBounds(new Rectangle(471, 270, 132, 24));
    jButton_CreateRoom.setText("Create room");
    jButton_CreateRoom.addActionListener(new ClientGui_jButton_CreateRoom_actionAdapter(this));
    list2.setBounds(new Rectangle(539, 31, 133, 208));
    label1.setText("Conversation");
    label1.setBounds(new Rectangle(19, 12, 363, 20));
    label2.setText("Available Rooms");
    label2.setBounds(new Rectangle(393, 11, 139, 20));
    label3.setText("Members in this room");
    label3.setBounds(new Rectangle(537, 12, 135, 17));
    this.getContentPane().add(jTextField_Send, null);
    this.getContentPane().add(textArea_Receive, null);
    this.getContentPane().add(list1, null);
    this.getContentPane().add(list2, null);
    this.getContentPane().add(btn_Send, null);
    this.getContentPane().add(jTextField_CreateRoom, null);
    this.getContentPane().add(jButton_CreateRoom, null);
    this.getContentPane().add(label2, null);
    this.getContentPane().add(label3, null);
    this.getContentPane().add(jTextField_IP, null);
    this.getContentPane().add(jButton_Connect, null);
    this.getContentPane().add(enterRoomButton, null);
    this.getContentPane().add(label1, null);
	UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		SwingUtilities.updateComponentTreeUI(this);
  }

  void btn_Send_actionPerformed(ActionEvent e) {
    str = jTextField_Send.getText();
    // delete input
    jTextField_Send.setText("");
    jTextField_Send.setCaretPosition(0);

    // send
    pOut.println(str);
    jTextField_Send.requestFocus();
  }

  public void setDisplay(String string) {
    textArea_Receive.append("\n" + string);

    // Focus auf Eingabe legen
    jTextField_Send.requestFocus();
  }

  void this_windowClosing(WindowEvent e) {
    // TO DO: Port schliessen...
    System.exit(1);
  }

  void jTextField_Send_keyPressed(KeyEvent e) {
    if (e.getKeyChar() == '\n') {
      btn_Send_actionPerformed(null);
    }
  }

  void enterRoomButton_actionPerformed(ActionEvent e) {
    String newRoom = list1.getSelectedItem();
    pOut.println("#enter "+newRoom);
    pOut.println("#userlist "+newRoom);
  }

  // actualise roomlist
  public void addRoomlist(String string) {
    if (string.equals("#delete"))
      list1.clear();
    else {
      list1.addItem(string);
    }
  }

  // actualise userlist
  public void addUserlist(String string) {
    if (string.equals("#delete"))
      list2.removeAll();
    else {
      list2.add(string);
    }
  }


  void jButton_Connect_actionPerformed(ActionEvent e) {
    boolean erfolg = mother.startService(jTextField_IP.getText());
    if (erfolg) jButton_Connect.setEnabled(false);
  }

  void jButton_CreateRoom_actionPerformed(ActionEvent e) {
    String tmpStr = "";
    tmpStr = "#create " + jTextField_CreateRoom.getText();
    pOut.println(tmpStr);

  }
}


/******************************************************************************
 *                         ACTIONLISTENER-Klassen
 *****************************************************************************/



class ClientGui_btn_Send_actionAdapter implements java.awt.event.ActionListener {
  ClientGui adaptee;

  ClientGui_btn_Send_actionAdapter(ClientGui adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.btn_Send_actionPerformed(e);
  }
}


class ClientGui_this_windowAdapter extends java.awt.event.WindowAdapter {
  ClientGui adaptee;

  ClientGui_this_windowAdapter(ClientGui adaptee) {
    this.adaptee = adaptee;
  }
  public void windowClosing(WindowEvent e) {
    adaptee.this_windowClosing(e);
  }
}

class ClientGui_jTextField_Send_keyAdapter extends java.awt.event.KeyAdapter {
  ClientGui adaptee;

  ClientGui_jTextField_Send_keyAdapter(ClientGui adaptee) {
    this.adaptee = adaptee;
  }
  public void keyPressed(KeyEvent e) {
    adaptee.jTextField_Send_keyPressed(e);
  }
}

class ClientGui_enterRoomButton_actionAdapter implements java.awt.event.ActionListener {
  ClientGui adaptee;

  ClientGui_enterRoomButton_actionAdapter(ClientGui adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.enterRoomButton_actionPerformed(e);
  }
}



class ClientGui_jButton_Connect_actionAdapter implements java.awt.event.ActionListener {
  ClientGui adaptee;

  ClientGui_jButton_Connect_actionAdapter(ClientGui adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton_Connect_actionPerformed(e);
  }
}

class ClientGui_jButton_CreateRoom_actionAdapter implements java.awt.event.ActionListener {
  ClientGui adaptee;

  ClientGui_jButton_CreateRoom_actionAdapter(ClientGui adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton_CreateRoom_actionPerformed(e);
  }
}
