package Server;
/**
 * This class creates the user interface for the server. It
 * displays the servers actions (serverstart, logon of a
 * client...)
 *
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class ServerMainGUI extends JFrame {
  TextArea Console = new TextArea();

  public ServerMainGUI() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }

  }
  private void jbInit() throws Exception {
    Console.setText("Welcome to the chatserver Andreas Lennartz");
    Console.setBounds(new Rectangle(23, 26, 494, 308));
    this.getContentPane().setLayout(null);
    this.setTitle("ServerConsole");
    this.addWindowListener(new ServerMainGUI_this_windowAdapter(this));
    this.getContentPane().add(Console, null);
    this.setBounds(150,150,550,390);
    UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
    SwingUtilities.updateComponentTreeUI(this);
  }

  public void addToConsole(String text)
  {
    Console.append(text);
    Console.validate();
  }

  void this_windowClosing(WindowEvent e) {
    // shuts down the window
    System.exit(0);
  }


}

class ServerMainGUI_this_windowAdapter
    extends java.awt.event.WindowAdapter {
  ServerMainGUI adaptee;

  ServerMainGUI_this_windowAdapter(ServerMainGUI adaptee) {
    this.adaptee = adaptee;
  }
  public void windowClosing(WindowEvent e) {
    adaptee.this_windowClosing(e);
  }
}
