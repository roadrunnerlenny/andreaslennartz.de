package Server;

/**
 * ClientSession:
 * This class is responsible for the logon of a client
 * on a server (connection, set of username, ...). It
 * receives the messages from the client and sends
 * them to the server.
 *
 */


import java.net.*;
import java.io.*;

public class ClientSession {

  private PrintStream pout;
  private Thread thr_listen;
  private Socket socket;
  public ServerMain serverMain;
  private boolean firstConnectDone = false;
  private String userName;
  private String room;

  public ClientSession(Socket socket, ServerMain serverHaupt) {
    try {
      this.socket = socket;
      this.serverMain = serverHaupt;

      // instantiate objects for the control
      ListenClient listenClient = new ListenClient(this.socket, this);

      // create threads
      thr_listen = new Thread(listenClient);
      thr_listen.start();

      // create stream for sending messages
      pout = new PrintStream(this.socket.getOutputStream());

      // Logon
      sendMessages ("Welcome. Please enter a name: ");
    }
    catch (IOException ex) {
      serverHaupt.display("\nClient not found.");
      ex.printStackTrace();
    }
    catch (Exception e)
    {
      serverHaupt.display("\nunknown error:"+e);
    }
  }

  public void sendMessages(String message)
  {
     pout.println(message);
  }

  public void recieveMessages(String message)
  {
    if (firstConnectDone)
    {
      String order = "";
      String annex = "";

      try
      {
        if ( (message.split(" "))[0] != null)
          order = (message.split(" "))[0];
        if ( (message.split(" "))[1] != null)
          annex = (message.split(" "))[1];
      }
      catch (ArrayIndexOutOfBoundsException aioobex)
      {
        // no need to catch
        ;
      }

      if (order.equalsIgnoreCase("#enter"))
      {
        if (serverMain.enterRoom(annex,this)) {
          this.room = annex;
          this.sendMessages("Server: Room entered: "+annex);
          this.sendMessages("#serverinfo userlist "+serverMain.returnUserlist(annex));
          serverMain.sendToAll("#serverinfo change");
        }
        else
        {
          this.sendMessages("Server: Wasn�t able to enter room "+annex+".");
         }
      }
      else if (order.equalsIgnoreCase("#roominfo")) {
        this.sendMessages("#serverinfo room "+this.room);
        this.sendMessages("#serverinfo userlist "+serverMain.returnUserlist(this.room));
      }
      else if (order.equalsIgnoreCase("#create")) {
        if (serverMain.createRoom(annex)) {
          this.sendMessages("Server: Room "+annex+" created.");
         }
      }
      else if (order.equalsIgnoreCase("#roomlist")) {
        this.sendMessages("#serverinfo roomlist "+serverMain.returnRoomlist());
      }
      else if (order.equalsIgnoreCase("#userlist")) {
        this.sendMessages("#serverinfo userlist "+serverMain.returnUserlist(annex));
      }
      else
      {
        serverMain.sendToRoom(room,userName+": "+message);
      }
    }
    else
    {
      // set username
      userName = message;
      firstConnectDone = true;
      // register username on the server
      room = "default";
      serverMain.registerUser(this);
      this.sendMessages("Welcome "+userName+"! you are in roum "+this.room);
      this.sendMessages("#serverinfo roomlist "+serverMain.returnRoomlist());
      this.sendMessages("#serverinfo userlist "+serverMain.returnUserlist(room));
      serverMain.sendToAll("#serverinfo change");
    }
  }

  public void shutDownClient()
  {
    try
    {
      serverMain.deleteClient(this);
      serverMain.sendToAll("#serverinfo change");
      socket.close();
      thr_listen.stop();
      thr_listen.destroy();
    }
    catch (Exception e)
    {
      serverMain.display("\nunknown error:" + e.toString());
    }
  }

  public String getUserName()
  {
    return userName;
  }

  public String getRoom()
  {
    return room;
  }



}
