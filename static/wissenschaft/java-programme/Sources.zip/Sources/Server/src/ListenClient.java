package Server;
/**
 * ListenClient:
 * This class receives messages from the client in order
 * to display them on the serverwindow.
 *
 */

import java.io.*;
import java.net.*;

public class ListenClient implements Runnable{

  // Variables of a class
  private Socket listen_sock;
  private String str;
  private BufferedReader buffRead;
  private ClientSession mother;

  public ListenClient(Socket sock,ClientSession mother) {

    try {
      this.mother = mother;

      listen_sock = sock;
      // get inputstream of the socket
      buffRead = new BufferedReader(new InputStreamReader(listen_sock.getInputStream()));
      mother.serverMain.display("\nCreate new client:"+sock.toString());
    }
    catch (IOException ex) {
      mother.serverMain.display("\nClient is dead:"+sock.toString());
      mother.shutDownClient();
    }
    catch (Exception ex)
    {
      mother.serverMain.display("\nunknown error:"+ex.toString());
    }
  }

  public void run() {
    while (true) {
      try
      {
        Thread.sleep (100*2);
      }
      catch (InterruptedException ex) {
        mother.serverMain.display("\nunknown error:"+ex.toString());
      }
      // chat
      communicate();
      }
    }// end of while

  private void communicate() {
    // get messages from client and display them
    try {
      str = buffRead.readLine();
      if (str == null){
        mother.serverMain.display("\nNo answer from Client.");
      }
      mother.recieveMessages(str);
      mother.serverMain.display("\nMessage: "+str);

    }
    catch (IOException ex) {
      mother.serverMain.display("\nClient is dead:"+listen_sock.toString());
      mother.shutDownClient();
    }
  }
}




