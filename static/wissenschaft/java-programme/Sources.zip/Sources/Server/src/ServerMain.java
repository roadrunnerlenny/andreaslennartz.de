package Server;
/**
 * Server:
 * Program which manages the mainfunctions of a simple
 * server-program.
 * It was developed during the study visit in La Laguna
 * (Tenerife)(Wintersemester 04/05)
 *
 * ServerMain:
 * This class creates the serversocket and manages the rooms.
 *
 */

import java.net.*;
import java.io.*;
import java.util.*;
import java.util.Vector;

public class ServerMain {

  private ServerMainGUI gui;
  private ServerSocket servSocket;
  private HashMap roomList = new HashMap();
  //private Vector clientList = new Vector();

  public ServerMain() {
    try {
      startService();
      startConsole();
      createRoom("default");
      while (true) {
        new ClientSession(servSocket.accept(), this);
      }
    }
    catch (Exception ex) {
      display(ex.toString());
    }

  }

  private void startConsole()
  {
    gui = new ServerMainGUI();
    gui.show();
    gui.requestFocus();
  }

  public void display(String text) {
    gui.addToConsole(text);
  }


  public void startService()
  {
    try
    {
      servSocket = new ServerSocket(4711);
    }
    catch(Exception e)
    {
      display("\nunknown error:"+e.toString());
    }
  }

  public boolean createRoom(String roomname)
  {
    if (!roomname.equals("")) {
      roomList.put(roomname,new Vector());
      sendToAll("#serverinfo roomList "+returnRoomlist());
      return true;
    }
    else {
      return false;
    }

  }


  public boolean enterRoom(String roomname,ClientSession client)
  {
    try {
      // delete from old room
      String actRoom = client.getRoom();
      Vector clientsInOldRoom = (Vector) roomList.get(actRoom);
      clientsInOldRoom.removeElement(client);
      roomList.put(actRoom,clientsInOldRoom);

      // enlist in new room
      Vector clientsinNewRoom = (Vector) roomList.get(roomname);
      clientsinNewRoom.add(client);
      roomList.put(roomname,clientsinNewRoom);
      return true;
    }
    catch (Exception ex)
    {
      display("\nunknown error:"+ex.toString());
      return false;
    }

  }

  public void deleteClient(ClientSession client) {
    //System.out.println("Username"+client.getUserName());
    try {
      String actRoom = client.getRoom();
      Vector clientsInOldRoom = (Vector) roomList.get(actRoom);
      clientsInOldRoom.removeElement(client);
      roomList.put(actRoom, clientsInOldRoom);
    }
    catch (Exception ex)
    {
      display("\nunknown error:"+ex.toString());
    }

  }

  public void sendToRoom(String roomname,String message)
  {
    Vector clients = (Vector) roomList.get(roomname);
    for (int i=0;i<clients.size();i++)
    {
      ((ClientSession)clients.elementAt(i)).sendMessages(message);
    }
  }

  public String returnRoomlist()
  {
    String rooms = "";
    Iterator i = roomList.keySet().iterator();
    do {
      rooms += i.next().toString()+" ";
    } while (i.hasNext());
    return rooms;
  }

  public String returnUserlist(String room) {
    String users = "";
    Vector clientsInRoom = (Vector)roomList.get(room);
    for (int i=0;i<clientsInRoom.size();i++) {
      ClientSession client = (ClientSession)clientsInRoom.elementAt(i);
      users += client.getUserName() + " ";
    }
    return users;
  }


  public void sendToAll(String message)
  {
    Iterator it = roomList.values().iterator();
    do {
      Vector clientsInRoom = (Vector)(it.next());
      for (int i=0;i<clientsInRoom.size();i++)
      {
        ((ClientSession)(clientsInRoom.elementAt(i))).
        sendMessages(message);
      }
    } while (it.hasNext());
  }

  public boolean registerUser(ClientSession client)
  {
    //TO-DO: Hier abfangen, ob User �berhaupt registriert werden kann
    return (this.enterRoom("default",client));
  }

  public static void main(String Args[])
  {
    ServerMain sMain = new ServerMain();
   }

}

