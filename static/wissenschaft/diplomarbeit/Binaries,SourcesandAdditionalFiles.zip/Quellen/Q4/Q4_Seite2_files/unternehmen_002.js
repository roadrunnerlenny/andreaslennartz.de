document.write('<MAP NAME=\"vanco_mpu\">\n<AREA COORDS=\"0,0,336,280\" HREF=\"http://ad.de.doubleclick.net/click%3Bh=v3|3298|3|0|%2a|i%3B17027886%3B0-0%3B0%3B8448723%3B4252-336|280%3B10635948|10653844|1%3B%3B%7Esscs%3D%3fhttp://www.vancofreedom.com/de\" TARGET=\"_new\">\n</MAP>\n');

// BEGIN Trafficking variables - YOU MAY NEED TO CHANGE THESE
// Version of Flash being served
// NB - Flash 3 does not support client-side click tracking
var flash_version_no = "6";
// DART Datacenter URL or In-House Server URL (append trailing slash "/")
var site = "http://www.zdnet.de/";
// DART Advertiser ID Number or Path to files on In-House Server (append trailing slash "/")
var advid = "ads/banner/vanco/";
// Flash Movie Filename
var swfile= "VancoDE336x280_main.swf";
// Fallback Image filename
var imgfile = "vanco_mpu.gif";
// Clickstring Number 1 (add more of these as necessary)
var clicktagurl1="http://www.vancofreedom.com/de";
var clicktagurl2="http://www.vancofreedom.com/de";
var clicktagurl3="http://www.vancofreedom.com/de";
var clicktagurl4="http://www.vancofreedom.com/de";
var clicktagurl5="http://www.vancofreedom.com/de";
var clicktagurl6="http://www.vancofreedom.com/de";
// Alt Text for Ad     
var altext = "Vanco";
// Ad Width in pixels
var width = "336";
// Ad Height in pixels
var height = "280";
// Ad Border width in pixels
var border = "0"; 
// END - Trafficking variables
// START - Browser and Plugin Detection - DO NOT CHANGE
var ShockMode = 0;
var flash_enabled = (navigator.mimeTypes && navigator.mimeTypes["application/x-shockwave-flash"] ? navigator.mimeTypes["application/x-shockwave-flash"].enabledPlugin : 0);
// END - Sniffer code variables 
// If browser is Flash enabled and the plugin version is greater than version_no
if ( flash_enabled && parseInt(flash_enabled.description.substring(flash_enabled.description.indexOf(".")-1)) >= flash_version_no ) {
// then set Shockmode to 1
        ShockMode = 1;
}
// else if OS is Win9* or NT and Browser is MSIE
else if (navigator.userAgent && navigator.userAgent.indexOf("MSIE")>=0 && (navigator.userAgent.indexOf("Windows 9")>=0 || navigator.userAgent.indexOf("Windows NT")>=0)) {
// Write VBScript to browser
                document.write('<SCRIPT LANGUAGE=VBScript> \n');
                document.write('on error resume next \n');
                document.write('ShockMode = (IsObject(CreateObject("ShockwaveFlash.ShockwaveFlash")))\n');
                document.write('<\/SCRIPT> \n');
}
// Yes Flash is enabled, and the plugin is appropriate to use write OBJECT and EMBED code to browser
if ( ShockMode ) {
        document.write('<OBJECT classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"');
        document.write(' standby="' + altext + '"');
        document.write(' codebase="http://active.macromedia.com/flash/cabs/swflash.cab"');
        document.write(' ID=banner1 WIDTH=' + width + ' HEIGHT=' + height + '>');
        document.write(' <PARAM NAME=movie VALUE="' + site + advid + swfile + '?clickTag=http://ad.de.doubleclick.net/click%3Bh=v3|3298|3|0|%2a|i%3B17027886%3B0-0%3B0%3B8448723%3B4252-336|280%3B10635948|10653844|1%3B%3B%7Esscs%3D%3f' + clicktagurl1 + '"> ');
        document.write('  <PARAM NAME=quality VALUE=high> ');
	  document.write('  <PARAM NAME=menu VALUE=false> ');
        document.write('<EMBED SRC="' + site + advid + swfile + '?clickTag=http://ad.de.doubleclick.net/click%3Bh=v3|3298|3|0|%2a|i%3B17027886%3B0-0%3B0%3B8448723%3B4252-336|280%3B10635948|10653844|1%3B%3B%7Esscs%3D%3f' + clicktagurl1 + '"');
        document.write(' WIDTH=' + width + ' HEIGHT=' + height + '');
        document.write(' QUALITY=high');
        document.write(' TYPE="application/x-shockwave-flash" PLUGINSPAGE="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash">');
        document.write('</EMBED>');
        document.write('</OBJECT>');
} 
// Else if the browser is not Netscape version 2 or above, send a GIF with reference to the image map
        else if (!(navigator.appName && navigator.appName.indexOf("Netscape")>=0 && navigator.appVersion.indexOf("2.")>=0)) {
                document.write('<IMG SRC="' + site + advid + imgfile + '" WIDTH=' + width + ' HEIGHT=' + height + ' BORDER=' + border + ' ALT="' + altext + '" USEMAP="#vanco_mpu">');
        }
// For anything else, send a GIF with reference to the image map
        else {
                document.write('<IMG SRC="' + site + advid + imgfile + '" WIDTH=' + width + ' HEIGHT=' + height + ' BORDER=' + border + ' ALT="' + altext +'" USEMAP="#vanco_mpu">');
        }
// END - Browser and Plugin Detection
//-->
document.write('\n<!-- No EMBED tag support -->\n<NOEMBED>\n  <IMG SRC=\"http://www.zdnet.de/ads/banner/vanco/vanco_mpu.gif\" WIDTH=336 HEIGHT=280 BORDER=0 ALT=\"Vanco\" USEMAP=\"#vanco_mpu\">\n</NOEMBED>\n<!-- No JavaScript Support or Javascript disabled -->\n<NOSCRIPT>\n  <IMG SRC=\"http://www.zdnet.de/ads/banner/vanco_mpu.gif\" WIDTH=336 HEIGHT=280 BORDER=0 ALT=\"Vanco\" USEMAP=\"#vanco_mpu\">\n</NOSCRIPT>\n<!-- BEGIN Flash Ad Delivery Code-->');
