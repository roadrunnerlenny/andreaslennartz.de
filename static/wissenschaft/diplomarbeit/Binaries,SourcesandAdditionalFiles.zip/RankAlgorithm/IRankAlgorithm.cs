//..begin "File Description"
/*--------------------------------------------------------------------------------*
   Filename:  IRankAlgorithm.cs
   Tool:      objectiF, CSharpSSvr V5.0.165
 *--------------------------------------------------------------------------------*/
//..end "File Description"

using System;

namespace RankAlgorithmLib
{	
	public interface IRankAlgorithm
	{
		double MakeRank (double[] SimilarityValues);
	}
}