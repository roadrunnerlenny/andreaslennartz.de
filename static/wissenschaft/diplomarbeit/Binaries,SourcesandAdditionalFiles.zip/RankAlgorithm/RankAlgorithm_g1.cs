//..begin "File Description"
/*--------------------------------------------------------------------------------*
   Filename:  RankAlgorithm_g1.cs
   Tool:      objectiF, CSharpSSvr V5.0.165
 *--------------------------------------------------------------------------------*/
//..end "File Description"

using System;

namespace RankAlgorithmLib
{	
	/// <summary>
	/// Implementiert den beschriebenen Algorithmus g1 zur Bestimmung des Rangs eines Dokumentes
	/// </summary>	
	public class RankAlgorithm_g1 
		: IRankAlgorithm
	{
		/// <summary>
		/// Variabler Faktor zur Einflussnahme auf die Bedeutung von �hnlichkeitswerten.
		/// </summary>
		public double k
		{
			get
			{
				return I_k;
			}
			
			set
			{
				I_k = value;
			}
		}
		private double I_k;

		/// <summary>
		/// Berechnet nach �bergabe der �hnlichkeitswerte den beschreibenden Wert eines Dokumentes.
		/// </summary>
		/// <param name="SimilarityValues">Feld der �hnlichkeitswerte</param>
		/// <returns>Beschreibender Wert, der sich aus den �hnlichkeitswerten ergibt</returns>
		public double MakeRank (double[] SimilarityValues)
		{
			double rank=0;
			foreach (double s_value in SimilarityValues) 
			{
				rank=rank+Math.Pow(s_value,k);
			}    
			rank=1-1/(rank+1);
			return rank;
		}
	}
}