using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace TestEnvironment
{
	/// <summary>
	/// Zusammenfassung f�r ViewDocument.
	/// </summary>
	public class ViewDocument : System.Windows.Forms.Form
	{
		public Document document = null; 
		private ArrayList otherDocuments = null;
		private System.Windows.Forms.Label properties_label;
		private System.Windows.Forms.Button ShowInBrowser_button;
		private System.Windows.Forms.Label timeStats_label;
		private System.Windows.Forms.PictureBox Diagramm;
		/// <summary>
		/// Erforderliche Designervariable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ViewDocument(Document document,ArrayList otherEngines)
		{
			//
			// Erforderlich f�r die Windows Form-Designerunterst�tzung
			//
			InitializeComponent();

			//
			// TODO: F�gen Sie den Konstruktorcode nach dem Aufruf von InitializeComponent hinzu
			//
			this.document = document;
			properties_label.Text = "Eigenschaften von "+document.URL+"\n\n";
			properties_label.Text += "-- Titel:"+document.Title+"\n";
			if (document.Snippet.Length>0)
				properties_label.Text += "-- Snippet:"+document.Snippet+"\n\n";
			properties_label.Text+= "-- ID in Datenbank:"+document.IDFooxxDB+"\n";
			properties_label.Text+= "-- Unsortierte Trefferlistennummer: "+document.UnsortedRankNumber+"\n";
			
			if (document.SortedRankNumber>0) 
			{
				properties_label.Text+= "-- Sortierte Trefferlistennummer: "+document.SortedRankNumber+"\n"; 
				properties_label.Text+= "-- Beschreibender Wert:"+document.RankValue+"\n";
				timeStats_label.Text="Zeitwerte:\n";			
				timeStats_label.Text+="Zeitdauer der Personalisierung:"+document.WorkTime.Seconds+"sec:"+document.WorkTime.Milliseconds+"msec\n\n";
				timeStats_label.Text+="-- Datenbankabfrage:"+document.DatabaseTicks+" Ticks\n";
				timeStats_label.Text+="--Durchf�hrung des Personalisierungsalgorithmus:"+document.AlgorithmTicks+" Ticks\n";
			}
			this.otherDocuments = otherEngines;
			
		}

		/// <summary>
		/// Die verwendeten Ressourcen bereinigen.
		/// </summary>
		/// 

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Vom Windows Form-Designer generierter Code
		/// <summary>
		/// Erforderliche Methode f�r die Designerunterst�tzung. 
		/// Der Inhalt der Methode darf nicht mit dem Code-Editor ge�ndert werden.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ViewDocument));
			this.properties_label = new System.Windows.Forms.Label();
			this.ShowInBrowser_button = new System.Windows.Forms.Button();
			this.timeStats_label = new System.Windows.Forms.Label();
			this.Diagramm = new System.Windows.Forms.PictureBox();
			this.SuspendLayout();
			// 
			// properties_label
			// 
			this.properties_label.Location = new System.Drawing.Point(8, 8);
			this.properties_label.Name = "properties_label";
			this.properties_label.Size = new System.Drawing.Size(344, 336);
			this.properties_label.TabIndex = 0;
			this.properties_label.Text = "Eigenschaften des Dokumentes";
			// 
			// ShowInBrowser_button
			// 
			this.ShowInBrowser_button.Location = new System.Drawing.Point(360, 312);
			this.ShowInBrowser_button.Name = "ShowInBrowser_button";
			this.ShowInBrowser_button.Size = new System.Drawing.Size(360, 24);
			this.ShowInBrowser_button.TabIndex = 1;
			this.ShowInBrowser_button.Text = "Im Browser anzeigen";
			this.ShowInBrowser_button.Click += new System.EventHandler(this.ShowInBrowser_button_Click);
			// 
			// timeStats_label
			// 
			this.timeStats_label.Location = new System.Drawing.Point(368, 168);
			this.timeStats_label.Name = "timeStats_label";
			this.timeStats_label.Size = new System.Drawing.Size(352, 136);
			this.timeStats_label.TabIndex = 2;
			this.timeStats_label.Text = "Zeitstatisik f�r sortierte Dokumente";
			// 
			// Diagramm
			// 
			this.Diagramm.Location = new System.Drawing.Point(368, 8);
			this.Diagramm.Name = "Diagramm";
			this.Diagramm.Size = new System.Drawing.Size(350, 150);
			this.Diagramm.TabIndex = 3;
			this.Diagramm.TabStop = false;
			this.Diagramm.Paint += new System.Windows.Forms.PaintEventHandler(this.Diagramm_Paint);
			// 
			// ViewDocument
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(728, 350);
			this.Controls.Add(this.Diagramm);
			this.Controls.Add(this.timeStats_label);
			this.Controls.Add(this.ShowInBrowser_button);
			this.Controls.Add(this.properties_label);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "ViewDocument";
			this.Text = "ViewDocument";
			this.ResumeLayout(false);

		}
		#endregion

		private void ShowInBrowser_button_Click(object sender, System.EventArgs e)
		{
			System.Diagnostics.Process.Start("C:\\Programme\\Internet Explorer\\IExplore.exe",document.URL);
		}

		private void Diagramm_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			Pen raster = new Pen(Color.Black,2); 
			Font text = new Font("Arial",10);
			int width=350;int height=150;
			e.Graphics.DrawLine(raster,new Point(width/2,0),new Point(width/2,height));
			e.Graphics.DrawLine(raster,new Point(0,height),new Point(width,height));
			if (otherDocuments.Count>0) 
			{
				int maxRank = 0; 
				foreach(Document d in otherDocuments) 
				{	
					if(d.UnsortedRankNumber>maxRank)
							maxRank = d.UnsortedRankNumber;
					if (d.SortedRankNumber>maxRank)
						maxRank = d.SortedRankNumber;
				}
				Console.WriteLine("Max:"+maxRank); 
				int x=width/2;
				int y=20;
				bool userA = true; 
				foreach (Document d in otherDocuments) 
				{
					if (d.SortedRankNumber>0) 
					{
						x+=23;
						double pc = ((double)d.SortedRankNumber/(double)maxRank)*100.0;
						int hpos = (int)Math.Round(pc); 
						Console.WriteLine(hpos+":"+d.URL); 	
						string rank = "";
						if (userA==true) 
							rank = "A"+d.SortedRankNumber.ToString();
						else
							rank="B"+d.SortedRankNumber.ToString(); 
						if (d.SearchEngine.Equals("Google")) 
							e.Graphics.DrawString(rank,text,Brushes.Blue,new Point(x,hpos));
						if (d.SearchEngine.Equals("Lucene"))
							e.Graphics.DrawString(rank,text,Brushes.Green,new Point(x,hpos));
						if (d.SearchEngine.Equals("Fooxx"))
							e.Graphics.DrawString(rank,text,Brushes.Orange,new Point(x,hpos));
						if (userA==true) userA = false;  else userA = true;
					}
					else 
					{
						y+=23;
						//int hpos = height-(220-((100/(maxRank/d.UnsortedRankNumber)) * (height/100)));
						double pc = ((double)d.UnsortedRankNumber/(double)maxRank)*100.0;
						int hpos = (int)Math.Round(pc);
						Console.WriteLine(hpos+":"+d.URL); 
						if (d.SearchEngine.Equals("Google"))
							e.Graphics.DrawString("G"+d.UnsortedRankNumber.ToString(),text,Brushes.Blue,new Point(y,hpos));
						if (d.SearchEngine.Equals("Lucene"))
							e.Graphics.DrawString("L"+d.UnsortedRankNumber.ToString(),text,Brushes.Green,new Point(y,hpos));
						if (d.SearchEngine.Equals("Fooxx"))
							e.Graphics.DrawString("F"+d.UnsortedRankNumber.ToString(),text,Brushes.Orange,new Point(y,hpos));
					}

				}
			}
			
		}
	}
}
