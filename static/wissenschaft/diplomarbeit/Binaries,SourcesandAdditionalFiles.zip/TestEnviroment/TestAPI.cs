//..begin "File Description"
/*--------------------------------------------------------------------------------*
Filename:  TestAPI.cs
Tool:      objectiF, CSharpSSvr V5.0.165
*--------------------------------------------------------------------------------*/
//..end "File Description"

using System;
using MySql.Data.MySqlClient;
using TestEnvironment.GoogleAPI;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.IO;
using System.Text;
using System.Web;
using RankAlgorithmLib;
using Lucene.Net.Search;
using Lucene.Net.QueryParsers;
using Lucene.Net.Analysis.Standard;
using Lucene.Net.Analysis;
using System.Net;
using System.Xml;

namespace TestEnvironment
{	
	public class TestAPI
	:	ITestAPI
	{
		/// <summary>
		/// Maximale Anzahl an Dokumenten der Dokumentenmenge. 
		/// </summary>
		public int MaxNumberOfDocuments
		{
			get
			{
				return I_MaxNumberOfDocuments;
			}
			
			set
			{
				I_MaxNumberOfDocuments = value;
			}
		}
		
		/// <summary>
		/// In diesem Feld wird die unsortierte Dokumentenmenge vorgehalten
		/// </summary>
		public Document[] UnsortedDocumentList
		{
			get
			{
				return I_UnsortedDocumentList;
			}
			
			set
			{
				I_UnsortedDocumentList = value;
			}
		}
		
		/// <summary>
		/// In diesem Feld wird nach der Sortierung die sortierte Dokumentenmenge vorgehalten
		/// </summary>
		public Document[] SortedDocumentList
		{
			get
			{
				return I_SortedDocumentList;
			}
			
			set
			{
				I_SortedDocumentList = value;
			}
		}
				
		public enum AlgorithmNumbers : int
		{
			RankAlgortihm_g1 = 1
		}
		
		private int I_MaxNumberOfDocuments = 20;
		private Document[] I_UnsortedDocumentList;
		private Document[] I_SortedDocumentList;
		public static DatabaseAccessWrapper DBWrapper = new DatabaseAccessWrapper ( );
		
		/// <summary>
		/// Nach �bergabe eines Suchbegriffes wird die Google-API benutzt, 
		/// um die unsortierte Dokumentliste mit Dokumenten zu f�llen. 
		/// Bei erfolgreicher Durchf�hrung wird true zur�ckgeliefert. 
		/// </summary>
		/// <param name="searchstring">Suchbegriff, mit dem die Google-API
		/// abgefragt werden soll</param>
		/// <returns>true, falls Abfrage erfolgreich durchgef�hrt wurde.</returns>
		public bool UseGoogleAPI (string searchstring)
		{
			try 
			{
				//Erschaffen einer neuen Google-API
				GoogleAPI.GoogleSearchService searchService = new GoogleAPI.GoogleSearchService();
				GoogleAPI.GoogleSearchResult searchResult = null;
		
				//Pro Abfrage 10 Seiten abfragen				
				ArrayList results = new ArrayList(); 
				int hitcount=0; bool stop=false;
				do
				{
					// Suchanfrage �bergeben
					searchResult = searchService.doGoogleSearch("noOt0vhQFHKFszZECRhVL+wrEIbk7yJu", 
						searchstring,hitcount,10, false, "", false, "", "", "");
					hitcount += 10;
					if (hitcount>searchResult.endIndex) stop = true;
					//Jede abgefragte Seite speichern
					foreach (GoogleAPI.ResultElement result in searchResult.resultElements)
					{
						results.Add(result);						
					}
				} while (stop==false && hitcount < I_MaxNumberOfDocuments);
			
				//Dokuemnte in unsortierte Dokumentenmenge ablegen
				I_UnsortedDocumentList = new Document[results.Count];
				for(int i=0;i<results.Count;i++)
				{
					GoogleAPI.ResultElement result = (GoogleAPI.ResultElement)results[i];
						
					Document d = new Document(NormalizeURL(result.URL),result.title,result.snippet,this.GetDocumentFooxxID(NormalizeURL(result.URL)),(i+1),"Google");
					I_UnsortedDocumentList[i] = d;
				}
				return true;
			}
			catch (Exception e) 
			{
				Console.WriteLine(" caught a " + e.GetType() + "\n with message: " + e.Message);
				return false;
			}
		}
		
		/// <summary>
		/// Nach �bergabe eines Suchbegriffes wird die Fooxx-API benutzt,
		///  um die unsortierte Dokumentenliste mit Dokumenten zu f�llen. 
		///  Bei erfolgreicher Durchf�hrung wird true zur�ckgeliefert.
		/// </summary>
		/// <param name="searchstring">Suchbegriff, mit dem die Dokumente abgefragt werden</param>
		/// <param name="user">Nutzer, f�r den die Dokumente personalisiert werden</param>
		/// <returns>true, falls Abfrage erfolgreich war</returns>
		public bool UseFooxxAPI (string searchstring,string user)
		{
			try 
			{
				int page = 1;
				bool end = false;
				ArrayList documents = new ArrayList(); 
				for (int i=0;i<I_MaxNumberOfDocuments&&end==false;i=i+10) 
				{
					string url = "http://www.fooxx.com/fooxxapi.asp?un="+user+"&pageno="+page+"&context="+searchstring;
					page++; 
					HttpWebRequest myHttpWebRequest = (HttpWebRequest)WebRequest.Create(url); 
					HttpWebResponse myHttpWebResponse = (HttpWebResponse)myHttpWebRequest.GetResponse(); 
					Stream receiveStream = myHttpWebResponse.GetResponseStream();
					Encoding encode = System.Text.Encoding.GetEncoding("UTF-8");
					StreamReader readStream = new StreamReader( receiveStream, encode );
					Char[] read = new Char[256];
					string result = "";
					int count = readStream.Read( read, 0, 256 );
					while (count > 0) 
					{
						String str = new String(read, 0, count);
						result = result+str;
						count = readStream.Read(read, 0, 256);
					}
					myHttpWebResponse.Close();
					readStream.Close();

					for (int l=0;l<10;l++) 
					{
						try 
						{
							result = result.Substring(result.IndexOf("<entry"));
							string xml_url = result.Substring(result.IndexOf("url=\""));
							xml_url = xml_url.Remove(0,5); xml_url = xml_url.Substring(0,xml_url.IndexOf("\"")); 
							string xml_title = result.Substring(result.IndexOf("title=\""));
							xml_title = xml_title.Remove(0,7); xml_title = xml_title.Substring(0,xml_title.IndexOf("\"")); 
							string xml_snippet = result.Substring(result.IndexOf("snippet=\""));
							xml_snippet = xml_snippet.Remove(0,9); xml_snippet = xml_snippet.Substring(0,xml_snippet.IndexOf("\"")); 					
							result = result.Substring(result.IndexOf("/>")); 
							documents.Add(new Document(xml_url,xml_title,xml_snippet,this.GetDocumentFooxxID(xml_url),(i+1)+l,"Fooxx"));
						} 
						catch (Exception e) 
						{
							end = true; 
							break;	
						}
					}
				} 

				I_UnsortedDocumentList = new Document[documents.Count];

				for (int i=0;i<I_UnsortedDocumentList.Length;i++) 
				{
					Document d = (Document)documents[i]; 
					I_UnsortedDocumentList[i] = new Document(d.URL,d.Title,d.Snippet,d.IDFooxxDB,d.UnsortedRankNumber,d.SearchEngine); 
				}			
				return true; 
			}
			catch (Exception e) 
			{
				Console.WriteLine(" caught a " + e.GetType() + "\n with message: " + e.Message);
				return false;
			}
		}
		
		/// <summary>
		/// Nach �bergabe eines Suchbegriffes wird der eigene Index benutzt, 
		/// um die unsortierte Dokumentenliste mit Dokumenten zu f�llen. 
		/// Bei erfolgreicher Durchf�hrung wird true zur�ckgeliefert.
		/// </summary>
		/// <param name="searchstring">Suchbegriff, mit dem der eigene Index durchsucht werden soll</param>
		/// <returns>true, falls das Abfragen erfolgreich war</returns>
		public bool UseLuceneIndex (string searchstring)
		{
			try
			{
				Searcher searcher = new IndexSearcher(@"C:\Dokumente und Einstellungen\Lenny\Eigene Dateien\Diplomarbeit\UML\Testumgebung\index");
				Analyzer analyzer = new StandardAnalyzer();
				
				
				Query query = QueryParser.Parse(searchstring,"contents", analyzer);
								
				Hits hits = searcher.Search(query);
				
				int max_hits=0;
				max_hits = hits.Length() > I_MaxNumberOfDocuments ? I_MaxNumberOfDocuments : hits.Length(); 
				
				I_UnsortedDocumentList = new Document[max_hits]; 
		
				for (int i=0;i<max_hits;i++) 
				{
					Lucene.Net.Documents.Document lucene_doc = hits.Doc(i); 
					System.String path = lucene_doc.Get("url");
					
					string url;
					using (StreamReader sr = File.OpenText(@"../../../"+@path)) 
					{
						url= sr.ReadLine();
					}
		
					string title = ""; 
					int IDFooxxDB = -1; 
					
					ArrayList DBresult = DBWrapper.DoQuery("SELECT id,title FROM objects WHERE url = '"+NormalizeURL(url)+"'");
					if (DBresult.Count>0) 
					{
						foreach (object[] o in DBresult) 
						{
							IDFooxxDB = Int32.Parse(o[0].ToString());		
							title = System.Web.HttpUtility.UrlDecode(ASCIIEncoding.UTF8.GetString((byte[])o[1])); 
						}
					}				
		
					I_UnsortedDocumentList[i] = new Document(NormalizeURL(url),title,"Ohne",IDFooxxDB,(i+1),"Lucene");  
				}				
				searcher.Close();
				return true;
			}
			catch (System.Exception e)
			{
				Console.WriteLine(" caught a " + e.GetType() + "\n with message: " + e.Message);
				return false; 
			}

		}
		
		/// <summary>
		/// Erwartet als Parameter den Suchenden Nutzer vom Typ User, die Nummer des zu verwendenden Algorithmus 
		/// (z.B. 1 f�r RankAlgorithm_g1) sowie eine Liste mit evtl. notwendigen Parametern f�r diesen 
		/// Algorithmus. Liefert als R�ckgabewert true, falls das Sortieren erfolgreich war, ansonsten false.
		/// </summary>
		/// <param name="searchUser">Suchender Nutzer</param>
		/// <param name="AlgorithmNumber">Nummer des zu verwendenen Algorithmus</param>
		/// <param name="AlgorithmParameter">Weitere Parameter des Algorithmus</param>
		/// <returns>true, falls das Sortieren erfolgreich</returns>
		public bool SortDocumentList (User searchUser, int AlgorithmNumber, params double [ ] AlgorithmParameter)
		{
			try 
			{
				if (AlgorithmNumber==(int)AlgorithmNumbers.RankAlgortihm_g1) 
				{
					RankAlgorithm_g1 g1 = new RankAlgorithm_g1();
					g1.k=AlgorithmParameter[0];
					I_SortedDocumentList = new Document[I_UnsortedDocumentList.Length]; 
		
					/***** NACH DER OPTIMIERUNG *****/
					/*string query = "";
					for (int i=0;i<I_UnsortedDocumentList.Length;i++) 
					{
						query = query + "SELECT "+i+" doc_id,similarity FROM" +
							" (SELECT DISTINCT user_vid FROM protocol p, objects o " +
							"  WHERE p.object_id = o.id AND o.url = '" + I_UnsortedDocumentList[i].URL+ "')" +
							"a, similarity b WHERE a.user_vid = b.a_user_id and b.b_user_id = " + searchUser.UserID;
						if (i<I_UnsortedDocumentList.Length-1) 
						{
							query += " UNION ";
						}
					}
					ArrayList dbResults = DBWrapper.DoQuery(query);	*/
					/***** Nach der Optimierung Ende ****/
					for (int i=0;i<I_UnsortedDocumentList.Length;i++) 
					{
						Document d = new Document(I_UnsortedDocumentList[i].URL,I_UnsortedDocumentList[i].Title,I_UnsortedDocumentList[i].Snippet,
							I_UnsortedDocumentList[i].IDFooxxDB,I_UnsortedDocumentList[i].UnsortedRankNumber,I_UnsortedDocumentList[i].SearchEngine);
						DateTime now = System.DateTime.Now;
						
						int ticksNow = Environment.TickCount; 
						/*** Vor der Optimierung ***/
						double[] simValues = this.GetSimilarityValues(searchUser,d); 
						/* Vor der Optimierung Ende **/
						/*** Nach der Optimierung ***/
						//double[] simValues = this.GetSimilarityValues(dbResults,i); 
						/*** Nach der Optimierung Ende ***/
						d.DatabaseTicks = Environment.TickCount-ticksNow; 
					
						ticksNow = Environment.TickCount;
						d.RankValue = g1.MakeRank(simValues);					
						d.AlgorithmTicks = Environment.TickCount-ticksNow; 
					
						DateTime later = System.DateTime.Now;
						d.WorkTime = later-now;
						I_SortedDocumentList[i] = d;
					}

				
					System.Array.Sort(I_SortedDocumentList);
					for (int i=0;i<I_SortedDocumentList.Length;i++) 
					{
						I_SortedDocumentList[i].SortedRankNumber = i+1;
					}
				}
				return true;
			}
			catch (Exception e) 
			{
				Console.WriteLine(e); 
				return false;
			}
		}
		
		/*** VOR DER OPTIMIERUNG ***/
		/// <summary>
		/// Liefert f�r die �bergebenden Dokumente alle �hnlichkeitswerte der anderen Nutzer 
		/// im Verh�ltnis zum �bergebenden Nutzer zur�ck.
		/// </summary>
		/// <param name="searchUser">Suchender Nutzer</param>
		/// <param name="document">Dokument</param>
		/// <returns>�hnlichkeitswerte der Nutzer des Dokumentes im Verh�ltnis zum Suchenden Nutzer</returns>
 		private double[] GetSimilarityValues (User searchUser, Document document)
		{
			document.URL = NormalizeURL(document.URL);

			string query = "SELECT similarity FROM" +
				" (SELECT DISTINCT user_vid FROM protocol p, objects o " +
				"  WHERE p.object_id = o.id AND o.url = '" + document.URL + "')" +
				"a, similarity b WHERE a.user_vid = b.a_user_id AND b.b_user_id = " + searchUser.UserID;
			
			ArrayList dbResults = DBWrapper.DoQuery(query); 
		
			double[] s = new double[dbResults.Count];
			int count=0; 
			foreach (object[] o in dbResults) 
			{
				s[count++] = Double.Parse(o[0].ToString()); 
			}
			return s;
		}

		/*** NACH DER OPTIMIERUNG ***/
		/// <summary>
		/// Hilfsfunktion, die �hnlichkeitswerte einer Abfrage mit mehreren Dokumeten zur�ckgibt
		/// </summary>
		/// <param name="dbResults">Ergebnis der Datenbankabfrage</param>
		/// <param name="doc_id">interne ID des Dokumentes</param>
		/// <returns>�hnlichkeitswerte des Dokumentes</returns>
		private double[] GetSimilarityValues(ArrayList dbResults,int doc_id) 
		{
			ArrayList s_Values = new ArrayList(); 
			foreach (object[] o in dbResults) 
			{
				if (Int32.Parse(o[0].ToString()) == doc_id) 
				{
					s_Values.Add(Double.Parse(o[1].ToString()));
				}				
			}
			double[] s_Values_d = new double[s_Values.Count];
			int count=0;
			foreach (double d in s_Values) 
			{
				s_Values_d[count++]=d;
			}
			return s_Values_d;
		}

		/// <summary>
		/// Liefert f�r die �bergebene URL die (falls vorhanden) ID des Dokumentes 
		/// in der Fooxx-Datenbank zur�ck. 
		/// </summary>
		/// <param name="URL">URL des Dokumentes</param>
		/// <returns>ID des Dokumentes in der Fooxx-Datenbank</returns>
		private int GetDocumentFooxxID(string URL) 
		{		
			int IDFooxxDB = -1;
			ArrayList DBresult = DBWrapper.DoQuery("SELECT id FROM objects WHERE url = '"+NormalizeURL(URL)+"'");
			if (DBresult.Count>0) 
			{
				foreach (object[] o in DBresult) 
				{
					IDFooxxDB = Int32.Parse(o[0].ToString());
				}
			}
			return IDFooxxDB;
		}
		
		/// <summary>
		/// Hilfsfunktion, die die �bergebene URL auf eine einheitliche Form bringt und diese zur�ckgibt.
		/// </summary>
		/// <param name="URL">URL, die normalisiert werden soll</param>
		/// <returns>Einheitliche Form der �bergebenen URL</returns>
		private string NormalizeURL (string URL)
		{
			string newURL = URL; 
			if ( !(newURL.StartsWith("http://")||newURL.StartsWith("https://")) ) 
				newURL="http://"+newURL;
			if (newURL.EndsWith("/"))
				newURL=newURL.Substring(0,newURL.Length-1); 
			newURL = newURL.Replace("&amp;","&");

			return newURL; 
		}
		
		/// <summary>
		/// Hilfsfunktion, die f�r eine �bergebene ID den entsprechenden Nutzer zur�ckgibt. 
		/// </summary>
		/// <param name="userID">ID eines Nutzer</param>
		/// <returns>Nutzer der �bergebenen ID</returns>
		public static User GetUserByID (int userID)
		{
			ArrayList dbResults = DBWrapper.DoQuery("SELECT nickname FROM user_vid WHERE id="+userID); 
			
			foreach (object[] o in dbResults) 
			{
				User u = new User(userID,o[0].ToString()); 
				return u;
			}
			return null;
		}
	}
}