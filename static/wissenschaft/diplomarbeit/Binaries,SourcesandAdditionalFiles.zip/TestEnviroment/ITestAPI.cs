//..begin "File Description"
/*--------------------------------------------------------------------------------*
   Filename:  ITestAPI.cs
   Tool:      objectiF, CSharpSSvr V5.0.165
 *--------------------------------------------------------------------------------*/
//..end "File Description"

using System;
using MySql.Data.MySqlClient;
using TestEnvironment.GoogleAPI;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.IO;
using System.Text;
using System.Web;
using RankAlgorithmLib;

namespace TestEnvironment
{	
	public interface ITestAPI
	{
		Document [ ] UnsortedDocumentList
		{
			get; 
			set; 
		}
		
		Document [ ] SortedDocumentList
		{
			get; 
			set; 
		}
		
		bool SortDocumentList (User searchUser, int AlgorithmNumber, params double [ ] AlgorithmParameter);
	}
}