//..begin "File Description"
/*--------------------------------------------------------------------------------*
   Filename:  Document.cs
   Tool:      objectiF, CSharpSSvr V5.0.165
 *--------------------------------------------------------------------------------*/
//..end "File Description"

using System;
using MySql.Data.MySqlClient;
using TestEnvironment.GoogleAPI;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.IO;
using System.Text;
using System.Web;
using RankAlgorithmLib;

namespace TestEnvironment
{	
	public class Document
	:	System.IComparable
	{
		public string URL
		{
			get
			{
				return I_URL;
			}
			
			set
			{
				I_URL = value;
			}
		}
		
		public string Title
		{
			get
			{
				return I_Title;
			}
			
			set
			{
				I_Title = value;
			}
		}
		
		public string Snippet
		{
			get
			{
				return I_Snippet;
			}
			
			set
			{
				I_Snippet = value;
			}
		}
		
		public double RankValue
		{
			get
			{
				return I_RankValue;
			}
			
			set
			{
				I_RankValue = value;
			}
		}
		
		public int IDFooxxDB
		{
			get
			{
				return I_IDFooxxDB;
			}
			
			set
			{
				I_IDFooxxDB = value;
			}
		}
		
		public int UnsortedRankNumber
		{
			get
			{
				return I_UnsortedRankNumber;
			}
			
			set
			{
				I_UnsortedRankNumber = value;
			}
		}
		
		public int SortedRankNumber
		{
			get
			{
				return I_SortedRankNumber;
			}
			
			set
			{
				I_SortedRankNumber = value;
			}
		}
		
		public string SearchEngine
		{
			get
			{
				return I_SearchEngine;
			}
			
			set
			{
				I_SearchEngine = value;
			}
		}
		
		private string I_URL;
		private string I_Title;
		private string I_Snippet;
		private double I_RankValue;
		private int I_IDFooxxDB;
		private int I_UnsortedRankNumber;
		private int I_SortedRankNumber;
		private string I_SearchEngine;
		
		//Zeitangaben f�r Debugging-Zwecke
		public TimeSpan WorkTime = new TimeSpan ( 0 );
		public int AlgorithmTicks = 0;
		public int DatabaseTicks = 0;
		
		public Document (string URL, string Title, string Snippet, int IDFooxxDB, int UnsortedRankNumber, string SearchEngine)
		{
			this.I_URL = URL;
			this.I_Title = Title;
			this.I_Snippet = Snippet;
			this.I_RankValue=0;
			this.I_IDFooxxDB = IDFooxxDB;
			this.I_UnsortedRankNumber = UnsortedRankNumber;
			this.I_SortedRankNumber = -1; 
			this.I_SearchEngine = SearchEngine; 
		}
		
		public int CompareTo (object obj)
		{
			if (obj is Document) 
			{
				Document d = (Document)obj;
				if ( I_RankValue>0 || d.RankValue>0 ) 
				{
					return new CaseInsensitiveComparer().Compare(d.RankValue,I_RankValue); 
				} 
				else 
				{
					return -1;
				}
				
			}
			throw new ArgumentException("Object is not a Document");
		}
		
		public override string ToString ()
		{
			if (SortedRankNumber!=-1) 
			{
				return I_SortedRankNumber+" ("+I_UnsortedRankNumber+") : "+I_URL;
			}
			else
			{
				return I_UnsortedRankNumber+" : "+I_URL; 
			}
		}
	}
}