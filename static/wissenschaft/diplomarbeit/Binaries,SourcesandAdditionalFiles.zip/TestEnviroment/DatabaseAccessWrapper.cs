//..begin "File Description"
/*--------------------------------------------------------------------------------*
   Filename:  DatabaseAccessWrapper.cs
   Tool:      objectiF, CSharpSSvr V5.0.165
 *--------------------------------------------------------------------------------*/
//..end "File Description"

using System;
using MySql.Data.MySqlClient;
using TestEnvironment.GoogleAPI;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.IO;
using System.Text;
using System.Web;
using RankAlgorithmLib;

namespace TestEnvironment
{	
	public class DatabaseAccessWrapper
	{
		string myConnectionString = "Database=gbn;Data Source=localhost;User Id=root;Password=gbn";
		MySqlConnection myConnection = null;

		private void Connect ()
		{
			myConnection = new MySqlConnection(myConnectionString);
			myConnection.Open();
		}
		
		private void Close ()
		{
			myConnection.Close(); 
		}
		
		public void DoNonQuery (string NonQuery)
		{
			this.Connect(); 
			MySqlCommand myCommand = new MySqlCommand(NonQuery,myConnection);
			myCommand.ExecuteNonQuery();
			this.Close(); 
		}
		
		public System.Collections.ArrayList DoQuery (string Query)
		{
			this.Connect(); 
			ArrayList result = new ArrayList(); 
			MySqlCommand myCommand = new MySqlCommand(Query,myConnection);
			MySqlDataReader myReader = myCommand.ExecuteReader();
			try 
			{
				while (myReader.Read()) 
				{
					object[] content = new object[myReader.FieldCount];
					myReader.GetValues(content);
					result.Add(content); 
				}
			}
			finally 
			{
				// always call Close when done with connection.
				myReader.Close();
			}
			this.Close(); 
			return result;
		}
		
	}
}