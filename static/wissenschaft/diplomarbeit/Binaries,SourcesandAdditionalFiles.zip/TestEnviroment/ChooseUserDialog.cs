using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace TestEnvironment
{
	/// <summary>
	/// Zusammenfassung f�r ChooseUserDialog.
	/// </summary>
	public class ChooseUserDialog : System.Windows.Forms.Form
	{
		public User choosedUser; 
		private System.Windows.Forms.ComboBox userName_comboBox;
		private System.Windows.Forms.Button chooseUser_button;
		/// <summary>
		/// Erforderliche Designervariable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ChooseUserDialog()
		{
			//
			// Erforderlich f�r die Windows Form-Designerunterst�tzung
			//
			InitializeComponent();

			//
			// TODO: F�gen Sie den Konstruktorcode nach dem Aufruf von InitializeComponent hinzu
			//

			ArrayList dbResults = TestAPI.DBWrapper.DoQuery("SELECT id,nickname FROM user_vid ORDER BY nickname"); 
		
			foreach (object[] o in dbResults) 
			{
				User u = new User(Int32.Parse(o[0].ToString()),o[1].ToString()); 
				userName_comboBox.Items.Add(u); 
			}
		
		}

		/// <summary>
		/// Die verwendeten Ressourcen bereinigen.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		protected override void OnClosing(CancelEventArgs e)
		{
			// If user clicked the OK button, make sure to
			// save the content. This must be done in the
			// SaveSettings() method in the derived Form.
			//if (!e.Cancel && (this.DialogResult == DialogResult.OK))
		//	{
				// If SaveSettings() is OK (TRUE), then e.Cancel
				// will be FALSE, therefore the application will be exit.
				//e.Cancel = !SaveSettings();
		//	}

			// Make sure any Closing event handler for the
			// form are called before the application exits.
			base.OnClosing(e);
		}

		#region Vom Windows Form-Designer generierter Code
		/// <summary>
		/// Erforderliche Methode f�r die Designerunterst�tzung. 
		/// Der Inhalt der Methode darf nicht mit dem Code-Editor ge�ndert werden.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ChooseUserDialog));
			this.userName_comboBox = new System.Windows.Forms.ComboBox();
			this.chooseUser_button = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// userName_comboBox
			// 
			this.userName_comboBox.Location = new System.Drawing.Point(8, 16);
			this.userName_comboBox.Name = "userName_comboBox";
			this.userName_comboBox.Size = new System.Drawing.Size(200, 21);
			this.userName_comboBox.TabIndex = 0;
			this.userName_comboBox.Text = "Nutzer ausw�hlen";
			// 
			// chooseUser_button
			// 
			this.chooseUser_button.Location = new System.Drawing.Point(216, 16);
			this.chooseUser_button.Name = "chooseUser_button";
			this.chooseUser_button.Size = new System.Drawing.Size(80, 24);
			this.chooseUser_button.TabIndex = 1;
			this.chooseUser_button.Text = "Ausw�hlen";
			this.chooseUser_button.Click += new System.EventHandler(this.chooseUser_button_Click);
			// 
			// ChooseUserDialog
			// 
			this.AcceptButton = this.chooseUser_button;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(304, 54);
			this.Controls.Add(this.chooseUser_button);
			this.Controls.Add(this.userName_comboBox);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "ChooseUserDialog";
			this.ShowInTaskbar = false;
			this.Text = "ChooseUserDialog";
			this.ResumeLayout(false);

		}
		#endregion

		private void chooseUser_button_Click(object sender, System.EventArgs e)
		{
			this.choosedUser = (User)userName_comboBox.SelectedItem;
			this.DialogResult = DialogResult.OK;   
		}
	}
}
