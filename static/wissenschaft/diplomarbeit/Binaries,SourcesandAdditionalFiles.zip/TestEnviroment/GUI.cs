//..begin "File Description"
/*--------------------------------------------------------------------------------*
   Filename:  GUI.cs
   Tool:      objectiF, CSharpSSvr V5.0.165
 *--------------------------------------------------------------------------------*/
//..end "File Description"

using System;
using MySql.Data.MySqlClient;
using TestEnvironment.GoogleAPI;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.IO;
using System.Text;
using System.Web;
using RankAlgorithmLib;

namespace TestEnvironment
{	
	public class GUI
	:	System.Windows.Forms.Form
	{
		TestAPI [ ] GoogleControl = new TestAPI [ 2 ];
		TestAPI [ ] LuceneControl = new TestAPI [ 2 ];
		TestAPI [ ] FooxxControl = new TestAPI [ 2 ];
		private System.Windows.Forms.TextBox searchstring_textBox;
		public System.Windows.Forms.ListBox SortedDocuments_listBox;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.RadioButton RankAlgorithm_g1_radioButton;
		private System.Windows.Forms.Panel panel4;
		private System.Windows.Forms.TextBox UserID_textBox;
		private System.Windows.Forms.TextBox k_textBox;
		private System.Windows.Forms.Button startSearch_button;
		private System.Windows.Forms.Button SortIt_button;
		private System.Windows.Forms.ListBox SortedDocuments2_listBox;
		private System.Windows.Forms.TextBox UserID2_textBox;
		private System.Windows.Forms.Panel panel5;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Panel panel6;
		private System.Windows.Forms.Panel panel7;
		private System.Windows.Forms.CheckBox UseGoogle_checkBox;
		private System.Windows.Forms.CheckBox UseLucene_checkBox;
		private System.Windows.Forms.TextBox MaxDocumentNumberGoogle_textBox;
		private System.Windows.Forms.TextBox MaxDocumentNumberLucene_textBox;
		private System.Windows.Forms.TextBox MaxDocumentNumberFooxx_textBox;
		private System.Windows.Forms.Label MaxDocumentNumberFooxx_label;
		private System.Windows.Forms.Label MaxDocumentNumberLucene_label;
		private System.Windows.Forms.Label MaxDocumentNumberGoogle_label;
		private System.Windows.Forms.GroupBox UnsortedGroupBox;
		private System.Windows.Forms.GroupBox SortedGroupBox;
		private System.Windows.Forms.GroupBox ControlGroupBox;
		private System.Windows.Forms.RadioButton ShowGoogle_radioButton;
		private System.Windows.Forms.RadioButton ShowLucene_radioButton;
		private System.Windows.Forms.RadioButton ShowFooxx_radioButton;
		private System.Windows.Forms.Label k_label;
		private System.Windows.Forms.Panel panel8;
		private System.Windows.Forms.Label UserID_label;
		private System.Windows.Forms.Label UserID2_label;
		private System.Windows.Forms.Label SortedDocuments_label;
		private System.Windows.Forms.Label SortedDocuments2_label;
		private System.Windows.Forms.CheckBox UseFooxx_checkBox;
		private System.Windows.Forms.CheckBox PersonalizeGoogle_checkBox;
		private System.Windows.Forms.CheckBox PersonalizeLucene_checkBox;
		private System.Windows.Forms.CheckBox PersonalizeFooxx_checkBox;
		private System.Windows.Forms.ListBox UnsortedDocumentsGoogle_listBox;
		private System.Windows.Forms.ListBox UnsortedDocumentsLucene_listBox;
		private System.Windows.Forms.ListBox UnsortedDocumentsFooxx_listBox;
		private System.Windows.Forms.Button SearchUserID_button;
		private System.Windows.Forms.Button SearchUserID2_button;
		private System.Windows.Forms.Label status_label;
		private System.Windows.Forms.Label GoogleStatus_label;
		private System.Windows.Forms.Label LuceneStatus_label;
		private System.Windows.Forms.Label FooxxStatus_label;
		private System.Windows.Forms.Label UserStatus_label;
		private System.Windows.Forms.Label UserStatus2_label;
		private System.Windows.Forms.TextBox FooxxUser_textBox;
		private System.Windows.Forms.Label FooxxUser_label;
		private System.Windows.Forms.Button SaveAll_button;
		private System.Windows.Forms.SaveFileDialog saveFileDialog;
		/// <summary>
		/// Erforderliche Designervariable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		
		public GUI ()
		{
			//
			// Erforderlich f�r die Windows Form-Designerunterst�tzung
			//
			InitializeComponent();
		
			GoogleControl[0] = new TestAPI();
			GoogleControl[1] = new TestAPI();
			LuceneControl[0] = new TestAPI();
			LuceneControl[1] = new TestAPI();
			FooxxControl[0] = new TestAPI();
			FooxxControl[1] = new TestAPI();
			
		}
		
		#region Vom Designer erstellter Code
		
		private void InitializeComponent ()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(GUI));
			this.searchstring_textBox = new System.Windows.Forms.TextBox();
			this.startSearch_button = new System.Windows.Forms.Button();
			this.UnsortedGroupBox = new System.Windows.Forms.GroupBox();
			this.panel7 = new System.Windows.Forms.Panel();
			this.FooxxUser_label = new System.Windows.Forms.Label();
			this.FooxxUser_textBox = new System.Windows.Forms.TextBox();
			this.FooxxStatus_label = new System.Windows.Forms.Label();
			this.UnsortedDocumentsFooxx_listBox = new System.Windows.Forms.ListBox();
			this.PersonalizeFooxx_checkBox = new System.Windows.Forms.CheckBox();
			this.MaxDocumentNumberFooxx_label = new System.Windows.Forms.Label();
			this.MaxDocumentNumberFooxx_textBox = new System.Windows.Forms.TextBox();
			this.UseFooxx_checkBox = new System.Windows.Forms.CheckBox();
			this.panel6 = new System.Windows.Forms.Panel();
			this.LuceneStatus_label = new System.Windows.Forms.Label();
			this.UnsortedDocumentsLucene_listBox = new System.Windows.Forms.ListBox();
			this.PersonalizeLucene_checkBox = new System.Windows.Forms.CheckBox();
			this.MaxDocumentNumberLucene_label = new System.Windows.Forms.Label();
			this.MaxDocumentNumberLucene_textBox = new System.Windows.Forms.TextBox();
			this.UseLucene_checkBox = new System.Windows.Forms.CheckBox();
			this.panel1 = new System.Windows.Forms.Panel();
			this.GoogleStatus_label = new System.Windows.Forms.Label();
			this.UnsortedDocumentsGoogle_listBox = new System.Windows.Forms.ListBox();
			this.PersonalizeGoogle_checkBox = new System.Windows.Forms.CheckBox();
			this.MaxDocumentNumberGoogle_label = new System.Windows.Forms.Label();
			this.MaxDocumentNumberGoogle_textBox = new System.Windows.Forms.TextBox();
			this.UseGoogle_checkBox = new System.Windows.Forms.CheckBox();
			this.panel2 = new System.Windows.Forms.Panel();
			this.SortedGroupBox = new System.Windows.Forms.GroupBox();
			this.UserStatus2_label = new System.Windows.Forms.Label();
			this.UserStatus_label = new System.Windows.Forms.Label();
			this.SortedDocuments2_label = new System.Windows.Forms.Label();
			this.SortedDocuments_label = new System.Windows.Forms.Label();
			this.panel8 = new System.Windows.Forms.Panel();
			this.ShowGoogle_radioButton = new System.Windows.Forms.RadioButton();
			this.ShowLucene_radioButton = new System.Windows.Forms.RadioButton();
			this.ShowFooxx_radioButton = new System.Windows.Forms.RadioButton();
			this.SortedDocuments2_listBox = new System.Windows.Forms.ListBox();
			this.SortedDocuments_listBox = new System.Windows.Forms.ListBox();
			this.panel4 = new System.Windows.Forms.Panel();
			this.k_label = new System.Windows.Forms.Label();
			this.k_textBox = new System.Windows.Forms.TextBox();
			this.panel3 = new System.Windows.Forms.Panel();
			this.RankAlgorithm_g1_radioButton = new System.Windows.Forms.RadioButton();
			this.ControlGroupBox = new System.Windows.Forms.GroupBox();
			this.status_label = new System.Windows.Forms.Label();
			this.panel5 = new System.Windows.Forms.Panel();
			this.SearchUserID2_button = new System.Windows.Forms.Button();
			this.SearchUserID_button = new System.Windows.Forms.Button();
			this.UserID2_label = new System.Windows.Forms.Label();
			this.UserID_label = new System.Windows.Forms.Label();
			this.UserID2_textBox = new System.Windows.Forms.TextBox();
			this.UserID_textBox = new System.Windows.Forms.TextBox();
			this.SortIt_button = new System.Windows.Forms.Button();
			this.SaveAll_button = new System.Windows.Forms.Button();
			this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
			this.UnsortedGroupBox.SuspendLayout();
			this.panel7.SuspendLayout();
			this.panel6.SuspendLayout();
			this.panel1.SuspendLayout();
			this.panel2.SuspendLayout();
			this.SortedGroupBox.SuspendLayout();
			this.panel8.SuspendLayout();
			this.panel4.SuspendLayout();
			this.panel3.SuspendLayout();
			this.ControlGroupBox.SuspendLayout();
			this.panel5.SuspendLayout();
			this.SuspendLayout();
			// 
			// searchstring_textBox
			// 
			this.searchstring_textBox.Location = new System.Drawing.Point(8, 16);
			this.searchstring_textBox.Name = "searchstring_textBox";
			this.searchstring_textBox.Size = new System.Drawing.Size(304, 20);
			this.searchstring_textBox.TabIndex = 1;
			this.searchstring_textBox.Text = "Suchbegriff";
			this.searchstring_textBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.searchstring_textBox_KeyDown);
			// 
			// startSearch_button
			// 
			this.startSearch_button.Location = new System.Drawing.Point(320, 16);
			this.startSearch_button.Name = "startSearch_button";
			this.startSearch_button.Size = new System.Drawing.Size(152, 24);
			this.startSearch_button.TabIndex = 2;
			this.startSearch_button.Text = "Suchen";
			this.startSearch_button.Click += new System.EventHandler(this.startSearch_button_Click);
			// 
			// UnsortedGroupBox
			// 
			this.UnsortedGroupBox.Controls.Add(this.panel7);
			this.UnsortedGroupBox.Controls.Add(this.panel6);
			this.UnsortedGroupBox.Controls.Add(this.panel1);
			this.UnsortedGroupBox.Controls.Add(this.panel2);
			this.UnsortedGroupBox.Location = new System.Drawing.Point(8, 8);
			this.UnsortedGroupBox.Name = "UnsortedGroupBox";
			this.UnsortedGroupBox.Size = new System.Drawing.Size(496, 800);
			this.UnsortedGroupBox.TabIndex = 4;
			this.UnsortedGroupBox.TabStop = false;
			this.UnsortedGroupBox.Text = "UnsortedGroupBox";
			// 
			// panel7
			// 
			this.panel7.Controls.Add(this.FooxxUser_label);
			this.panel7.Controls.Add(this.FooxxUser_textBox);
			this.panel7.Controls.Add(this.FooxxStatus_label);
			this.panel7.Controls.Add(this.UnsortedDocumentsFooxx_listBox);
			this.panel7.Controls.Add(this.PersonalizeFooxx_checkBox);
			this.panel7.Controls.Add(this.MaxDocumentNumberFooxx_label);
			this.panel7.Controls.Add(this.MaxDocumentNumberFooxx_textBox);
			this.panel7.Controls.Add(this.UseFooxx_checkBox);
			this.panel7.Location = new System.Drawing.Point(8, 544);
			this.panel7.Name = "panel7";
			this.panel7.Size = new System.Drawing.Size(472, 248);
			this.panel7.TabIndex = 9;
			// 
			// FooxxUser_label
			// 
			this.FooxxUser_label.Location = new System.Drawing.Point(32, 32);
			this.FooxxUser_label.Name = "FooxxUser_label";
			this.FooxxUser_label.Size = new System.Drawing.Size(264, 24);
			this.FooxxUser_label.TabIndex = 9;
			this.FooxxUser_label.Text = "Personalisierung der Ergebnisse mit Fooxx-Nutzer:";
			this.FooxxUser_label.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// FooxxUser_textBox
			// 
			this.FooxxUser_textBox.Location = new System.Drawing.Point(304, 32);
			this.FooxxUser_textBox.Name = "FooxxUser_textBox";
			this.FooxxUser_textBox.Size = new System.Drawing.Size(160, 20);
			this.FooxxUser_textBox.TabIndex = 8;
			this.FooxxUser_textBox.Text = "GAST";
			// 
			// FooxxStatus_label
			// 
			this.FooxxStatus_label.Location = new System.Drawing.Point(8, 224);
			this.FooxxStatus_label.Name = "FooxxStatus_label";
			this.FooxxStatus_label.Size = new System.Drawing.Size(464, 24);
			this.FooxxStatus_label.TabIndex = 7;
			// 
			// UnsortedDocumentsFooxx_listBox
			// 
			this.UnsortedDocumentsFooxx_listBox.Location = new System.Drawing.Point(8, 56);
			this.UnsortedDocumentsFooxx_listBox.Name = "UnsortedDocumentsFooxx_listBox";
			this.UnsortedDocumentsFooxx_listBox.Size = new System.Drawing.Size(464, 160);
			this.UnsortedDocumentsFooxx_listBox.TabIndex = 6;
			this.UnsortedDocumentsFooxx_listBox.DoubleClick += new System.EventHandler(this.listBox_DoubleClick);
			// 
			// PersonalizeFooxx_checkBox
			// 
			this.PersonalizeFooxx_checkBox.Location = new System.Drawing.Point(376, 8);
			this.PersonalizeFooxx_checkBox.Name = "PersonalizeFooxx_checkBox";
			this.PersonalizeFooxx_checkBox.TabIndex = 5;
			this.PersonalizeFooxx_checkBox.Text = "Personalisieren";
			// 
			// MaxDocumentNumberFooxx_label
			// 
			this.MaxDocumentNumberFooxx_label.Location = new System.Drawing.Point(168, 8);
			this.MaxDocumentNumberFooxx_label.Name = "MaxDocumentNumberFooxx_label";
			this.MaxDocumentNumberFooxx_label.Size = new System.Drawing.Size(128, 24);
			this.MaxDocumentNumberFooxx_label.TabIndex = 4;
			this.MaxDocumentNumberFooxx_label.Text = "Max. Anzahl Dokumente";
			this.MaxDocumentNumberFooxx_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// MaxDocumentNumberFooxx_textBox
			// 
			this.MaxDocumentNumberFooxx_textBox.Location = new System.Drawing.Point(304, 8);
			this.MaxDocumentNumberFooxx_textBox.Name = "MaxDocumentNumberFooxx_textBox";
			this.MaxDocumentNumberFooxx_textBox.Size = new System.Drawing.Size(48, 20);
			this.MaxDocumentNumberFooxx_textBox.TabIndex = 3;
			this.MaxDocumentNumberFooxx_textBox.Text = "30";
			// 
			// UseFooxx_checkBox
			// 
			this.UseFooxx_checkBox.Location = new System.Drawing.Point(8, 8);
			this.UseFooxx_checkBox.Name = "UseFooxx_checkBox";
			this.UseFooxx_checkBox.TabIndex = 2;
			this.UseFooxx_checkBox.Text = "Fooxx abfragen";
			// 
			// panel6
			// 
			this.panel6.Controls.Add(this.LuceneStatus_label);
			this.panel6.Controls.Add(this.UnsortedDocumentsLucene_listBox);
			this.panel6.Controls.Add(this.PersonalizeLucene_checkBox);
			this.panel6.Controls.Add(this.MaxDocumentNumberLucene_label);
			this.panel6.Controls.Add(this.MaxDocumentNumberLucene_textBox);
			this.panel6.Controls.Add(this.UseLucene_checkBox);
			this.panel6.Location = new System.Drawing.Point(8, 296);
			this.panel6.Name = "panel6";
			this.panel6.Size = new System.Drawing.Size(480, 248);
			this.panel6.TabIndex = 8;
			// 
			// LuceneStatus_label
			// 
			this.LuceneStatus_label.Location = new System.Drawing.Point(8, 224);
			this.LuceneStatus_label.Name = "LuceneStatus_label";
			this.LuceneStatus_label.Size = new System.Drawing.Size(464, 24);
			this.LuceneStatus_label.TabIndex = 7;
			// 
			// UnsortedDocumentsLucene_listBox
			// 
			this.UnsortedDocumentsLucene_listBox.Location = new System.Drawing.Point(8, 32);
			this.UnsortedDocumentsLucene_listBox.Name = "UnsortedDocumentsLucene_listBox";
			this.UnsortedDocumentsLucene_listBox.Size = new System.Drawing.Size(464, 186);
			this.UnsortedDocumentsLucene_listBox.TabIndex = 6;
			this.UnsortedDocumentsLucene_listBox.DoubleClick += new System.EventHandler(this.listBox_DoubleClick);
			// 
			// PersonalizeLucene_checkBox
			// 
			this.PersonalizeLucene_checkBox.Location = new System.Drawing.Point(376, 8);
			this.PersonalizeLucene_checkBox.Name = "PersonalizeLucene_checkBox";
			this.PersonalizeLucene_checkBox.TabIndex = 5;
			this.PersonalizeLucene_checkBox.Text = "Personalisieren";
			// 
			// MaxDocumentNumberLucene_label
			// 
			this.MaxDocumentNumberLucene_label.Location = new System.Drawing.Point(160, 8);
			this.MaxDocumentNumberLucene_label.Name = "MaxDocumentNumberLucene_label";
			this.MaxDocumentNumberLucene_label.Size = new System.Drawing.Size(128, 24);
			this.MaxDocumentNumberLucene_label.TabIndex = 4;
			this.MaxDocumentNumberLucene_label.Text = "Max. Anzahl Dokumente";
			this.MaxDocumentNumberLucene_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// MaxDocumentNumberLucene_textBox
			// 
			this.MaxDocumentNumberLucene_textBox.Location = new System.Drawing.Point(296, 8);
			this.MaxDocumentNumberLucene_textBox.Name = "MaxDocumentNumberLucene_textBox";
			this.MaxDocumentNumberLucene_textBox.Size = new System.Drawing.Size(48, 20);
			this.MaxDocumentNumberLucene_textBox.TabIndex = 3;
			this.MaxDocumentNumberLucene_textBox.Text = "30";
			// 
			// UseLucene_checkBox
			// 
			this.UseLucene_checkBox.Location = new System.Drawing.Point(8, 8);
			this.UseLucene_checkBox.Name = "UseLucene_checkBox";
			this.UseLucene_checkBox.Size = new System.Drawing.Size(176, 24);
			this.UseLucene_checkBox.TabIndex = 2;
			this.UseLucene_checkBox.Text = "Eigenen Index abfragen";
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.GoogleStatus_label);
			this.panel1.Controls.Add(this.UnsortedDocumentsGoogle_listBox);
			this.panel1.Controls.Add(this.PersonalizeGoogle_checkBox);
			this.panel1.Controls.Add(this.MaxDocumentNumberGoogle_label);
			this.panel1.Controls.Add(this.MaxDocumentNumberGoogle_textBox);
			this.panel1.Controls.Add(this.UseGoogle_checkBox);
			this.panel1.Location = new System.Drawing.Point(8, 64);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(480, 232);
			this.panel1.TabIndex = 7;
			// 
			// GoogleStatus_label
			// 
			this.GoogleStatus_label.Location = new System.Drawing.Point(8, 208);
			this.GoogleStatus_label.Name = "GoogleStatus_label";
			this.GoogleStatus_label.Size = new System.Drawing.Size(464, 24);
			this.GoogleStatus_label.TabIndex = 10;
			// 
			// UnsortedDocumentsGoogle_listBox
			// 
			this.UnsortedDocumentsGoogle_listBox.Location = new System.Drawing.Point(8, 32);
			this.UnsortedDocumentsGoogle_listBox.Name = "UnsortedDocumentsGoogle_listBox";
			this.UnsortedDocumentsGoogle_listBox.Size = new System.Drawing.Size(464, 173);
			this.UnsortedDocumentsGoogle_listBox.TabIndex = 9;
			this.UnsortedDocumentsGoogle_listBox.DoubleClick += new System.EventHandler(this.listBox_DoubleClick);
			// 
			// PersonalizeGoogle_checkBox
			// 
			this.PersonalizeGoogle_checkBox.Location = new System.Drawing.Point(376, 8);
			this.PersonalizeGoogle_checkBox.Name = "PersonalizeGoogle_checkBox";
			this.PersonalizeGoogle_checkBox.TabIndex = 8;
			this.PersonalizeGoogle_checkBox.Text = "Personalisieren";
			// 
			// MaxDocumentNumberGoogle_label
			// 
			this.MaxDocumentNumberGoogle_label.Location = new System.Drawing.Point(160, 8);
			this.MaxDocumentNumberGoogle_label.Name = "MaxDocumentNumberGoogle_label";
			this.MaxDocumentNumberGoogle_label.Size = new System.Drawing.Size(128, 24);
			this.MaxDocumentNumberGoogle_label.TabIndex = 7;
			this.MaxDocumentNumberGoogle_label.Text = "Max. Anzahl Dokumente";
			this.MaxDocumentNumberGoogle_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// MaxDocumentNumberGoogle_textBox
			// 
			this.MaxDocumentNumberGoogle_textBox.Location = new System.Drawing.Point(296, 8);
			this.MaxDocumentNumberGoogle_textBox.Name = "MaxDocumentNumberGoogle_textBox";
			this.MaxDocumentNumberGoogle_textBox.Size = new System.Drawing.Size(48, 20);
			this.MaxDocumentNumberGoogle_textBox.TabIndex = 6;
			this.MaxDocumentNumberGoogle_textBox.Text = "30";
			// 
			// UseGoogle_checkBox
			// 
			this.UseGoogle_checkBox.Location = new System.Drawing.Point(8, 8);
			this.UseGoogle_checkBox.Name = "UseGoogle_checkBox";
			this.UseGoogle_checkBox.Size = new System.Drawing.Size(136, 24);
			this.UseGoogle_checkBox.TabIndex = 5;
			this.UseGoogle_checkBox.Text = "GoogleAPI abfragen";
			// 
			// panel2
			// 
			this.panel2.Controls.Add(this.searchstring_textBox);
			this.panel2.Controls.Add(this.startSearch_button);
			this.panel2.Location = new System.Drawing.Point(8, 16);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(480, 48);
			this.panel2.TabIndex = 6;
			// 
			// SortedGroupBox
			// 
			this.SortedGroupBox.Controls.Add(this.UserStatus2_label);
			this.SortedGroupBox.Controls.Add(this.UserStatus_label);
			this.SortedGroupBox.Controls.Add(this.SortedDocuments2_label);
			this.SortedGroupBox.Controls.Add(this.SortedDocuments_label);
			this.SortedGroupBox.Controls.Add(this.panel8);
			this.SortedGroupBox.Controls.Add(this.SortedDocuments2_listBox);
			this.SortedGroupBox.Controls.Add(this.SortedDocuments_listBox);
			this.SortedGroupBox.Location = new System.Drawing.Point(504, 112);
			this.SortedGroupBox.Name = "SortedGroupBox";
			this.SortedGroupBox.Size = new System.Drawing.Size(608, 664);
			this.SortedGroupBox.TabIndex = 5;
			this.SortedGroupBox.TabStop = false;
			this.SortedGroupBox.Text = "SortedGroupBox";
			// 
			// UserStatus2_label
			// 
			this.UserStatus2_label.Location = new System.Drawing.Point(8, 624);
			this.UserStatus2_label.Name = "UserStatus2_label";
			this.UserStatus2_label.Size = new System.Drawing.Size(592, 24);
			this.UserStatus2_label.TabIndex = 10;
			// 
			// UserStatus_label
			// 
			this.UserStatus_label.Location = new System.Drawing.Point(8, 320);
			this.UserStatus_label.Name = "UserStatus_label";
			this.UserStatus_label.Size = new System.Drawing.Size(592, 24);
			this.UserStatus_label.TabIndex = 9;
			// 
			// SortedDocuments2_label
			// 
			this.SortedDocuments2_label.Location = new System.Drawing.Point(184, 360);
			this.SortedDocuments2_label.Name = "SortedDocuments2_label";
			this.SortedDocuments2_label.Size = new System.Drawing.Size(216, 16);
			this.SortedDocuments2_label.TabIndex = 8;
			this.SortedDocuments2_label.Text = "Personalisierte Sortierung von Nutzer B";
			this.SortedDocuments2_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// SortedDocuments_label
			// 
			this.SortedDocuments_label.Location = new System.Drawing.Point(200, 64);
			this.SortedDocuments_label.Name = "SortedDocuments_label";
			this.SortedDocuments_label.Size = new System.Drawing.Size(208, 16);
			this.SortedDocuments_label.TabIndex = 7;
			this.SortedDocuments_label.Text = "Personalisierte Sortierung von Nutzer A";
			this.SortedDocuments_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// panel8
			// 
			this.panel8.Controls.Add(this.ShowGoogle_radioButton);
			this.panel8.Controls.Add(this.ShowLucene_radioButton);
			this.panel8.Controls.Add(this.ShowFooxx_radioButton);
			this.panel8.Location = new System.Drawing.Point(8, 16);
			this.panel8.Name = "panel8";
			this.panel8.Size = new System.Drawing.Size(592, 40);
			this.panel8.TabIndex = 6;
			// 
			// ShowGoogle_radioButton
			// 
			this.ShowGoogle_radioButton.Location = new System.Drawing.Point(8, 8);
			this.ShowGoogle_radioButton.Name = "ShowGoogle_radioButton";
			this.ShowGoogle_radioButton.Size = new System.Drawing.Size(128, 24);
			this.ShowGoogle_radioButton.TabIndex = 3;
			this.ShowGoogle_radioButton.Text = "Sortierung Google";
			this.ShowGoogle_radioButton.CheckedChanged += new System.EventHandler(this.ShowGoogle_radioButton_CheckedChanged);
			// 
			// ShowLucene_radioButton
			// 
			this.ShowLucene_radioButton.Location = new System.Drawing.Point(224, 8);
			this.ShowLucene_radioButton.Name = "ShowLucene_radioButton";
			this.ShowLucene_radioButton.Size = new System.Drawing.Size(152, 24);
			this.ShowLucene_radioButton.TabIndex = 4;
			this.ShowLucene_radioButton.Text = "Sortierung Eigener Index";
			this.ShowLucene_radioButton.CheckedChanged += new System.EventHandler(this.ShowLucene_radioButton_CheckedChanged);
			// 
			// ShowFooxx_radioButton
			// 
			this.ShowFooxx_radioButton.Location = new System.Drawing.Point(472, 8);
			this.ShowFooxx_radioButton.Name = "ShowFooxx_radioButton";
			this.ShowFooxx_radioButton.Size = new System.Drawing.Size(112, 24);
			this.ShowFooxx_radioButton.TabIndex = 5;
			this.ShowFooxx_radioButton.Text = "Sortierung Fooxx";
			this.ShowFooxx_radioButton.CheckedChanged += new System.EventHandler(this.ShowFooxx_radioButton_CheckedChanged);
			// 
			// SortedDocuments2_listBox
			// 
			this.SortedDocuments2_listBox.Location = new System.Drawing.Point(8, 384);
			this.SortedDocuments2_listBox.Name = "SortedDocuments2_listBox";
			this.SortedDocuments2_listBox.Size = new System.Drawing.Size(592, 238);
			this.SortedDocuments2_listBox.TabIndex = 2;
			this.SortedDocuments2_listBox.DoubleClick += new System.EventHandler(this.listBox_DoubleClick);
			// 
			// SortedDocuments_listBox
			// 
			this.SortedDocuments_listBox.Location = new System.Drawing.Point(8, 88);
			this.SortedDocuments_listBox.Name = "SortedDocuments_listBox";
			this.SortedDocuments_listBox.Size = new System.Drawing.Size(592, 225);
			this.SortedDocuments_listBox.TabIndex = 0;
			this.SortedDocuments_listBox.DoubleClick += new System.EventHandler(this.listBox_DoubleClick);
			// 
			// panel4
			// 
			this.panel4.Controls.Add(this.k_label);
			this.panel4.Controls.Add(this.k_textBox);
			this.panel4.Location = new System.Drawing.Point(144, 24);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(96, 72);
			this.panel4.TabIndex = 3;
			// 
			// k_label
			// 
			this.k_label.Location = new System.Drawing.Point(8, 8);
			this.k_label.Name = "k_label";
			this.k_label.Size = new System.Drawing.Size(24, 24);
			this.k_label.TabIndex = 1;
			this.k_label.Text = "k";
			this.k_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// k_textBox
			// 
			this.k_textBox.Location = new System.Drawing.Point(40, 8);
			this.k_textBox.Name = "k_textBox";
			this.k_textBox.Size = new System.Drawing.Size(48, 20);
			this.k_textBox.TabIndex = 0;
			this.k_textBox.Text = "2";
			// 
			// panel3
			// 
			this.panel3.Controls.Add(this.RankAlgorithm_g1_radioButton);
			this.panel3.Location = new System.Drawing.Point(16, 24);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(120, 72);
			this.panel3.TabIndex = 2;
			// 
			// RankAlgorithm_g1_radioButton
			// 
			this.RankAlgorithm_g1_radioButton.Checked = true;
			this.RankAlgorithm_g1_radioButton.Location = new System.Drawing.Point(8, 8);
			this.RankAlgorithm_g1_radioButton.Name = "RankAlgorithm_g1_radioButton";
			this.RankAlgorithm_g1_radioButton.TabIndex = 0;
			this.RankAlgorithm_g1_radioButton.TabStop = true;
			this.RankAlgorithm_g1_radioButton.Text = "Algorithmus g1";
			// 
			// ControlGroupBox
			// 
			this.ControlGroupBox.Controls.Add(this.status_label);
			this.ControlGroupBox.Controls.Add(this.panel5);
			this.ControlGroupBox.Controls.Add(this.SortIt_button);
			this.ControlGroupBox.Controls.Add(this.panel4);
			this.ControlGroupBox.Controls.Add(this.panel3);
			this.ControlGroupBox.Location = new System.Drawing.Point(504, 8);
			this.ControlGroupBox.Name = "ControlGroupBox";
			this.ControlGroupBox.Size = new System.Drawing.Size(608, 104);
			this.ControlGroupBox.TabIndex = 6;
			this.ControlGroupBox.TabStop = false;
			this.ControlGroupBox.Text = "ControlGroupBox";
			// 
			// status_label
			// 
			this.status_label.Location = new System.Drawing.Point(440, 64);
			this.status_label.Name = "status_label";
			this.status_label.Size = new System.Drawing.Size(160, 32);
			this.status_label.TabIndex = 6;
			this.status_label.Text = "Status der Personalisierung";
			// 
			// panel5
			// 
			this.panel5.Controls.Add(this.SearchUserID2_button);
			this.panel5.Controls.Add(this.SearchUserID_button);
			this.panel5.Controls.Add(this.UserID2_label);
			this.panel5.Controls.Add(this.UserID_label);
			this.panel5.Controls.Add(this.UserID2_textBox);
			this.panel5.Controls.Add(this.UserID_textBox);
			this.panel5.Location = new System.Drawing.Point(248, 24);
			this.panel5.Name = "panel5";
			this.panel5.Size = new System.Drawing.Size(184, 72);
			this.panel5.TabIndex = 5;
			// 
			// SearchUserID2_button
			// 
			this.SearchUserID2_button.Location = new System.Drawing.Point(128, 40);
			this.SearchUserID2_button.Name = "SearchUserID2_button";
			this.SearchUserID2_button.Size = new System.Drawing.Size(48, 24);
			this.SearchUserID2_button.TabIndex = 8;
			this.SearchUserID2_button.Text = "...";
			this.SearchUserID2_button.Click += new System.EventHandler(this.SearchUserID2_button_Click);
			// 
			// SearchUserID_button
			// 
			this.SearchUserID_button.Location = new System.Drawing.Point(128, 8);
			this.SearchUserID_button.Name = "SearchUserID_button";
			this.SearchUserID_button.Size = new System.Drawing.Size(48, 24);
			this.SearchUserID_button.TabIndex = 7;
			this.SearchUserID_button.Text = "...";
			this.SearchUserID_button.Click += new System.EventHandler(this.SearchUserID_button_Click);
			// 
			// UserID2_label
			// 
			this.UserID2_label.Location = new System.Drawing.Point(8, 40);
			this.UserID2_label.Name = "UserID2_label";
			this.UserID2_label.Size = new System.Drawing.Size(48, 24);
			this.UserID2_label.TabIndex = 6;
			this.UserID2_label.Text = "Nutzer B";
			this.UserID2_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// UserID_label
			// 
			this.UserID_label.Location = new System.Drawing.Point(8, 8);
			this.UserID_label.Name = "UserID_label";
			this.UserID_label.Size = new System.Drawing.Size(48, 24);
			this.UserID_label.TabIndex = 5;
			this.UserID_label.Text = "Nutzer A";
			this.UserID_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// UserID2_textBox
			// 
			this.UserID2_textBox.Location = new System.Drawing.Point(72, 40);
			this.UserID2_textBox.Name = "UserID2_textBox";
			this.UserID2_textBox.Size = new System.Drawing.Size(48, 20);
			this.UserID2_textBox.TabIndex = 4;
			this.UserID2_textBox.Text = "21";
			// 
			// UserID_textBox
			// 
			this.UserID_textBox.Location = new System.Drawing.Point(72, 8);
			this.UserID_textBox.Name = "UserID_textBox";
			this.UserID_textBox.Size = new System.Drawing.Size(48, 20);
			this.UserID_textBox.TabIndex = 0;
			this.UserID_textBox.Text = "301";
			// 
			// SortIt_button
			// 
			this.SortIt_button.Location = new System.Drawing.Point(440, 24);
			this.SortIt_button.Name = "SortIt_button";
			this.SortIt_button.Size = new System.Drawing.Size(160, 32);
			this.SortIt_button.TabIndex = 1;
			this.SortIt_button.Text = "Personalisierte Bewertung durchf�hren";
			this.SortIt_button.Click += new System.EventHandler(this.SortIt_button_Click);
			// 
			// SaveAll_button
			// 
			this.SaveAll_button.Location = new System.Drawing.Point(944, 776);
			this.SaveAll_button.Name = "SaveAll_button";
			this.SaveAll_button.Size = new System.Drawing.Size(168, 24);
			this.SaveAll_button.TabIndex = 7;
			this.SaveAll_button.Text = "Ergebnislisten speichern";
			this.SaveAll_button.Click += new System.EventHandler(this.SaveAll_button_Click);
			// 
			// GUI
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(1208, 814);
			this.Controls.Add(this.SaveAll_button);
			this.Controls.Add(this.ControlGroupBox);
			this.Controls.Add(this.SortedGroupBox);
			this.Controls.Add(this.UnsortedGroupBox);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "GUI";
			this.Text = "Testumgebung im Rahmen der Diplomarbeit";
			this.UnsortedGroupBox.ResumeLayout(false);
			this.panel7.ResumeLayout(false);
			this.panel6.ResumeLayout(false);
			this.panel1.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			this.SortedGroupBox.ResumeLayout(false);
			this.panel8.ResumeLayout(false);
			this.panel4.ResumeLayout(false);
			this.panel3.ResumeLayout(false);
			this.ControlGroupBox.ResumeLayout(false);
			this.panel5.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		
		#endregion
		
		/// <summary>
		/// Die verwendeten Ressourcen bereinigen.
		/// </summary>	
		protected override void Dispose (bool disposing)
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );		
		}
		
		public void ShowDocuments (ListBox document_listBox, Document [ ] UnsortedDocumentList)
		{
			try 
			{
				document_listBox.Items.Clear();
				document_listBox.BeginUpdate();
		
				if (UnsortedDocumentList != null && UnsortedDocumentList.Length > 0) 
				{
					foreach (Document d in UnsortedDocumentList) 
					{
						document_listBox.Items.Add(d);
					}
				} 
				else 
				{
					document_listBox.Items.Add("Keine Dokumente gefunden!"); 
				}
		
				document_listBox.EndUpdate();
			}
			catch (Exception ex) 
			{
				status_label.Text="Fehler bei der Anzeige der Dokumente!"; 
			}
		}
		
		private void startSearch_button_Click (object sender, System.EventArgs e)
		{
			startSearch();			
		}
		
		private void searchstring_textBox_KeyDown (object sender, System.Windows.Forms.KeyEventArgs e)
		{
			if (e.KeyCode==System.Windows.Forms.Keys.Return) 
			{
				startSearch();
			}
		}
		
		private void DocumentListCopy (Document [ ] source, Document [ ] destination)
		{
			for (int i=0;i<source.Length;i++) 
			{
				Document old_d = source[i];
				Document new_d = new Document(old_d.URL,old_d.Title,old_d.Snippet,old_d.IDFooxxDB,old_d.UnsortedRankNumber,old_d.SearchEngine);
				destination[i] = new_d;
			}
		}
		
		private void startSearch ()
		{
			try 
			{
				this.Cursor = System.Windows.Forms.Cursors.WaitCursor;
				if (UseGoogle_checkBox.Checked) 
				{
					DateTime now = System.DateTime.Now;
		        
					GoogleControl[0].MaxNumberOfDocuments = Int32.Parse(MaxDocumentNumberGoogle_textBox.Text);
					GoogleControl[1].MaxNumberOfDocuments = Int32.Parse(MaxDocumentNumberGoogle_textBox.Text);
				
					GoogleControl[0].UseGoogleAPI(searchstring_textBox.Text);
				
					GoogleControl[1].UnsortedDocumentList=new Document[GoogleControl[0].UnsortedDocumentList.Length];
					DocumentListCopy(GoogleControl[0].UnsortedDocumentList,GoogleControl[1].UnsortedDocumentList);
					//Array.Copy(GoogleControl[0].UnsortedDocumentList,GoogleControl[1].UnsortedDocumentList,GoogleControl[0].UnsortedDocumentList.Length);
		
					DateTime later = System.DateTime.Now;
					TimeSpan timeSpan = later-now;
				
					GoogleStatus_label.Text = "Abfragezeit:"+timeSpan.Minutes+":"+timeSpan.Seconds+":"+timeSpan.Milliseconds;
					ShowDocuments(UnsortedDocumentsGoogle_listBox,GoogleControl[0].UnsortedDocumentList);
		
				}
			}
			catch (Exception e) 
			{
				GoogleStatus_label.Text = "Fehler bei der Abfrage";
			}
			try 
			{
				if (UseLucene_checkBox.Checked) 
				{
					DateTime now = System.DateTime.Now;
				
					LuceneControl[0].MaxNumberOfDocuments = Int32.Parse(MaxDocumentNumberLucene_textBox.Text); 
					LuceneControl[1].MaxNumberOfDocuments = Int32.Parse(MaxDocumentNumberLucene_textBox.Text); 
				
					LuceneControl[0].UseLuceneIndex(searchstring_textBox.Text); 				
				
					LuceneControl[1].UnsortedDocumentList=new Document[LuceneControl[0].UnsortedDocumentList.Length]; 
					DocumentListCopy(LuceneControl[0].UnsortedDocumentList,LuceneControl[1].UnsortedDocumentList); 
					//Array.Copy(LuceneControl[0].UnsortedDocumentList,LuceneControl[1].UnsortedDocumentList,LuceneControl[0].UnsortedDocumentList.Length);
				
					DateTime later = System.DateTime.Now;
					TimeSpan timeSpan = later-now;
				
					LuceneStatus_label.Text = "Abfragezeit:"+timeSpan.Minutes+":"+timeSpan.Seconds+":"+timeSpan.Milliseconds;
					ShowDocuments(UnsortedDocumentsLucene_listBox,LuceneControl[0].UnsortedDocumentList);
				}
			}
			catch (Exception e) 
			{
				LuceneStatus_label.Text = "Fehler bei der Abfrage";
			}
			try 
			{
				if (UseFooxx_checkBox.Checked) 
				{
					DateTime now = System.DateTime.Now;
				
					FooxxControl[0].MaxNumberOfDocuments = Int32.Parse(MaxDocumentNumberFooxx_textBox.Text); 
					FooxxControl[1].MaxNumberOfDocuments = Int32.Parse(MaxDocumentNumberFooxx_textBox.Text); 
				
					FooxxControl[0].UseFooxxAPI(searchstring_textBox.Text,FooxxUser_textBox.Text); 
				
					FooxxControl[1].UnsortedDocumentList=new Document[FooxxControl[0].UnsortedDocumentList.Length];
					DocumentListCopy(FooxxControl[0].UnsortedDocumentList,FooxxControl[1].UnsortedDocumentList); 
					//Array.Copy(FooxxControl[0].UnsortedDocumentList,FooxxControl[1].UnsortedDocumentList,FooxxControl[0].UnsortedDocumentList.Length); 
				
					DateTime later = System.DateTime.Now;
					TimeSpan timeSpan = later-now;
				
					FooxxStatus_label.Text = "Abfragezeit:"+timeSpan.Minutes+":"+timeSpan.Seconds+":"+timeSpan.Milliseconds;
					ShowDocuments(UnsortedDocumentsFooxx_listBox,FooxxControl[0].UnsortedDocumentList);
				}	
			}
			catch (Exception e) 
			{
				FooxxStatus_label.Text = "Fehler bei der Abfrage";
			}
			this.Cursor = System.Windows.Forms.Cursors.Default;
		}
		
		private void SortIt_button_Click (object sender, System.EventArgs e)
		{
			try 
			{
				User searchUser = TestAPI.GetUserByID(Int32.Parse(UserID_textBox.Text));
				User searchUser2 = TestAPI.GetUserByID(Int32.Parse(UserID2_textBox.Text)); 
			
				status_label.Text = "Bitte warten!";
				UserStatus_label.Text = "";
				UserStatus2_label.Text = ""; 
				this.Update(); 
				this.Cursor = System.Windows.Forms.Cursors.WaitCursor;
			
				DateTime nowAll = System.DateTime.Now;
				if (PersonalizeGoogle_checkBox.Checked) 
				{
					DateTime now = System.DateTime.Now;
					GoogleControl[0].SortDocumentList(searchUser,(int)TestAPI.AlgorithmNumbers.RankAlgortihm_g1,Double.Parse(this.k_textBox.Text));
					DateTime later = System.DateTime.Now; TimeSpan timeSpan = later-now;
					UserStatus_label.Text +=" Google:"+timeSpan.Minutes+":"+timeSpan.Seconds+":"+timeSpan.Milliseconds; 
		
					now = System.DateTime.Now;
					GoogleControl[1].SortDocumentList(searchUser2,(int)TestAPI.AlgorithmNumbers.RankAlgortihm_g1,Double.Parse(this.k_textBox.Text));
					later = System.DateTime.Now; timeSpan = later-now;
					UserStatus2_label.Text +=" Google:"+timeSpan.Minutes+":"+timeSpan.Seconds+":"+timeSpan.Milliseconds; 
				
					ShowGoogle_radioButton.Checked=true;
					ShowGoogle_radioButton_CheckedChanged(ShowGoogle_radioButton,new System.EventArgs());
					status_label.Text="Personalisierung Google durchgef�hrt...";
					this.Update(); 
				}
				if (PersonalizeLucene_checkBox.Checked) 
				{
					DateTime now = System.DateTime.Now;
					LuceneControl[0].SortDocumentList(searchUser,(int)TestAPI.AlgorithmNumbers.RankAlgortihm_g1,Double.Parse(this.k_textBox.Text));
					DateTime later = System.DateTime.Now; TimeSpan timeSpan = later-now;
					UserStatus_label.Text +=" Lucene:"+timeSpan.Minutes+":"+timeSpan.Seconds+":"+timeSpan.Milliseconds; 
		
					now = System.DateTime.Now;
					LuceneControl[1].SortDocumentList(searchUser2,(int)TestAPI.AlgorithmNumbers.RankAlgortihm_g1,Double.Parse(this.k_textBox.Text));
					later = System.DateTime.Now; timeSpan = later-now;
					UserStatus2_label.Text +=" Lucene:"+timeSpan.Minutes+":"+timeSpan.Seconds+":"+timeSpan.Milliseconds; 
		
					ShowLucene_radioButton.Checked=true;
					ShowLucene_radioButton_CheckedChanged(ShowLucene_radioButton,new System.EventArgs());
					status_label.Text="Personalisierung Eigener Index durchgef�hrt...";
					this.Update(); 
				}
				if (PersonalizeFooxx_checkBox.Checked) 
				{
					DateTime now = System.DateTime.Now;
					FooxxControl[0].SortDocumentList(searchUser,(int)TestAPI.AlgorithmNumbers.RankAlgortihm_g1,Double.Parse(this.k_textBox.Text));
					DateTime later = System.DateTime.Now; TimeSpan timeSpan = later-now;
					UserStatus_label.Text +=" Fooxx:"+timeSpan.Minutes+":"+timeSpan.Seconds+":"+timeSpan.Milliseconds; 
		
					now = System.DateTime.Now;
					FooxxControl[1].SortDocumentList(searchUser2,(int)TestAPI.AlgorithmNumbers.RankAlgortihm_g1,Double.Parse(this.k_textBox.Text));
					later = System.DateTime.Now; timeSpan = later-now;
					UserStatus2_label.Text +=" Fooxx:"+timeSpan.Minutes+":"+timeSpan.Seconds+":"+timeSpan.Milliseconds; 
		
					ShowFooxx_radioButton.Checked=true;
					ShowFooxx_radioButton_CheckedChanged(ShowFooxx_radioButton,new System.EventArgs());
					status_label.Text="Personalisierung Fooxx durchgef�hrt...!";
				}
				DateTime laterAll = System.DateTime.Now; TimeSpan timeSpanAll = laterAll-nowAll;
		
				status_label.Text = "Personalisierung durchgef�hrt!\nZeit:"+timeSpanAll.Minutes+":"+timeSpanAll.Seconds+":"+timeSpanAll.Milliseconds;
				this.Cursor = System.Windows.Forms.Cursors.Default;
			}
			catch (Exception ex)
			{
				this.Cursor = System.Windows.Forms.Cursors.Default;
				status_label.Text = "Fehler beim Durchf�hren der Personalisierung!";
			}
						
		
		}
		
		[STAThread]
		public static void Main (string [ ] args)
		{
			System.Windows.Forms.Application.Run(new GUI());
		}
		
		private void SearchUserID_button_Click (object sender, System.EventArgs e)
		{
			ChooseUserDialog dlg = new ChooseUserDialog();
			if (dlg.ShowDialog() == DialogResult.OK) 
			{
				if (dlg.choosedUser != null) 
				{
					UserID_textBox.Text= dlg.choosedUser.UserID.ToString();
				}
			}
		}
		
		private void SearchUserID2_button_Click (object sender, System.EventArgs e)
		{
			ChooseUserDialog dlg = new ChooseUserDialog();
			if (dlg.ShowDialog() == DialogResult.OK) 
			{
				if (dlg.choosedUser != null) 
				{
					UserID2_textBox.Text= dlg.choosedUser.UserID.ToString();	
				}
			}
		}
		
		private void listBox_DoubleClick (object sender, System.EventArgs e)
		{
			if (((ListBox)sender).SelectedIndex>=0) 
			{
				Document document = (Document)((ListBox)sender).SelectedItem;
								
				ArrayList otherEngines = new ArrayList();
				
				if (GoogleControl[0].UnsortedDocumentList!=null) 
				{
					foreach (Document d in GoogleControl[0].UnsortedDocumentList) 
					{
						if (d.URL.Equals(document.URL))
							otherEngines.Add(d);
					}
				}
				if (LuceneControl[0].UnsortedDocumentList!=null) 
				{
					foreach (Document d in LuceneControl[0].UnsortedDocumentList) 
					{ 
						if (d.URL.Equals(document.URL))
							otherEngines.Add(d);
					}
				}
				if (FooxxControl[0].UnsortedDocumentList!=null)  
				{
					foreach (Document d in FooxxControl[0].UnsortedDocumentList)  
					{
						if (d.URL.Equals(document.URL))
							otherEngines.Add(d);
					}
				}
				for (int i=0;i<2;i++) 
				{
					if (GoogleControl[i].SortedDocumentList!=null) 
					{
						foreach (Document d in GoogleControl[i].SortedDocumentList) 
						{
							if (d.URL.Equals(document.URL))
								otherEngines.Add(d);
						}
					}
				}
				for (int i=0;i<2;i++) 
				{
					if (LuceneControl[i].SortedDocumentList!=null) 
					{  
						foreach (Document d in LuceneControl[i].SortedDocumentList)  
						{
							if (d.URL.Equals(document.URL))
								otherEngines.Add(d);
						}
					}
				}
				for (int i=0;i<2;i++) 
				{
					if (FooxxControl[i].SortedDocumentList!=null)  
					{
						foreach (Document d in FooxxControl[i].SortedDocumentList)  
						{
							if (d.URL.Equals(document.URL))
								otherEngines.Add(d);
						}
					}
				}
		
				ViewDocument propertyWindow = new ViewDocument(document,otherEngines); 
				propertyWindow.Show();
						
			}			
		}
		
		private void ShowGoogle_radioButton_CheckedChanged (object sender, System.EventArgs e)
		{
			ShowDocuments(SortedDocuments_listBox,GoogleControl[0].SortedDocumentList); 
			ShowDocuments(SortedDocuments2_listBox,GoogleControl[1].SortedDocumentList); 
		}
		
		private void ShowLucene_radioButton_CheckedChanged (object sender, System.EventArgs e)
		{
			ShowDocuments(SortedDocuments_listBox,LuceneControl[0].SortedDocumentList); 
			ShowDocuments(SortedDocuments2_listBox,LuceneControl[1].SortedDocumentList); 
		}
		
		private void ShowFooxx_radioButton_CheckedChanged (object sender, System.EventArgs e)
		{
			ShowDocuments(SortedDocuments_listBox,FooxxControl[0].SortedDocumentList); 
			ShowDocuments(SortedDocuments2_listBox,FooxxControl[1].SortedDocumentList); 
		}

		private void SaveAll_button_Click(object sender, System.EventArgs e)
		{
			Stream stream ;
 
			saveFileDialog.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*"  ;
			saveFileDialog.FilterIndex = 2 ;
			saveFileDialog.RestoreDirectory = true ;
 
			if(saveFileDialog.ShowDialog() == DialogResult.OK)
			{
				if((stream = saveFileDialog.OpenFile()) != null)
				{
					StreamWriter writer = new StreamWriter(stream);
					
					writer.WriteLine(" ------ Ergebnisliste Google: -------");
					try 
					{
						foreach (Document d in GoogleControl[0].UnsortedDocumentList) 
							writer.WriteLine(d.ToString());
					}
					catch (Exception ex) {	writer.WriteLine("Keine Ergebnisse vorhanden."); }

					writer.WriteLine("\r\n\r\n ------  Ergebnisliste Eigener Index: ------");
					try 
					{
						foreach (Document d in LuceneControl[0].UnsortedDocumentList) 
							writer.WriteLine(d.ToString());
					}
					catch (Exception ex) {	writer.WriteLine("Keine Ergebnisse vorhanden."); }

					writer.WriteLine("\r\n\r\n ------  Ergebnisliste Fooxx: ------");
					try 
					{
						foreach (Document d in FooxxControl[0].UnsortedDocumentList) 
							writer.WriteLine(d.ToString());
					}
					catch (Exception ex) {	writer.WriteLine("Keine Ergebnisse vorhanden."); }

					writer.WriteLine("\r\n\r\n ------  Ergebnisse Personalisierung Google f�r Nutzer A: -------");
					try 
					{
						foreach (Document d in GoogleControl[0].SortedDocumentList) 
							writer.WriteLine(d.ToString());
					}
					catch (Exception ex) {	writer.WriteLine("Keine Ergebnisse vorhanden.");	}

					writer.WriteLine("\r\n\r\n ------  Ergebnisse Personalisierung Google f�r Nutzer B: -------");
					try 
					{
						foreach (Document d in GoogleControl[1].SortedDocumentList) 
							writer.WriteLine(d.ToString());
					}
					catch (Exception ex) {	writer.WriteLine("Keine Ergebnisse vorhanden."); }

					writer.WriteLine("\r\n\r\n ------  Ergebnisse Personalisierung eigener Index f�r Nutzer A: -------");
					try 
					{
						foreach (Document d in LuceneControl[0].SortedDocumentList) 
							writer.WriteLine(d.ToString());
					}
					catch (Exception ex) {	writer.WriteLine("Keine Ergebnisse vorhanden."); 	}

					writer.WriteLine("\r\n\r\n ------  Ergebnisse Personalisierung eigener Index f�r Nutzer B: -------");
					try 
					{
						foreach (Document d in LuceneControl[1].SortedDocumentList) 
							writer.WriteLine(d.ToString());
					}
					catch (Exception ex) {	writer.WriteLine("Keine Ergebnisse vorhanden.");	}

					writer.WriteLine("\r\n\r\n ------  Ergebnisse Personalisierung Fooxx f�r Nutzer A: -------");
					try 
					{
						foreach (Document d in FooxxControl[0].SortedDocumentList) 
							writer.WriteLine(d.ToString());
					}
					catch (Exception ex) {	writer.WriteLine("Keine Ergebnisse vorhanden.");	}

					writer.WriteLine("\r\n\r\n ------  Ergebnisse Personalisierung Fooxx f�r Nutzer B: -------");
					try 
					{
						foreach (Document d in FooxxControl[1].SortedDocumentList) 
							writer.WriteLine(d.ToString());
					}
					catch (Exception ex) {	writer.WriteLine("Keine Ergebnisse vorhanden."); 	}
					
					writer.Close(); 
					stream.Close();
				}
			}

		}
	}
}