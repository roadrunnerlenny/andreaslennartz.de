//..begin "File Description"
/*--------------------------------------------------------------------------------*
   Filename:  User.cs
   Tool:      objectiF, CSharpSSvr V5.0.165
 *--------------------------------------------------------------------------------*/
//..end "File Description"

using System;
using MySql.Data.MySqlClient;
using TestEnvironment.GoogleAPI;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.IO;
using System.Text;
using System.Web;
using RankAlgorithmLib;

namespace TestEnvironment
{	
	public class User
	{
		public int UserID
		{
			get
			{
				return I_UserID;
			}
			
			set
			{
				I_UserID = value;
			}
		}
		
		public string Username
		{
			get
			{
				return I_Username;
			}
			
			set
			{
				I_Username = value;
			}
		}
		
		private int I_UserID;
		private string I_Username;
		
		public User (int UserID, string Username)
		{
			this.I_UserID = UserID;
			this.I_Username = Username;
		}
		
		public override string ToString ()
		{
			return I_Username+"("+I_UserID+")";
		}
	}
}